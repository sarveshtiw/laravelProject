<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

/*
 * Web page routes
 */
//Route::get('/', 'WelcomeController@index');
Route::get('/', 'WebController@index');
Route::get('/login', 'Auth\AuthController@getLogin');
Route::get('/login', 'Auth\AuthController@getLogin');

Route::get('home', 'HomeController@index');
Route::get('term/index', 'TermController@index');
Route::get('term/privacy', 'TermController@privacy');

Route::get('nightclub/index', ['middleware' => 'checkRole', 'roles' => ['club admin','admin'], 'uses' => 'NightclubController@index']);
Route::any('nightclub/search',['middleware' => 'checkRole', 'roles' => ['admin'], 'uses' => 'NightclubController@searchNightClub']);
Route::get('nightclub/create',['middleware' => 'checkRole', 'roles' => ['admin','club admin'], 'uses' => 'NightclubController@showNightClubForm']);
Route::post('nightclub/create',['middleware' => 'checkRole', 'roles' => ['admin','club admin'], 'uses' => 'NightclubController@createNightClub']);
Route::post('nightclub/edit',['middleware' => 'checkRole', 'roles' => ['admin','club admin'], 'uses' => 'NightclubController@editNightClub']);
Route::get('nightclub/update/{id}',['middleware' => 'checkRole', 'roles' => ['admin','club admin'], 'uses' => 'NightclubController@updateNightClub']);
Route::post('nightclub/deactivate',['middleware' => 'checkRole', 'roles' => ['admin'], 'uses' => 'NightclubController@deactivateNightClub']);
Route::post('nightclub/activate',['middleware' => 'checkRole', 'roles' => ['admin'], 'uses' => 'NightclubController@activateNightClub']);
Route::get('nightclub/viewDetails/{id}',['middleware' => 'checkRole', 'roles' => ['admin'], 'uses' => 'NightclubController@viewDetailsNightClub']);
Route::get('nightclub/changePassword',['middleware' => 'checkRole', 'roles' => ['admin','club admin','deal admin','event admin'], 'uses' => 'NightclubUserController@viewChangePasswordForm']);
Route::post('nightclub/password/reset',['middleware' => 'checkRole', 'roles' => ['admin','club admin','deal admin','event admin'], 'uses' => 'NightclubUserController@changePassword']);
Route::post('nightclub/resetPassword/email',['uses' => 'NightclubUserController@resetPassword']);
Route::get('nightclub/viewAssignedNightclub',['middleware' => 'checkRole', 'roles' => ['admin','club admin'], 'uses' => 'NightclubController@viewAssignedNightclub']);
Route::post('nightclub/uploadClubMultipleImages',['middleware' => 'checkRole', 'roles' => ['club admin','admin'], 'uses' => 'NightclubController@uploadClubMultipleImages']);
Route::get('nightclub/deleteClubImages',['middleware' => 'checkRole', 'roles' => ['club admin','admin'], 'uses' => 'NightclubController@deleteClubImages']);
Route::post('nighclub/validateUserEmail',['middleware' => 'checkRole', 'roles' => ['club admin','admin'], 'uses' => 'NightclubController@validateUserEmail']);


Route::get('nightclub/viewAdminUserDetails',['middleware' => 'checkRole', 'roles' => ['club admin'], 'uses' => 'NightclubUserController@viewAdminUserDetails']);
Route::get('nightclub/viewCreateAdmin',['middleware' => 'checkRole', 'roles' => ['club admin'], 'uses' => 'NightclubUserController@viewCreateAdminPage']);
Route::post('nightclub/createAdmin',['middleware' => 'checkRole', 'roles' => ['club admin'], 'uses' => 'NightclubUserController@createAdmin']);
Route::get('nightclub/allUserDetails',['middleware' => 'checkRole', 'roles' => ['club admin','admin'], 'uses' => 'NightclubUserController@viewClubUserDetails']);

Route::get('nightclub/viewClubAdmins',['middleware' => 'checkRole', 'roles' => ['club admin','admin'], 'uses' => 'NightclubUserController@viewClubAdmins']);
Route::any('nightclub/searchClubAdmins',['middleware' => 'checkRole', 'roles' => ['club admin','admin'], 'uses' => 'NightclubUserController@searchClubAdmins']);
Route::any('nightclub/searchAdminUserDetails',['middleware' => 'checkRole', 'roles' => ['club admin','admin'], 'uses' => 'NightclubUserController@searchAdminUserDetails']);


Route::any('nightclub/viewDealAdminDetails',['middleware' => 'checkRole', 'roles' => ['club admin','admin'], 'uses' => 'NightclubUserController@viewDealAdminDetails']);
Route::any('nightclub/searchDealAdminDetails',['middleware' => 'checkRole', 'roles' => ['club admin','admin'], 'uses' => 'NightclubUserController@searchDealAdminDetails']);

Route::any('nightclub/viewEventAdminDetails',['middleware' => 'checkRole', 'roles' => ['club admin','admin'], 'uses' => 'NightclubUserController@viewEventAdminDetails']);
Route::any('nightclub/searchEventAdminDetails',['middleware' => 'checkRole', 'roles' => ['club admin','admin'], 'uses' => 'NightclubUserController@searchEventAdminDetails']);

Route::any('user/viewReportedUsers',['middleware' => 'checkRole', 'roles' => ['admin'], 'uses' => 'NightclubUserController@viewReportedUsers']);
Route::any('user/searchReportedUsers',['middleware' => 'checkRole', 'roles' => ['admin'], 'uses' => 'NightclubUserController@searchReportedUsers']);

Route::any('group/viewReportedGroups',['middleware' => 'checkRole', 'roles' => ['admin'], 'uses' => 'NightclubUserController@viewReportedGroups']);
Route::any('group/searchReportedGroups',['middleware' => 'checkRole', 'roles' => ['admin'], 'uses' => 'NightclubUserController@searchReportedGroups']);

Route::get('nightclub/deleteAppUser/{id}',['middleware' => 'checkRole', 'roles' => ['club admin','admin'], 'uses' => 'NightclubUserController@deleteAppUser']);
Route::get('nightclub/deleteAdminUser/{id}',['middleware' => 'checkRole', 'roles' => ['club admin','admin'], 'uses' => 'NightclubUserController@deleteAdminUser']);
Route::post('nightclub/activateUser',['middleware' => 'checkRole', 'roles' => ['club admin','admin'], 'uses' => 'NightclubUserController@activateClubUser']);
Route::get('nightclub/viewCreateEvent',['middleware' => 'checkRole', 'roles' => ['club admin','admin','event admin'], 'uses' => 'NightclubEventController@viewCreateEventPage']);
Route::post('nightclub/createEvent',['middleware' => 'checkRole', 'roles' => ['club admin','admin','event admin'], 'uses' => 'NightclubEventController@createEvent']);
Route::post('nightclub/editEvent',['middleware' => 'checkRole', 'roles' => ['admin','club admin', 'event admin'], 'uses' => 'NightclubEventController@editNightClubEvent']);

Route::get('nightclub/createDeal',['middleware' => 'checkRole', 'roles' => ['club admin','admin','deal admin'], 'uses' => 'NightclubDealController@viewCreateDealPage']);
Route::post('nightclub/createDeal',['middleware' => 'checkRole', 'roles' => ['club admin','admin','deal admin'], 'uses' => 'NightclubDealController@createDeal']);
Route::get('nightclub/deleteDeal/{id}',['middleware' => 'checkRole', 'roles' => ['club admin','admin','deal admin'], 'uses' => 'NightclubDealController@deleteDeal']);

Route::get('nightclub/allEventDetails',['middleware' => 'checkRole', 'roles' => ['club admin','admin','event admin'], 'uses' => 'NightclubEventController@viewNightclubEventDetails']);
Route::get('nightclub/disabledEventDetails',['middleware' => 'checkRole', 'roles' => ['club admin','admin','event admin'], 'uses' => 'NightclubEventController@viewDisabledEvents']);
Route::get('nightclub/deleteEvent/{id}',['middleware' => 'checkRole', 'roles' => ['club admin','admin','deal admin','event admin'], 'uses' => 'NightclubEventController@deleteEvent']);
Route::get('nightclub/disableEvent/{id}',['middleware' => 'checkRole', 'roles' => ['club admin','admin','event admin'], 'uses' => 'NightclubEventController@disableEvent']);
Route::get('nightclub/activateEvent/{id}',['middleware' => 'checkRole', 'roles' => ['club admin','admin','event admin'], 'uses' => 'NightclubEventController@activateEvent']);
Route::get('nightclub/updateEvent/{id}',['middleware' => 'checkRole', 'roles' => ['club admin','admin','event admin'], 'uses' => 'NightclubEventController@updateNightClubEvent']);
Route::get('nightclub/viewEventDetails/{id}',['middleware' => 'checkRole', 'roles' => ['club admin','admin','event admin'], 'uses' => 'NightclubEventController@viewDetailsNightClubEvent']);
Route::get('nightclub/addEventAdditionalImages/{id}',['middleware' => 'checkRole', 'roles' => ['admin','club admin','event admin'], 'uses' => 'NightclubEventController@addEventAdditionalImages']);

Route::get('nightclub/allDealDetails',['middleware' => 'checkRole', 'roles' => ['club admin','admin','deal admin'], 'uses' => 'NightclubDealController@viewNightclubDealDetails']);
Route::get('nightclub/disabledDealDetails',['middleware' => 'checkRole', 'roles' => ['club admin','admin','deal admin'], 'uses' => 'NightclubDealController@viewDisabledDeals']);
Route::get('nightclub/deleteDeal/{id}',['middleware' => 'checkRole', 'roles' => ['club admin','admin','deal admin','event admin'], 'uses' => 'NightclubDealController@deleteDeal']);
Route::get('nightclub/disableDeal/{id}',['middleware' => 'checkRole', 'roles' => ['club admin','admin','deal admin'], 'uses' => 'NightclubDealController@disableDeal']);
Route::get('nightclub/activateDeal/{id}',['middleware' => 'checkRole', 'roles' => ['club admin','admin','deal admin'], 'uses' => 'NightclubDealController@activateDeal']);
Route::get('nightclub/updateDeal/{id}',['middleware' => 'checkRole', 'roles' => ['club admin','admin','deal admin'], 'uses' => 'NightclubDealController@updateNightClubDeal']);
Route::get('nightclub/viewDealDetails/{id}',['middleware' => 'checkRole', 'roles' => ['club admin','admin','deal admin'], 'uses' => 'NightclubDealController@viewDetailsNightClubDeal']);
Route::any('nightclub/searchUser',['middleware' => 'checkRole', 'roles' => ['club admin','admin'], 'uses' => 'NightclubUserController@searchNightClubUser']);
Route::any('nightclub/searchEvent',['middleware' => 'checkRole', 'roles' => ['club admin','admin','event admin'], 'uses' => 'NightclubEventController@searchNightClubEvent']);
Route::any('nightclub/searchDisabledEvent',['middleware' => 'checkRole', 'roles' => ['club admin','admin','event admin'], 'uses' => 'NightclubEventController@searchDisabledNightClubEvent']);
Route::any('nightclub/searchDeal',['middleware' => 'checkRole', 'roles' => ['club admin','admin','deal admin'], 'uses' => 'NightclubDealController@searchNightClubDeal']);
Route::any('nightclub/searchDisabledDeal',['middleware' => 'checkRole', 'roles' => ['club admin','admin','deal admin'], 'uses' => 'NightclubDealController@searchDisabledNightClubDeal']);
Route::post('nightclub/uploadEventMultipleImages',['middleware' => 'checkRole', 'roles' => ['club admin','admin','event admin'], 'uses' => 'NightclubEventController@uploadEventMultipleImages']);
Route::get('nightclub/deleteEventImages',['middleware' => 'checkRole', 'roles' => ['club admin','admin','event admin'], 'uses' => 'NightclubEventController@deleteEventImages']);

//Club Check-in Report
//Route::get('nightclub/nightclubCheckIn/viewCheckInHistory',['middleware' => 'checkRole', 'roles' => ['club admin','event admin'], 'uses' => 'NightclubCheckInController@viewCheckInHistory']);
Route::any('nightclub/nightclubCheckIn/getCheckInHistory',['middleware' => 'checkRole', 'roles' => ['club admin','event admin'], 'uses' => 'NightclubCheckInController@getCheckInHistory']);

//Frequent Visitor Report
//Route::get('nightclub/nightclubCheckIn/viewTotalVisits',['middleware' => 'checkRole', 'roles' => ['club admin','event admin'], 'uses' => 'NightclubCheckInController@viewTotalVisits']);
Route::any('nightclub/nightclubCheckIn/getTotalVisits',['middleware' => 'checkRole', 'roles' => ['club admin','event admin'], 'uses' => 'NightclubCheckInController@getTotalVisits']);

//Suburb Report
Route::get('nightclub/nightclubCheckIn/viewTotalVisitorsBySuburbs',['middleware' => 'checkRole', 'roles' => ['club admin','event admin'], 'uses' => 'NightclubCheckInController@viewTotalVisitorsBySuburbs']);
Route::any('nightclub/nightclubCheckIn/getTotalVisitorsBySuburbs',['middleware' => 'checkRole', 'roles' => ['club admin','event admin'], 'uses' => 'NightclubCheckInController@getTotalVisitorsBySuburbs']);

//Average Time of Entry
//Route::get('nightclub/nightclubCheckIn/viewAverageVisitReports',['middleware' => 'checkRole', 'roles' => ['club admin','event admin'], 'uses' => 'NightclubCheckInController@viewAverageVisitReports']);
Route::any('nightclub/nightclubCheckIn/getAverageVisitTime',['middleware' => 'checkRole', 'roles' => ['club admin','event admin'], 'uses' => 'NightclubCheckInController@getAverageVisitTime']);


Route::get('nightclub/logout',function(){
    Auth::logout();
    return Redirect::to('auth/login');
});

Route::controllers([
	'auth' => 'Auth\AuthController',
	'password' => 'Auth\PasswordController',
]);

/*
 * Web-services
 */
Route::post('/service/testing/sendNotification', 'Webservices\TestingController@sendNotification');

Route::post('/service/user/signup', 'Webservices\UserController@signup');
Route::post('/service/user/signin', 'Webservices\UserController@signin');
Route::post('/service/user/signinFb', 'Webservices\UserController@signinFb');
Route::post('/service/user/validateEmail', 'Webservices\UserController@validateEmail');
Route::post('/service/user/updateProfile', 'Webservices\UserController@updateProfile');
Route::post('/service/user/updateProfilePic', 'Webservices\UserController@updateProfilePic');
Route::post('/service/user/updateUserLocation', 'Webservices\UserController@updateUserLocation');
Route::post('/service/user/setOpenToChat', 'Webservices\UserController@setOpenToChat');
Route::post('/service/user/changePassword', 'Webservices\UserController@changePassword');
Route::post('/service/user/saveFilter', 'Webservices\UserController@saveFilter');
Route::post('/service/user/logout', 'Webservices\UserController@logout');
Route::post('/service/user/resetPassword', 'Webservices\UserController@resetPassword');
Route::post('/service/user/getProfile', 'Webservices\UserController@getProfile');
Route::post('/service/user/getFriendsProfile', 'Webservices\UserController@getFriendsProfile');
Route::post('/service/user/getByEmails', 'Webservices\UserController@getByEmails');
Route::post('/service/user/getByFacebookIds', 'Webservices\UserController@getByFacebookIds');
Route::post('/service/user/getFollowedClubs', 'Webservices\UserController@getFollowedClubs');
Route::post('/service/user/getFriendsNearBy', 'Webservices\UserController@getFriendsNearBy');
Route::post('/service/user/getMyFriends', 'Webservices\UserController@getMyFriends');
Route::post('/service/user/getStrangersNearBy', 'Webservices\UserController@getStrangersNearBy');
Route::post('/service/user/sendNotification', 'Webservices\UserController@sendNotification');
Route::post('/service/user/deactivateAccount', 'Webservices\UserController@deactivateUserAccount');
Route::post('/service/user/reportUser', 'Webservices\UserController@reportUser');
Route::post('/service/user/blockUser', 'Webservices\UserController@blockUser');
Route::post('/service/user/getFriendsOfFriend','Webservices\UserController@getFriendsOfFriend');
Route::post('/service/user/receiveNotification', 'Webservices\UserController@receiveNotification');


Route::post('/service/nightclub/getList', 'Webservices\NightclubController@getList');
Route::post('/service/nightclub/getClubDetails', 'Webservices\NightclubController@getClubDetails');
Route::post('/service/nightclub/createClub', 'Webservices\NightclubController@createClub');

Route::post('/service/nightclub/follow', 'Webservices\NightclubController@follow');
Route::post('/service/nightclub/unfollow', 'Webservices\NightclubController@unfollow');
Route::post('/service/nightclub/getFollowers', 'Webservices\NightclubController@getFollowers');
Route::post('/service/notification/getList', 'Webservices\NotificationController@getList');
Route::post('/service/user/getFriendNotification', 'Webservices\NotificationController@getFriendNotification');


Route::post('/service/friend/sendRequest', 'Webservices\FriendController@sendRequest');
Route::post('/service/friend/rejectFriend', 'Webservices\FriendController@rejectFriend');
Route::post('/service/friend/respond', 'Webservices\FriendController@respond');
Route::post('/service/friend/listSentRequests', 'Webservices\FriendController@listSentRequests');
Route::post('/service/friend/listReceivedRequests', 'Webservices\FriendController@listReceivedRequests');

Route::post('/service/venueType/getList','Webservices\VenueTypeController@getList');
Route::post('/service/user/userStatus','Webservices\UserStatusController@getUserStatus');
Route::post('/service/user/addUserStatus','Webservices\UserStatusController@addUserStatus');
Route::post('/service/user/deleteUserStatus','Webservices\UserStatusController@deleteUserStatus');
Route::post('/service/user/addUserGoingOutStatus','Webservices\UserStatusController@addUserGoingOutStatus');
Route::post('/service/user/updateNotAttendingStatus', 'Webservices\UserStatusController@updateNotAttendingStatus');
Route::get('/service/cron/sendPushNotification', 'Webservices\CronController@sendPushNotification');
Route::get('/service/cron/resetUserStatusToHistory', 'Webservices\CronController@resetUserStatusToHistory');
Route::post('/service/user/deleteUserGoingOutStatus', 'Webservices\UserStatusController@deleteUserGoingOutStatus');

/*
 * Web-services for testing
 */

Route::any('facebook/login',['middleware' => 'checkRole', 'roles' => ['club admin','event admin'], 'uses' => 'NightclubEventController@facebookLogin']);
Route::any('facebook/callback',['middleware' => 'checkRole', 'roles' => ['club admin','event admin'], 'uses' => 'NightclubEventController@facebookCallback']);
Route::any('facebook/importEventFromFacebook',['middleware' => 'checkRole', 'roles' => ['club admin','event admin'], 'uses' => 'NightclubEventController@importEventFromFacebook']);
