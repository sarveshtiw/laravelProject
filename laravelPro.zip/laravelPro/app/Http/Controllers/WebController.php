<?php namespace App\Http\Controllers;

use App\Models\NightclubCheckInHistory;
use App\Models\User;
use App\Models\Nightclub;
use App\Models\NightclubEvent;
use App\Models\NightclubDeal;
use App\Models\SuggestVenue;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use App\Http\Middleware\Pagination;
use \Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Pagination\Paginator;
use Illuminate\Database\Eloquent\Model;
use App\Models\ClubOwnerRequest;
use App\Models\clubOwnerMessages;
use DB;

class WebController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Web Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders your application's "website" 
	|
	*/

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		//$this->middleware('auth');
	}

	/**
	 * Show the application dashboard to the user.
	 *
	 * @return Response
	 */
	public function index()
	{
		return view('landing');
	}
}
