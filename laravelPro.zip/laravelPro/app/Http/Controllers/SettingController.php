<?php namespace App\Http\Controllers;

use App\Models\NightclubCheckInHistory;
use App\Models\User;
use App\Models\Nightclub;
use App\Models\NightclubEvent;
use App\Models\NightclubDeal;
use App\Models\SuggestVenue;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use App\Http\Middleware\Pagination;
use \Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Pagination\Paginator;
use Illuminate\Database\Eloquent\Model;
use App\Models\TermAndCondition;

class SettingController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Home Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders your application's "dashboard" for users that
	| are authenticated. Of course, you are free to change or remove the
	| controller as you wish. It is just here to get your app started!
	|
	*/

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->middleware('auth');
	}

	/**
	 * Show the application dashboard to the user.
	 *
	 * @return Response
	 */
	public function viewTerms()
	{
		$terms = TermAndCondition::find(1);
		return view('termsAndConditions')->with('terms',$terms);
	}

	public function editTerms(){
		$terms = TermAndCondition::find(1);
		return view('termsAndConditionsEdit')->with('terms',$terms); 
	}

	public function updateTerms(){
		$terms = input::all();
        $rules = array(
            'id' => array('required','numeric'),
            'description'=> array('required')
        );
        $validator = Validator::make($terms, $rules);
        if ($validator->fails()) {
            return Redirect::to('setting/editTerms/'.$terms['id'])->with('terms',$terms)->withErrors($validator);
        } else {
			$term = TermAndCondition::find($terms['id']);
			if (isset($terms['description']) && !empty($terms['description']))
                $term->description = htmlspecialchars($terms['description']);

			$term->save();
		}
		return Redirect::to('setting/editTerms/'.$terms['id'])->with('terms',$terms)->with('flash_message', 'Term & Conditions Updated Successfully.'); 
	}
}
