<?php namespace App\Http\Controllers;

use App\Models\NightclubCheckInHistory;
use App\Models\User;
use App\Models\Nightclub;
use App\Models\NightclubEvent;
use App\Models\NightclubDeal;
use App\Models\SuggestVenue;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use App\Http\Middleware\Pagination;
use \Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Pagination\Paginator;
use Illuminate\Database\Eloquent\Model;
use App\Models\ClubOwnerRequest;
use App\Models\clubOwnerMessages;
use DB;

class HomeController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Home Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders your application's "dashboard" for users that
	| are authenticated. Of course, you are free to change or remove the
	| controller as you wish. It is just here to get your app started!
	|
	*/

	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->middleware('auth');
	}

	/**
	 * Show the application dashboard to the user.
	 *
	 * @return Response
	 */
	public function index()
	{
		if(\Auth::user()->role == 'admin')
		{
			$userCount 			   = User::where('role','user')->where('isDisabled',0)->count();
			$nightClubCount  	   = Nightclub::where('isDisabled',0)->count();

            $nightClubEventCount = DB::table('nightclubEvent as ne')
                            ->join('nightclub as n ', 'n.id', '=', 'ne.nightclubId')
                            ->select('ne.*','n.nightclubName')
                            ->where('ne.isDisabled',0)
                            ->whereRaw("ne.endDateTime >= NOW()")
                            ->count();

            $nightClubDealCount = DB::table('nightclubDeal as nd')
	                            ->join('nightclub as n ', 'n.id', '=', 'nd.nightclubId')
	                            ->select('nd.*','n.nightclubName')
	                            ->where('nd.isDisabled',0)
	                            ->whereRaw("nd.endDateTime >= NOW()")
	                            ->count();   
	        $clubOwnerRequestCount = ClubOwnerRequest::get()->count();
			$suggestedVenuesCount  = SuggestVenue::count();
			return view('home')
							->with('userCount',$userCount)
							->with('nightClubCount',$nightClubCount)
							->with('nightClubEventCount',$nightClubEventCount)
							->with('nightClubDealCount',$nightClubDealCount)
							->with('suggestedVenuesCount',$suggestedVenuesCount)
							->with('clubOwnerRequestCount',$clubOwnerRequestCount);	              
		}
		elseif(\Auth::user()->role == 'club admin')
		{
			$adminCount 		   = User::where('role','event admin')->where('role','deal admin')->where('nightclubId',\Auth::user()->nightclubId)->where('isDisabled',0)->count();
			$nightClubCount  	   = Nightclub::where('isDisabled',0)->count();

			$nightClubEventCount = DB::table('nightclubEvent as ne')
                            ->join('nightclub as n ', 'n.id', '=', 'ne.nightclubId')
                            ->select('ne.*','n.nightclubName')
                            ->where('ne.isDisabled',0)
                            ->where('nightclubId','=',\Auth::user()->nightclubId)
                            ->whereRaw("ne.endDateTime >= NOW()")
                            ->count();

            $nightClubDealCount = DB::table('nightclubDeal as nd')
				                ->join('nightclub as n ', 'n.id', '=', 'nd.nightclubId')
				                ->select('nd.*','n.nightclubName')
				                ->where('nightclubId','=',\Auth::user()->nightclubId)
				                ->where('nd.isDisabled',0)
				                ->whereRaw("nd.endDateTime >= NOW()")
				                ->count();  

			$clubOwnerRequestCount = ClubOwnerRequest::get()->count();
			$suggestedVenuesCount  = SuggestVenue::count();
			return view('home')
							->with('adminCount',$adminCount)
							->with('nightClubCount',$nightClubCount)
							->with('nightClubEventCount',$nightClubEventCount)
							->with('nightClubDealCount',$nightClubDealCount)
							->with('suggestedVenuesCount',$suggestedVenuesCount)
							->with('clubOwnerRequestCount',$clubOwnerRequestCount);	           
		}
		else {
			return view('home');
		}
	}

}
