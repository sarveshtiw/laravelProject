<?php namespace App\Http\Controllers;

use DB;
class TermController extends Controller {

	/*
	|--------------------------------------------------------------------------
	| Term Controller
	|--------------------------------------------------------------------------
	|
	| This controller renders your application's "dashboard" for users that
	| are authenticated. Of course, you are free to change or remove the
	| controller as you wish. It is just here to get your app started!
	|
	*/

	/**
	 * Show the application terms & conditions page.
	 *
	 * @return Response
	 */
	public function index()
	{
		$termsData = DB::table('termAndCondition')->first();
		return view('pages.terms')->with('termsData',$termsData);
	}

	/**
	 * Show the application dashboard to the user.
	 *
	 * @return Response
	 */
	public function privacy()
	{
		return view('pages.privacy_policy');
	}

	
}
