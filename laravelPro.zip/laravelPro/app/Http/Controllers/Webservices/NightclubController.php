<?php namespace App\Http\Controllers\Webservices;

use \Illuminate\Support\Facades\Request;
use \Illuminate\Support\Facades\Response;
use \Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use App\Http\Middleware\VkUtility;
use App\Models\User;
use App\Models\UserStatusHistory;
use App\Models\Notification;
use App\Models\Friend;
use App\Models\UserSession;
use App\Models\Nightclub;
use App\Models\NightclubCheckIn;
use App\Models\NightclubEvent;
use App\Models\NightclubFollower;
use App\Models\SuggestVenue;
use DB;

class NightclubController extends Controller {

    /*
    |--------------------------------------------------------------------------
    | Nightclub Controller
    |--------------------------------------------------------------------------
    |
    | This controller provides services to process nightclub records
    |
    */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }

    /**
     * Return list of all nightclubs sorted by distance
     *
     * @return Response
     */
    public function getList()
    {
        $apiName = 'nightclub/getList';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'nearMe' => array('required', 'numeric', 'in:0,1'),
            'latitude' => array('numeric'),
            'longitude' => array('numeric'),
            'location' => array('string'),
            'venueType' => array('string'),
            'subVenueType' => array('string'),
            'dressCode' => array('string'),
            'musicGenre' => array('string'),
            'budget' => array('numeric'),
            'popularity' => array('string'),
            'maxDistance' => array('numeric'),
            'searchText' => array('string'),
            'sortBy' => array('in:location,distance,budget'),
            'myClubs' => array('string'),
            'exceptions' => array('array')
        );
        
        if(!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else
        {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) 
            {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            }
            else if(is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first()))
            {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            }
            else
            {
                $nearMe = 0;
                $latitude = 0;
                $longitude = 0;
                $location = '';
                $venueType = ''; 
                $dressCode = ''; 
                $musicGenreString = '';
                $subMusicGenreString = '';
                $budget = 0;
                $popularity = '';
                $maxDistance = 0;
                $sortBy = 'iFollowIt DESC, distance ASC';
                $searchText = '';
                $exceptions = '';
                $venuTypeArray = [];
                $userId = 0;
                $myClubs = 0;
                $venuTypeString = '';
                $subVenueTypeString = '';
                
                $nearMe = filter_var($_JSON['nearMe'], FILTER_SANITIZE_NUMBER_INT);
                if(isset($_JSON['myClubs']) && !empty($_JSON['myClubs']))
                    $myClubs = filter_var($_JSON['myClubs'], FILTER_SANITIZE_NUMBER_INT);
                
                if(isset($_JSON['latitude']) && !empty($_JSON['latitude']))
                    $latitude = filter_var ($_JSON['latitude'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
                
                if(isset($_JSON['longitude']) && !empty($_JSON['longitude']))
                    $longitude = filter_var ($_JSON['longitude'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
                
                if(isset($_JSON['location']) && !empty($_JSON['location']))
                    $location = filter_var ($_JSON['location'], FILTER_SANITIZE_STRING);
                
                if(isset($_JSON['venueType']) && !empty($_JSON['venueType'])){
                    $venueType = filter_var ($_JSON['venueType'], FILTER_SANITIZE_STRING);
                    $venuTypeArray = explode(',', $venueType);
                    $venuTypeString = implode(',',array_map(function($el){ return "'".$el."'"; }, $venuTypeArray));
                }

                if(isset($_JSON['subVenueType']) && !empty($_JSON['subVenueType'])){
                    $subVenueType = filter_var ($_JSON['subVenueType'], FILTER_SANITIZE_STRING);
                    $subVenueTypeArray = explode(',', $subVenueType);
                    $subVenueTypeString = implode(',',array_map(function($el){ return "'".$el."'"; }, $subVenueTypeArray));
                }
                
                if(isset($_JSON['dressCode']) && !empty($_JSON['dressCode']))
                    $dressCode = filter_var ($_JSON['dressCode'], FILTER_SANITIZE_STRING);
                
                // if(isset($_JSON['musicGenre']) && !empty($_JSON['musicGenre']))
                //     $musicGenre = filter_var ($_JSON['musicGenre'], FILTER_SANITIZE_STRING);

                if(isset($_JSON['musicGenre']) && !empty($_JSON['musicGenre'])){
                    $musicGenre = filter_var ($_JSON['musicGenre'], FILTER_SANITIZE_STRING);
                    $musicGenreArray = explode(',', $musicGenre);
                    $musicGenreString = implode(',',array_map(function($el){ return "'".$el."'"; }, $musicGenreArray));
                }

                if(isset($_JSON['subMusicGenre']) && !empty($_JSON['subMusicGenre'])){
                    $subMusicGenre = filter_var ($_JSON['subMusicGenre'], FILTER_SANITIZE_STRING);
                    $subMusicGenreArray = explode(',', $subMusicGenre);
                    $subMusicGenreString = implode(',',array_map(function($el){ return "'".$el."'"; }, $subMusicGenreArray));
                }
                
                if(isset($_JSON['budget']) && !empty($_JSON['budget']))
                    $budget = filter_var ($_JSON['budget'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
                
                if(isset($_JSON['popularity']) && !empty($_JSON['popularity']))
                    $popularity = filter_var ($_JSON['popularity'], FILTER_SANITIZE_STRING);
                                
                if(isset($_JSON['maxDistance']) && !empty($_JSON['maxDistance']))
                    $maxDistance = filter_var ($_JSON['maxDistance'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
                
                if(isset($_JSON['searchText']) && !empty($_JSON['searchText']))
                    $searchText = filter_var ($_JSON['searchText'], FILTER_SANITIZE_STRING);
                
                if(isset($_JSON['sortBy']) && !empty($_JSON['sortBy']))
                    $sortBy = filter_var ($_JSON['sortBy'], FILTER_SANITIZE_STRING);
                                
                if(isset($_JSON['exceptions']) && !empty($_JSON['exceptions']))
                    $exceptions = join(',', $_JSON['exceptions']);
                
                $userId = $userSession->userId;
                $nightclubs = Nightclub::getList($nearMe, $latitude, $longitude, $location, $venuTypeString, $dressCode, $musicGenreString, $budget, $popularity, $maxDistance, $sortBy, $exceptions, $searchText, $userId, $myClubs, $subVenueTypeString, $subMusicGenreString);
                
                //Get Night Club Followers
                $clubCount = 0;
                foreach($nightclubs as $nightclub){

                    $nightclubCheckins = NightclubCheckIn::getListByNightclubId($nightclub->id, $searchText, $exceptions, $userId); 
                    $nightclubs[$clubCount]->nightclubCheckins = $nightclubCheckins;
                    $nightclubs[$clubCount++]->nightclubCheckinsCount = count(NightclubCheckIn::getListByNightclubId($nightclub->id, $searchText, '', $userId)); 
                    //DB::table('nightclubCheckIn')->where('nightclubId',$nightclub->id)->whereNotIn('userId',array($userId))->count();
                }
                $result = VkUtility::success($apiName, 'Records fetched successfully');
                $result['nightclubs'] = $nightclubs;
            }
        }
        //return Response::json($result);
        return Response::json($result)->header("Connection","close");
    }
    
    /**
     * Return details of a nightclub
     *
     * @return Response
     */
    public function getClubDetails()
    {
        $apiName = 'nightclub/getClubDetails';
        $userSession = null;
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'nightclubId' => array('required'),
            'latitude' => array('numeric'),
            'longitude' => array('numeric')
        );
        
        if(!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else
        {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) 
            {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            }
            else if(is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first()))
            {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            }
            else
            {
                $nearMe = 0;
                $latitude = 0;
                $longitude = 0;
                $location = '';
                $venueType = ''; 
                $dressCode = ''; 
                $musicGenre = '';
                $budget = 0;
                $popularity = '';
                $maxDistance = 3;
                $sortBy = 'distance';
                $exceptions = '';
                $latitude = 0;
                $longitude = 0;
                $nightclubId = $_JSON['nightclubId'];
                $userId = $userSession['userId'];
                
                if(isset($_JSON['latitude']) && !empty($_JSON['latitude']))
                    $latitude = filter_var ($_JSON['latitude'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
                
                if(isset($_JSON['longitude']) && !empty($_JSON['longitude']))
                    $longitude = filter_var ($_JSON['longitude'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
                
                $nightclub = Nightclub::getById($nightclubId, $latitude, $longitude, $userId);
                if(is_null($nightclub) || empty($nightclub))
                    $result = VkUtility::error($apiName, 99, 'No data exist for selected nightclub.');
                else
                {
                    $checkIns = User::getCheckedInUsers($userId,$nightclubId);
                  
                    $nightclub->checkIns = $checkIns;
                    $nightclub->checkInCount = count($checkIns);
                    
                    $result = VkUtility::success($apiName, 'Records fetched successfully');
                    $result['nightclub'] = $nightclub;
                }
            }
        }
        //return Response::json($result);
        return Response::json($result)->header("Connection","close");
    }
    
    /**
     * Create a nightculb record
     *
     * @return Response
     */
    public function createClub()
    {
        $apiName = 'nightclub/createClub';
        
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'name' => array('required', 'string'),
            'location' => array('required'),
            'briefInfo' => array('required', 'string'),
            'barType' => array('string'),
            'venueType' => array('string'),
            'dressCode' => array('string'),
            'musicGenre' => array('string'),
            'budget' => array('numeric'),
            'popularity' => array('required', 'integer', 'between:1,10'),
            'facebookLink' => array('required'),
            'twitterLink' => array('required'),
            'instagramLink' => array('required'),
            'weekdayOpeningTime' => array('required'),
            'weekdayClosingTime' => array('required'),
            'weekendOpeningTime' => array('required'),
            'weekendClosingTime' => array('required')
        );
        
        if(!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else
        {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) 
            {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            }
            else
            {
                $nightclub = new Nightclub();
                $nightclub->nightclubName = $_JSON['name'];
                $nightclub->budget = $_JSON['budget'];
                $nightclub->popularity = $_JSON['popularity'];
                $nightclub->weekdayOpeningTime = $_JSON['weekdayOpeningTime'];
                $nightclub->weekdayClosingTime = $_JSON['weekdayClosingTime'];
                $nightclub->weekendOpeningTime = $_JSON['weekendOpeningTime'];
                $nightclub->weekendClosingTime = $_JSON['weekendClosingTime'];
                $nightclub->facebookLink = $_JSON['facebookLink'];
                $nightclub->twitterLink = $_JSON['twitterLink'];
                $nightclub->instagramLink = $_JSON['instagramLink'];
                
                if(isset($_JSON['briefInfo']) && !empty($_JSON['briefInfo']))
                    $nightclub->briefInfo = $_JSON['briefInfo'];
                
                if(isset($_JSON['barType']) && !empty($_JSON['barType']))
                    $nightclub->barType = $_JSON['barType'];
                
                if(isset($_JSON['venueType']) && !empty($_JSON['venueType']))
                    $nightclub->venueType = $_JSON['venueType'];
                
                if(isset($_JSON['dressCode']) && !empty($_JSON['dressCode']))
                    $nightclub->dressCode = $_JSON['dressCode'];
                
                if(isset($_JSON['musicGenre']) && !empty($_JSON['musicGenre']))
                    $nightclub->musicGenre = $_JSON['musicGenre'];
                
               if(isset($_JSON['location']) && !empty($_JSON['location']))
                {
                    $locationComponents = VkUtility::getLocationFromPostcode($_JSON['location']);
                    $nightclub->latitude = $locationComponents['latitude'];
                    $nightclub->longitude = $locationComponents['longitude'];
                    $nightclub->location = $locationComponents['formattedAddress'];
                }
                
                if(isset($_JSON['coverImage']) && !empty($_JSON['coverImage']))
                {
                    $imageDir = public_path() . config('constants.nightclubCoverImage');
                    $thumbDir = public_path() . config('constants.nightclubCoverThumb');
                    $maxWidth = config('constants.thumbMaxWidth');
                    $nightclub->coverImage = VkUtility::saveBase64ImagePng($_JSON['coverImage'], $imageDir, $thumbDir, $maxWidth);
                }
                if(isset($_JSON['logo']) && !empty($_JSON['logo']))
                {
                    $imageDir = public_path() . config('constants.nightclubLogoImage');
                    $thumbDir = public_path() . config('constants.nightclubLogoThumb');
                    $maxWidth = config('constants.thumbMaxWidth');
                    $nightclub->logo = VkUtility::saveBase64ImagePng($_JSON['logo'], $imageDir, $thumbDir, $maxWidth);
                }
                
                $nightclub->save();
                
                $result = VkUtility::success($apiName, 'Club Created Successfully');
                $result['nightclub'] = Nightclub::getById($nightclub->id, 1);
            }
        }
        //return Response::json($result);
        return Response::json($result)->header("Connection","close");
    }

    /**
     * Follow a nightclub
     *
     * @return Response
     */
    public function follow()
    {
        $apiName = 'nightclub/follow';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'nightclubId' => array('required', 'integer')
        );
        
        $userSession = null;
        $nightclub = null;
        
        if(!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else
        {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) 
            {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            }
            else if(is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first()))
            {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            }
            else if(is_null($nightclub = Nightclub::where('id', '=', $_JSON['nightclubId'])->first()))
            {
                $result = VkUtility::error($apiName, 99, 'Selected nightclub does not exist.');
            }
            else
            {
                $notificationMessage = '';
                $nightclubFollower = new NightclubFollower();
                $nightclubFollower->nightclubId = $nightclub->id;
                $nightclubFollower->userId = $userSession->userId;
                
                $nightclubFollower->save();
                
                $nightclub->followerCount = $nightclub->followerCount + 1;
                $nightclub->save();
                
                $user = User::where('id', '=', $userSession->userId)->first();
                $user->nightclubFollowCount += 1;
                $user->save();

                // Make User Status for Following club
                $userStatusHistory = new UserStatusHistory();

                $userStatusHistory->userId = $user->id;
                $userStatusHistory->statusMessage = "You are following ".$nightclub->nightclubName;
                $userStatusHistory->save();
                //Send notification to All  Friends.

                $userFriendList = Friend::getFriendIds($userSession->userId);
                $userFriendDataList = explode(',',$userFriendList);
                if(strlen($userFriendList)>0){
                    foreach($userFriendDataList as $userFriend){
                        // Saved Notification
                        $notification = new Notification();
                        $notification->senderUserId = $userSession->userId;
                        $notification->receiverUserId = $userFriend;
                        $notification->message = $user->firstName.' '. $user->surName." is following ".$nightclub->nightclubName;
                        $notification->notificationType = 8;
                        $notificationMessage = $user->firstName.' '. $user->surName." is following ".$nightclub->nightclubName;
                        $notification->isSent = 0;
                        $notification->save();
                    }
                }

                $result = VkUtility::success($apiName, 'Nightclub followed successfully');
            }
        }
        //return Response::json($result);
        return Response::json($result)->header("Connection","close");
    }

    /**
     * Unfollow a nightclub
     *
     * @return Response
     */
    public function unfollow()
    {
        $apiName = 'nightclub/unfollow';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'nightclubId' => array('required', 'integer')
        );
        
        $userSession = null;
        $nightclub = null;
        $nightclubFollower = null;
        
        if(!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else
        {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) 
            {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            }
            else if(is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first()))
            {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            }
            else if(is_null($nightclub = Nightclub::where('id', '=', $_JSON['nightclubId'])->first()))
            {
                $result = VkUtility::error($apiName, 99, 'Selected nightclub does not exist.');
            }
            else if(is_null($nightclubFollower = NightclubFollower::where('nightclubId', '=', $_JSON['nightclubId'])->where('userId', '=', $userSession->userId)->first()))
            {
                $result = VkUtility::error($apiName, 99, 'You do not follow the selected nightculb.');
            }
            else
            {
                $nightclubFollower->delete();
                
                $nightclub->followerCount = $nightclub->followerCount - 1;
                $nightclub->save();
                
                $user = User::where('id', '=', $userSession->userId)->first();
                $user->nightclubFollowCount = $user->nightclubFollowCount - 1;
                $user->save();
                
                $result = VkUtility::success($apiName, 'Nightclub unfollowed successfully');
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * get list of nightclub followers
     *
     * @return Response
     */
    public function getFollowers()
    {
        $apiName = 'nightclub/getFollowers';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'nightclubId' => array('required', 'integer')
        );
        
        $userSession = null;
        $nightclub = null;
        
        if(!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else
        {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) 
            {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            }
            else if(is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first()))
            {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            }
            else if(is_null($nightclub = Nightclub::where('id', '=', $_JSON['nightclubId'])->first()))
            {
                $result = VkUtility::error($apiName, 99, 'Selected nightclub does not exist.');
            }
            else
            {
                $nightclubFollowers = NightclubFollower::getList($nightclub->id);
                
                $result = VkUtility::success($apiName, 'Records fetched successfully.');
                $result['nightclubFollowers'] = $nightclubFollowers;
            }
        }
        return Response::json($result)->header("Connection","close");
    }
    
    
}
