<?php namespace App\Http\Controllers\Webservices;

use \Illuminate\Support\Facades\Request;
use \Illuminate\Support\Facades\Response;
use \Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use App\Http\Middleware\VkUtility;
use App\Http\Middleware\VkXmpp;
use App\Models\User;
use App\Models\UserSession;
use \Illuminate\Support\Facades\Mail;

class TestingController extends Controller {

    /**
     * Register a user on xmpp
     *
     * @return Response
     */
    public function signupXmpp()
    {
        $apiName = 'testing/signupXmpp';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'userName' => array('required', 'string'),
            'password' => array('required', 'string')
        );
        
        if(!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else
        {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) 
            {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            }
            else
            {
                $response = VkXmpp::registerUser($_JSON['userName'], $_JSON['password']);
                if($response['res'] == 1)   //error
                    $result = VkUtility::error($apiName, 99, $response['text']);        //error message
                else
                    $result = VkUtility::success($apiName, $response['text']);
            }
        }
        return Response::json($result)->header("Connection","close");
    }
    
    /**
     * Using ejabberd_xmlrpc
     *
     * @return Response
     */
    public function getUserResources()
    {
//        $param_auth = array("user"=>"admin", "server"=>"localhost", "password"=>"password");
//        $param_comm = array("user"=>"testuser", "host"=>"localhost");
//        $param = array($param_auth, $param_comm);
        
        
        $param=array("host"=>"appster-mbp-vikas-gupta.local");
        $request = xmlrpc_encode_request('registered_users', $param, (array('encoding' => 'utf-8')));

        $context = stream_context_create(array('http' => array(
            'method' => "POST",
            'header' => "User-Agent: XMLRPC::Client mod_xmlrpc\r\n" .
                        "Content-Type: text/xml\r\n" .
                        "Content-Length: ".strlen($request),
            'content' => $request
        )));
        
        $file = file_get_contents("http://127.0.0.1:4560/RPC2", false, $context);

        $response = xmlrpc_decode($file);

        if (xmlrpc_is_fault($response)) {
            trigger_error("xmlrpc: $response[faultString] ($response[faultCode])");
        } else {
            print_r($response);
        }
    }
    
    /**
     * test push notification
     *
     * @return Response
     */
    public function sendNotification()
    {
        $apiName = 'testing/sendNotification';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'deviceToken' => array('required', 'string')
        );
        
        if(!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else
        {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) 
            {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            }
            else
            {
                $deviceToken = filter_var($_JSON['deviceToken'], FILTER_SANITIZE_STRING);
                $message = 'test notification';
                $deviceBadge = 1;
                $data = array('key'=>'value');
                VkUtility::sendApnsNotification($deviceToken, $message, $deviceBadge, $data);
                
                $result = VkUtility::success($apiName, 'notification sent');
            }
        }
        return Response::json($result);
    }
}
