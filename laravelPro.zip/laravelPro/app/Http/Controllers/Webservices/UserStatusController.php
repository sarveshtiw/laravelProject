<?php

namespace App\Http\Controllers\Webservices;

use \Illuminate\Support\Facades\Request;
use \Illuminate\Support\Facades\Response;
use \Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use App\Http\Middleware\VkUtility;
use App\Http\Middleware\VkXmpp;
use App\Models\User;
use App\Models\Friend;
use App\Models\Notification;
use App\Models\Nightclub;
use App\Models\NightclubCheckIn;
use App\Models\NightclubCheckInHistory;
use App\Models\NightclubFollower;
use App\Models\UserSession;
use App\Models\UserStatusHistory;
use App\Models\UserStatusFriends;
use App\Models\ReportUser;
use App\Models\BlockUser;
use \App\Models\TaggedUser;
use \Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;

class UserStatusController extends Controller {
    /*
      |--------------------------------------------------------------------------
      | User Status Controller
      |--------------------------------------------------------------------------
      |
      | This controller provides services to process user records
      |
     */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        
    }

    public function addUserStatus() {
        $apiName = 'user/addUserStatus';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'statusMessage' => array('required','string'),
            'taggedImage' => array(),
            'taggedVenue' => array('string'),
            'taggedVenueId' => array('numeric'),
            'taggedFriends' => array('array')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first();
                if (is_null($userSession))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else {

                    $user = User::where('id', '=', $userSession->userId)->first();
                    if (is_null($user))
                        $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                    else {
                        $taggedVenueId = 0;
                        $userStatusFriendsList = array();
                        $taggedFriendsList = array();
                        $userStatusHistory = new UserStatusHistory();
                        $userStatusHistory->userId = $user->id;

                        $message = "You posted the following: ";
                        if(isset($_JSON['statusMessage']) && !empty($_JSON['statusMessage']))
                            $userStatusHistory->statusMessage = $message.base64_decode(filter_var ($_JSON['statusMessage'], FILTER_SANITIZE_STRING));

                        if(isset($_JSON['taggedVenue']) && !empty($_JSON['taggedVenue']))
                            $userStatusHistory->taggedVenue = filter_var ($_JSON['taggedVenue'], FILTER_SANITIZE_STRING);
                        else
                            $userStatusHistory->taggedVenue = '';

                        if(isset($_JSON['taggedFriends']) && !empty($_JSON['taggedFriends'])){
                            $taggedFriendsList =  $_JSON['taggedFriends'];
                            $userFriendData = User::where('id', '=', $taggedFriendsList[0])->first();

                            if(count($taggedFriendsList)>1){
                                $userStatusFriendsListCount = count($taggedFriendsList) - 1;
                                $userStatusHistory->statusMessage .= " with @". $userFriendData->firstName.' '. $userFriendData->surName.' +'.$userStatusFriendsListCount ." others";
                            }
                            else 
                                $userStatusHistory->statusMessage .= " with @". $userFriendData->firstName.' '. $userFriendData->surName;
                        }
                        
                        if(isset($_JSON['taggedVenueId']) && !empty(isset($_JSON['taggedVenueId'])))
                            $userStatusHistory->taggedVenueId =  filter_var ($_JSON['taggedVenueId'], FILTER_SANITIZE_NUMBER_INT);

                        if (isset($_JSON['taggedImage']) && !empty($_JSON['taggedImage'])) {
                            $imageDir = public_path() . config('constants.userstatusImage');
                            $thumbDir = public_path() . config('constants.userstatusThumbImage');
                            $maxWidth = config('constants.thumbMaxWidth');

                            $userStatusHistory->taggedImage = VkUtility::saveBase64ImagePng($_JSON['taggedImage'], $imageDir, $thumbDir, $maxWidth);
                        }
                        $userStatusHistory->save();
                        
                        
                        $count = 0;
                        if(count($taggedFriendsList) > 0) {
                            foreach($taggedFriendsList as $taggedFriend){
                                // Saved Tagged Friend Data
                                $userStatusFriends = new UserStatusFriends();
                                $userStatusFriends->userStatusId = $userStatusHistory->id;
                                $userStatusFriends->taggedFriends = $taggedFriend;
                                $userStatusFriends->save();

                                // Saved Notification
                                $notification = new Notification();
                                $notification->senderUserId = $userSession->userId;
                                $notification->receiverUserId = $taggedFriend;
                                $notification->message = $user->firstName.' '. $user->surName." posted the following: ".base64_decode(filter_var ($_JSON['statusMessage'], FILTER_SANITIZE_STRING)) ." and Tagged you.";
                                $notification->notificationType = 11; 
                                $notification->notificationImage = $userStatusHistory->taggedImage; 
                                $notification->save(); 
                            }
                        }

                        //Send notification to All not Tagged Friends.

                        $userFriendList = Friend::getFriendIds($userSession->userId);

                        $userFriendDataList = explode(',',$userFriendList);
                        if(strlen($userFriendList)>0){
                            foreach($userFriendDataList as $userFriend){
                                if(count($taggedFriendsList) > 0) {
                                    foreach($taggedFriendsList as $taggedFriend){
                                        if($userFriend!=$taggedFriend) {
                                            // Saved Notification
                                            $notification = new Notification();
                                            $notification->senderUserId = $userSession->userId;
                                            $notification->receiverUserId = $userFriend;
                                            $notification->message = $user->firstName.' '. $user->surName." posted the following: ".base64_decode(filter_var ($_JSON['statusMessage'], FILTER_SANITIZE_STRING)) ;
                                            $notification->notificationType = 13;
                                            $notification->nightclubId = $taggedVenueId;
                                            $notification->isSent = 1;
                                            $notification->notificationImage = $userStatusHistory->taggedImage; 
                                            $notification->save();
                                        }
                                    }
                                }
                                else 
                                {
                                    // Saved Notification
                                    $notification = new Notification();
                                    $notification->senderUserId = $userSession->userId;
                                    $notification->receiverUserId = $userFriend;
                                    $notification->message = $user->firstName.' '. $user->surName." posted the following: ".base64_decode(filter_var ($_JSON['statusMessage'], FILTER_SANITIZE_STRING)) ;
                                    $notification->notificationType = 13;
                                    $notification->nightclubId = $taggedVenueId;
                                    $notification->isSent = 1;
                                    $notification->notificationImage = $userStatusHistory->taggedImage; 
                                    $notification->save();
                                }
                            }
                        }
                        
                        $result = VkUtility::success($apiName, 'User Status Created Successfully');
                        $userStatus = UserStatusHistory::getById($userStatusHistory->id);
                        $userStatus->timeElapsed = '1s';
                        $userStatus->userStatusTaggedFriends = UserStatusFriends::getList($userStatusHistory->id);
                        $result['userStatus'] = $userStatus;
                    }
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * Get user status details by email addresses
     *
     * @return Response
     */
    public function getUserStatus() {
        $apiName = 'user/userStatus';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'userId' => array('required', 'numeric'),
            'exceptions' => array('array')
        );
        
        if(!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else
        {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) 
            {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            }
            else if(is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first()))
            {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            }
            else
            {
                
                $userId = filter_var($_JSON['userId'], FILTER_SANITIZE_NUMBER_INT);
                $exceptions = '';
                if(isset($_JSON['exceptions']) && !empty($_JSON['exceptions']))
                    $exceptions = join(',', $_JSON['exceptions']);

                $userStatusHistory = UserStatusHistory::getList($userId, $exceptions);
                
                //Get User Status Friends
                $count = 0;
                $taggedFriendsList = array();
                $userStatusFriends = new UserStatusFriends();
                foreach($userStatusHistory as $userStatus){
                    //Get User Status Friends
                    $userStatusFriendsData = $userStatusFriends::getList($userStatus->id);
                    $userStatus->timeElapsed = VkUtility::getTimeElapsedShort(date_create($userStatus->createDate), date_create());
                    $userStatusHistory[$count++]->userStatusTaggedFriends = $userStatusFriendsData;
                }

                $result = VkUtility::success($apiName, 'Records fetched successfully');
                $result['userStatus'] = $userStatusHistory;
            }
        }
        //return Response::json($result);
        return Response::json($result)->header("Connection","close");
    }


    public function addUserGoingOutStatus() {
        $apiName = 'user/addUserGoingOutStatus';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'statusMessage' => array('string'),
            'taggedImage' => array(),
            'taggedVenue' => array('string'),
            'taggedVenueId' => array('numeric'),
            'taggedFriends' => array('array'),
            'notificationId' => array('numeric')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first();
                if (is_null($userSession))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else {

                    $user = User::where('id', '=', $userSession->userId)->first();
                    if (is_null($user))
                        $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                    else {

                        $nightclub = Nightclub::where('id',  $_JSON['taggedVenueId'])->where('isDisabled',0)->first();
                        if(is_null($nightclub) || empty($nightclub)){
                            $result = VkUtility::error($apiName, 99, 'No data exist for selected nightclub.');
                        } else {

                            $message = "You posted the following: ";

                            $taggedVenueId  = 0;
                            $userTaggedFriendsList = array();
                            $userStatusHistory = new UserStatusHistory();

                            $userStatusHistory->userId = $user->id;
                            if(isset($_JSON['statusMessage']) && !empty($_JSON['statusMessage']))
                                $userStatusHistory->statusMessage = "You set your status to going out at @".filter_var ($_JSON['taggedVenue'], FILTER_SANITIZE_STRING)." and posted the following: ".base64_decode(filter_var ($_JSON['statusMessage'], FILTER_SANITIZE_STRING));
                            else
                                $userStatusHistory->statusMessage = "You set your status to going out to @".filter_var ($_JSON['taggedVenue'], FILTER_SANITIZE_STRING);

                            if(isset($_JSON['taggedVenue']) && !empty($_JSON['taggedVenue'])){
                                $userStatusHistory->taggedVenue = filter_var ($_JSON['taggedVenue'], FILTER_SANITIZE_STRING);
                            }
                            else
                                $userStatusHistory->taggedVenue = '';

                            if(isset($_JSON['taggedVenueId']) && !empty(isset($_JSON['taggedVenueId']))){
                                $taggedVenueId =  filter_var($_JSON['taggedVenueId'], FILTER_SANITIZE_NUMBER_INT);
                                $userStatusHistory->taggedVenueId = $taggedVenueId;
                                
                                //Get Last Check in Data
                                $nightclubCheckIn = NightclubCheckIn::where('userId',$userSession->userId)->get();

                                //Delete Last Checked in
                                NightclubCheckIn::where('userId',$userSession->userId)->delete();

                                //Add Last Checked in Data to Checked in History
                                if(count($nightclubCheckIn)>0){
                                    foreach($nightclubCheckIn as $checkinData){
                                        $nightclubCheckInHistory = new NightclubCheckInHistory();
                                        $nightclubCheckInHistory->nightclubId = $checkinData->nightclubId;
                                        $nightclubCheckInHistory->userId = $checkinData->userId;
                                        $nightclubCheckInHistory->checkInDateTime = $checkinData->createDate;
                                        $nightclubCheckInHistory->checkOutDatetIme = date('Y-m-d H:i:s');
                                        $nightclubCheckInHistory->save();
                                    }
                                }

                                //User Current Club Checked in
                                $nightclubCheckIn = new NightclubCheckIn();
                                $nightclubCheckIn->nightclubId = $taggedVenueId;
                                $nightclubCheckIn->userId = $userSession->userId;      
                                $nightclubCheckIn->save();                      
                            }  

                            if(isset($_JSON['taggedFriends']) && !empty($_JSON['taggedFriends'])){
                                $userTaggedFriendsList =  $_JSON['taggedFriends'];
                                $userFriendData = User::where('id', '=', $userTaggedFriendsList[0])->first();

                                if(count($userTaggedFriendsList)>1){
                                    $userStatusFriendsListCount = count($userTaggedFriendsList) - 1;
                                    $userStatusHistory->statusMessage .= " with @". $userFriendData->firstName.' '. $userFriendData->surName.' +'.$userStatusFriendsListCount ." others";
                                }
                                else 
                                    $userStatusHistory->statusMessage .= " with @". $userFriendData->firstName.' '. $userFriendData->surName;
                            }

                            if (isset($_JSON['taggedImage']) && !empty($_JSON['taggedImage'])) {
                                $imageDir = public_path() . config('constants.userstatusImage');
                                $thumbDir = public_path() . config('constants.userstatusThumbImage');
                                $maxWidth = config('constants.thumbMaxWidth');

                                $userStatusHistory->taggedImage = VkUtility::saveBase64ImagePng($_JSON['taggedImage'], $imageDir, $thumbDir, $maxWidth);
                            }
                            $userStatusHistory->save();

                            if(isset($_JSON['notificationId']) && !empty($_JSON['notificationId'])){
                                $notification = Notification::where('id', $_JSON['notificationId'])->first();
                                $notification->notificationButtonStatus = 1;
                                $notification->save();
                            }

                            
                            $taggedFriendsList = array();
                            $count = 0;

                            //Tagged User Friend
                            if(count($userTaggedFriendsList) > 0) {
                                foreach($userTaggedFriendsList as $userStatusFriend){
                                    $userStatusFriends = new UserStatusFriends();
                                    $userStatusFriends->userStatusId = $userStatusHistory->id;
                                    $userStatusFriends->taggedFriends = $userStatusFriend;
                                    $userStatusFriends->save();


                                    // Saved Notification
                                    $notification = new Notification();
                                    $notification->senderUserId = $userSession->userId;
                                    $notification->receiverUserId = $userStatusFriend;
                                    //$notification->message = $user->firstName.' '. $user->surName." is going out to ".filter_var ($_JSON['taggedVenue'], FILTER_SANITIZE_STRING)." and posted the following ".base64_decode(filter_var ($_JSON['statusMessage'], FILTER_SANITIZE_STRING)) ." and Tagged you.";
                                    if(isset($_JSON['statusMessage']) && !empty($_JSON['statusMessage']))
                                    $notification->message = $user->firstName.' '. $user->surName." is going out to ".filter_var ($_JSON['taggedVenue'], FILTER_SANITIZE_STRING)." and posted the following: ".base64_decode(filter_var ($_JSON['statusMessage'], FILTER_SANITIZE_STRING)) ." and Tagged you.";
                                    else
                                        $notification->message = $user->firstName.' '. $user->surName." is going out to ".filter_var ($_JSON['taggedVenue'], FILTER_SANITIZE_STRING) ." and Tagged you.";
                                    $notification->notificationType = 3;
                                    $notification->nightclubId = $taggedVenueId;
                                    $notification->notificationImage = $userStatusHistory->taggedImage; 
                                    $notification->save();
                                }
                            }
                            // Make User Status for Following club
                            

                            //Send notification to All not Tagged Friends.

                            $userFriendList = Friend::getFriendIds($userSession->userId);
                            $userFriendDataList = explode(',',$userFriendList);
                            if(strlen($userFriendList)>0){
                                foreach($userFriendDataList as $userFriend){
                                    if(count($taggedFriendsList) > 0) {
                                        foreach($userTaggedFriendsList as $taggedFriend){
                                            if($userFriend!=$taggedFriend) {
                                                // Saved Notification
                                                $notification = new Notification();
                                                $notification->senderUserId = $userSession->userId;
                                                $notification->receiverUserId = $userFriend;
                                                if(isset($_JSON['statusMessage']) && !empty($_JSON['statusMessage']))
                                                    $notification->message = $user->firstName.' '. $user->surName." is going out to ".filter_var ($_JSON['taggedVenue'], FILTER_SANITIZE_STRING)." and posted the following: ".base64_decode(filter_var ($_JSON['statusMessage'], FILTER_SANITIZE_STRING));
                                                else
                                                    $notification->message = $user->firstName.' '. $user->surName." is going out to ".filter_var ($_JSON['taggedVenue'], FILTER_SANITIZE_STRING);
                                                $notification->notificationType = 9;
                                                $notification->isSent = 1;
                                                $notification->nightclubId = $taggedVenueId;
                                                $notification->notificationImage = $userStatusHistory->taggedImage; 
                                                $notification->save();
                                            }
                                        }
                                    } 
                                    else 
                                    {
                                        // Saved Notification
                                        $notification = new Notification();
                                        $notification->senderUserId = $userSession->userId;
                                        $notification->receiverUserId = $userFriend;
                                        if(isset($_JSON['statusMessage']) && !empty($_JSON['statusMessage']))
                                            $notification->message = $user->firstName.' '. $user->surName." is going out to ".filter_var ($_JSON['taggedVenue'], FILTER_SANITIZE_STRING)." and posted the following: ".base64_decode(filter_var ($_JSON['statusMessage'], FILTER_SANITIZE_STRING));
                                        else
                                            $notification->message = $user->firstName.' '. $user->surName." is going out to ".filter_var ($_JSON['taggedVenue'], FILTER_SANITIZE_STRING);
                                        $notification->notificationType = 9;
                                        $notification->isSent = 1;
                                        $notification->nightclubId = $taggedVenueId;
                                        $notification->notificationImage = $userStatusHistory->taggedImage; 
                                        $notification->save();
                                    }
                                }
                            }

                            $result = VkUtility::success($apiName, 'User Status Created Successfully');
                            $userStatus = UserStatusHistory::getById($userStatusHistory->id);
                            $userStatus->timeElapsed = '1s';
                            $userStatus->userStatusTaggedFriends = UserStatusFriends::getList($userStatusHistory->id);
                            $result['userStatus'] = $userStatus;
                        }
                    }
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }


    public function updateNotAttendingStatus() {
        $apiName = 'user/updateNotAttendingStatus';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'notificationId' => array('required','numeric')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first();
                if (is_null($userSession))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else {

                    $notification = Notification::where('id', $_JSON['notificationId'])->first();
                    if (is_null($notification))
                        $result = VkUtility::error($apiName, 101, 'Notifiction does not exixt.');
                    else {
                        $notification->notificationButtonStatus = 2;
                        $notification->save();
                        $result = VkUtility::success($apiName, 'Notifiction Status Saved Successfully.');
                    }
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }


    //Delete User Status

    public function deleteUserStatus() {
        $apiName = 'user/deleteUserStatus';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'statusId' => array('required','integer')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first();
                if (is_null($userSession))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else {
                    $deleteStatus = UserStatusHistory::where('id', '=', $_JSON['statusId'])->first();
                    if (is_null($deleteStatus))
                        $result = VkUtility::success($apiName, 'No data exist for selected status.');
                    else {

                        UserStatusHistory::where('id',$_JSON['statusId'])->delete();

                        $result = VkUtility::success($apiName, 'User status deleted successfully');
                    }
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }
    
    public function deleteUserGoingOutStatus(){
       $apiName = 'user/deleteUserGoingOutStatus';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first();
                if (is_null($userSession))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else {
                    $deleteStatus = UserStatusHistory::where('userId', '=', $userSession->userId)->where('taggedVenueId','<>',0)->orderBy('createDate','Desc')->first();
                    if (is_null($deleteStatus))
                        $result = VkUtility::success($apiName, 'No data exist for selected status.');
                    else {
                        $deleteStatus->delete();
                        NightclubCheckIn::where('userId',$userSession->userId)->delete();

                        $result = VkUtility::success($apiName, 'Going Out status deleted successfully');
                    }
                }
            }
        }
        return Response::json($result)->header("Connection","close"); 
    }
}
