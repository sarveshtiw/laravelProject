<?php namespace App\Http\Controllers\Webservices;

use \Illuminate\Support\Facades\Request;
use \Illuminate\Support\Facades\Response;
use \Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use App\Http\Middleware\VkUtility;
use App\Models\User;
use App\Models\UserSession;
use App\Models\Friend;
use App\Models\Notification;
use App\Models\Wink;
use DB;

class FriendController extends Controller {

    /*
    |--------------------------------------------------------------------------
    | Friend Controller
    |--------------------------------------------------------------------------
    |
    | This controller provides services to process friend records
    |
    */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }

    /**
     * Create a friend record
     *
     * @return Response
     */
    public function sendRequest()
    {
        $apiName = 'friend/sendRequest';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'selectedUserId' => array('required', 'integer')
        );
        
        if(!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else
        {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) 
            {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            }
            else if(is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first()))
            {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            }
            else if($userSession->userId == $_JSON['selectedUserId'])
            {
                $result = VkUtility::error($apiName, 99, 'You can not send request to yourself.');
            }
            else
            {   
                $notificationMessage = '';
                $user = User::where('id', '=', $userSession->userId)->first();
                $selectedUserId = filter_var($_JSON['selectedUserId'], FILTER_SANITIZE_NUMBER_INT);
                $selectedUser = User::where('id', '=', $selectedUserId)->first();
                $friend = Friend::getFriend($userSession->userId, $selectedUserId);
                
                if(is_null($user))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else if(is_null($selectedUser) || empty ($selectedUser))
                    $result = VkUtility::error($apiName, 99, 'Selected user does not exist.');
                else if(!is_null($friend) && !empty ($friend))
                    $result = VkUtility::error($apiName, 99, 'Selected user is either already a friend or a request already exists.');
                else
                {
                    $friend = new Friend();
                    $friend->senderUserId = $userSession->userId;
                    $friend->receiverUserId = $selectedUserId;
                    $friend->save();
                    
                    // Saved Notification as accepted to sender and receiver both
                    $notification = new Notification();
                    $notification->senderUserId = $userSession->userId;
                    $notification->receiverUserId = $selectedUserId;
                    $notification->message = $user->firstName.' '. $user->surName." has sent a friend request.";
                    $notificationMessage = $user->firstName.' '. $user->surName." has sent a friend request.";
                    $notification->isSent = 1;
                    $notification->notificationType = 4;
                    $notification->save();

                    //send push notification
                    $selectedUserSession = UserSession::where('userId', '=', $selectedUserId)->first();
                    if(!is_null($selectedUserSession) && !empty($selectedUserSession) && $selectedUserSession->deviceToken && $selectedUser->receiveNotification == 1)
                    {
                      
                        $data = array(
                            'notificationId'=>1, 
                            'senderUserId'=>$userSession->userId,
                            'senderJabberId'=>$user->jabberId,
                        );
                        VkUtility::sendApnsNotification($selectedUserSession->deviceToken, $notificationMessage, $selectedUserSession->deviceBadge, $data);
                    }
                    
                    $result = VkUtility::success($apiName, 'Friend request sent successfully');
                    $result['friendId'] = $friend->id;
                    $result['isFriendStatus'] = 0;
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * Respond to a friend
     *
     * @return Response
     */
    public function respond()
    {
        $apiName = 'friend/respond';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'friendId' => array('required', 'integer'),
            'response' => array('required', 'integer', 'in:0,1'),    /* 0 reject, 1 accept */
            'notificationId' => array('integer')
        );
        
        if(!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else
        {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) 
            {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            }
            else if(is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first()))
            {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            }
            else
            {
                $notificationMessage = '';
                $user = User::where('id', '=', $userSession->userId)->first();
                $response = filter_var($_JSON['response'], FILTER_SANITIZE_NUMBER_INT);
                $friendId = filter_var($_JSON['friendId'], FILTER_SANITIZE_NUMBER_INT);
                $friend = Friend::where('senderUserId', '=', $friendId)->where('receiverUserId', '=', $userSession->userId)->first();
                $senderUser = null;
                
                if(is_null($user))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else if(is_null($friend) || empty ($friend))
                    $result = VkUtility::error($apiName, 99, 'Selected friend does not exist.');
                else if($friend->friendStatus == 2)
                    $result = VkUtility::error($apiName, 99, 'You have already accepted this friend.');
                else if($friend->friendStatus == 3)
                    $result = VkUtility::error($apiName, 99, 'You have already rejected this friend.');
                else if(($senderUser = User::where('id', '=', $friend->senderUserId)->where('isDisabled', '=', 0)->first()) == null){
                    $result = VkUtility::error($apiName, 99, 'Sender user record does not exist.');
                
                    $friend->delete();
                }
                else
                {
                    //if the response is 1 set status to 2(accepted) else delete the record
                    if($response == 1)
                    {
                        $friend->friendStatus = 2;
                        $friend->save();
                        
                        $user->friendCount += 1;
                        $user->save();
                        
                        $senderUser->friendCount += 1;
                        $senderUser->save();

                        // Delete Old notification 
                        if(isset($_JSON['notificationId']) && !empty($_JSON['notificationId']))
                            Notification::where('id',filter_var ($_JSON['notificationId'], FILTER_SANITIZE_NUMBER_INT))->delete();
                        
                        // Saved Notification as accepted to sender and receiver both
                        $notification = new Notification();
                        $notification->senderUserId = $userSession->userId;
                        $notification->receiverUserId = $friendId;
                        $notification->message = $user->firstName.' '. $user->surName." has accepted your friend request.";
                        $notificationMessage = $user->firstName.' '. $user->surName." has accepted your friend request.";
                        $notification->isSent = 1;
                        $notification->notificationType = 5;
                        $notification->save();
                    }
                    else
                    {
                        // Reject Friend Request
                        $friend->delete();

                        if(isset($_JSON['notificationId']) && !empty($_JSON['notificationId']))
                            Notification::where('id',filter_var ($_JSON['notificationId'], FILTER_SANITIZE_NUMBER_INT))->delete();

                        // Saved Notification as recject friend
                        $notification = new Notification();
                        $notification->senderUserId = $userSession->userId;
                        $notification->receiverUserId = $friendId;
                        $notification->message = $user->firstName.' '. $user->surName." has rejected your friend request.";
                        $notificationMessage = $user->firstName.' '. $user->surName." has rejected your friend request.";
                        $notification->isSent = 1;
                        $notification->notificationType = 5;
                        $notification->save();
                    }
  
                    //send push notification
                    $senderUserSession = UserSession::where('userId', '=', $senderUser->id)->first();
                    
                    if(!is_null($senderUserSession) && !empty($senderUserSession) && $senderUserSession->deviceToken && $senderUser->receiveNotification == 1)
                    {
                        
                        $data = array(
                            'notificationId'=>1, 
                            'senderUserId'=>$userSession->userId,   /* current user */
                            'senderJabberId'=>$user->jabberId,
                        );
                        if($response == 1){
                            $message = "$user->firstName $user->surName has accepted your friend request.";
                            $notificationMessage = "$user->firstName $user->surName has accepted your friend request.";
                        }
                        else{
                            $message = "$user->firstName $user->surName has rejected your friend request.";
                            $notificationMessage = "$user->firstName $user->surName has rejected your friend request.";
                        }
                        
                        VkUtility::sendApnsNotification($senderUserSession->deviceToken, $notificationMessage, $senderUserSession->deviceBadge, $data);
                    
                        }
                    $sendResponse = ($response) ? 'Friend request accepted' : 'Friend request rejected';
     
                    $result = VkUtility::success($apiName, $sendResponse);
                    $result['friendId'] = $friend->id;
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }
    
    /**
     * Return list of all friends requests sent
     *
     * @return Response
     */
    public function listSentRequests()
    {
        $apiName = 'friend/listSentRequests';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required')
        );
        
        if(!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else
        {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) 
            {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            }
            else if(is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first()))
            {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            }
            else
            {
                $senderUserId = $userSession->userId;
                $receiverUserId = 0;
                $friendRequests = Friend::getList($senderUserId, $receiverUserId);
                $result = VkUtility::success($apiName, 'Records fetched successfully');
                $result['friendRequests'] = $friendRequests;
            }
        }
        return Response::json($result)->header("Connection","close");
    }
    
    /**
     * Return list of all friend requests received
     *
     * @return Response
     */
    public function listReceivedRequests()
    {
        $apiName = 'friend/listReceivedRequests';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required')
        );
        
        if(!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else
        {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) 
            {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            }
            else if(is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first()))
            {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            }
            else
            {
                $senderUserId = 0;
                $receiverUserId = $userSession->userId;
                $friendRequests = Friend::getList($senderUserId, $receiverUserId);
                
                foreach($friendRequests as $friendRequest)
                {
                    $friendRequest->timeElapsed = VkUtility::getTimeElapsedShort(date_create($friendRequest->createDate), date_create());
                }
                
                $result = VkUtility::success($apiName, 'Records fetched successfully');
                $result['friendRequests'] = $friendRequests;
            }
        }
        return Response::json($result)->header("Connection","close");
    }


    //Reject a friend

    /**
    * Respond to a friend
    *
    * @return Response
    */
    public function rejectFriend()
    {
        $apiName = 'friend/rejectFriend';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'friendId' => array('required', 'integer')
        );
        
        if(!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else
        {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) 
            {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            }
            else if(is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first()))
            {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            }
            else
            {
                $user = User::where('id', '=', $userSession->userId)->first();
                $senderUserId = $userSession->userId;
                $friendId = $_JSON['friendId'];
                $friendResult = Friend::Where(function($query) use ($friendId,$senderUserId)
                    {
                        $query->where('senderUserId', $friendId)
                              ->where('receiverUserId', $senderUserId)
                              ->where('friendStatus', 2);
                    })
                    ->orWhere(function($query) use ($friendId,$senderUserId)
                    {
                        $query->where('senderUserId', $senderUserId)
                              ->where('receiverUserId', $friendId)
                              ->where('friendStatus', 2);
                    })
                    ->first();
                if(is_null($friendResult)) {
                    $result = VkUtility::error($apiName, 99, 'Selected user is no longer in your friend list.');
                }
                else{
                    // Delete friend
                    $friendResult->delete();
                    
                    //Decreasse Login User friend count
                    $user->friendCount -= 1;
                    $user->save();
                    
                    //Decreasse Unfriend User friend count
                    $friendUser = User::where('id', '=', $friendId)->first();
                    $friendUser->friendCount -= 1;
                    $friendUser->save();
                    

                    // Delete All Notifications of the Mutual User
                    $notificationResult = Notification::Where(function($query) use ($friendId,$senderUserId)
                    {
                        $query->where('senderUserId', $friendId)
                              ->where('receiverUserId', $senderUserId);
                    })
                    ->orWhere(function($query) use ($friendId,$senderUserId)
                    {
                        $query->where('senderUserId', $senderUserId)
                              ->where('receiverUserId', $friendId);
                    })
                    ->delete();

                    // Delete Wink for Mutual Users
                    $winkResult = Wink::Where(function($query) use ($friendId,$senderUserId)
                    {
                        $query->where('senderUserId', $friendId)
                              ->where('receiverUserId', $senderUserId);
                    })
                    ->orWhere(function($query) use ($friendId,$senderUserId)
                    {
                        $query->where('senderUserId', $senderUserId)
                              ->where('receiverUserId', $friendId);
                    })
                    ->delete();

                    $result = VkUtility::success($apiName, 'Friend rejected successfully');
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

}
