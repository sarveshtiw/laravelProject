<?php namespace App\Http\Controllers\Webservices;

use \Illuminate\Support\Facades\Request;
use \Illuminate\Support\Facades\Response;
use \Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use App\Http\Middleware\VkUtility;
use App\Models\User;
use App\Models\UserSession;
use App\Models\Nightclub;
use App\Models\UserPhoto;

class UserPhotoController extends Controller {

    /*
    |--------------------------------------------------------------------------
    | Nightclub Controller
    |--------------------------------------------------------------------------
    |
    | This controller provides services to process nightclub records
    |
    */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }

    /**
     * Return list of all nightclub deals
     *
     * @return Response
     */
    public function getList()
    {
        $apiName = 'userPhoto/getList';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'selectedUserId' => array('integer'),
            'exceptions' => array('array')
        );
        
        if(!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else
        {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) 
            {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            }
            else if(is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first()))
            {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            }
            else
            {
                $selectedUserId = 0;
                $exceptions = '';
                
                if(isset($_JSON['selectedUserId']) && !empty($_JSON['selectedUserId']))
                    $selectedUserId = filter_var ($_JSON['selectedUserId'], FILTER_SANITIZE_NUMBER_INT);
                
                if(isset($_JSON['exceptions']) && !empty($_JSON['exceptions']))
                    $exceptions = join(',', $_JSON['exceptions']);
                
                $userPhotos = UserPhoto::getList($selectedUserId, $exceptions);
                
                $result = VkUtility::success($apiName, 'Records fetched successfully');
                $result['userPhotos'] = $userPhotos;
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * Add a photo to a nightclub
     *
     * @return Response
     */
    public function add()
    {
        $apiName = 'userPhoto/add';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'image' => array('required'),
            'briefInfo' => array('string')
        );
        
        $user = null;
        
        if(!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else
        {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) 
            {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            }
            else if(is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first()))
            {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            }
            else if(is_null($user = User::where('id', '=', $userSession->userId)->first()))
            {
                $result = VkUtility::error($apiName, 99, 'Selected user does not exist.');
            }
            else
            {
                $userPhoto = new UserPhoto();
                $userPhoto->userId = $user->id;
                
                if(isset($_JSON['briefInfo']) && !empty($_JSON['briefInfo']))
                    $userPhoto->briefInfo = $_JSON['briefInfo'];
                
                $imageDir = public_path() . config('constants.userImage');
                $thumbDir = public_path() . config('constants.userThumb');
                $maxWidth = config('constants.thumbMaxWidth');
                $userPhoto->image = VkUtility::saveBase64ImagePng($_JSON['image'], $imageDir, $thumbDir, $maxWidth);
                
                $userPhoto->save();
                
                $result = VkUtility::success($apiName, 'User photo saved successfully');
                $result['userPhoto'] = UserPhoto::getById($userPhoto->id);
            }
        }
        return Response::json($result)->header("Connection","close");
    }


    /**
     * Delete user photo & return all remains photo
     *
     * @return Response
     */
    public function delete()
    {
        $apiName = 'userPhoto/delete';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'userPhotoId' => array('required','integer')
        );
        
        if(!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else
        {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) 
            {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            }
            else if(is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first()))
            {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            }
            else if(is_null($userPhoto = UserPhoto::where('id',$_JSON['userPhotoId'])->first()))
            {
                $result = VkUtility::error($apiName, 99, 'Selected Photo does not exit on server.');
            }
            else
            {
                $exceptions = '';

                if(isset($_JSON['userPhotoId']) && !empty($_JSON['userPhotoId']))
                    $userPhotoId = filter_var ($_JSON['userPhotoId'], FILTER_SANITIZE_NUMBER_INT);
                $selectedUserId = $userSession->userId;
                
                UserPhoto::where('id',$userPhotoId)->where('userId',$selectedUserId)->delete();
                $userPhotos = UserPhoto::getList($selectedUserId);
                
                $result = VkUtility::success($apiName, 'Records deleted successfully');
                $result['userPhotos'] = $userPhotos;
            }
        }
        return Response::json($result)->header("Connection","close");
    }

}
