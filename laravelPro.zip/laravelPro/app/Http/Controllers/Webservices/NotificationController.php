<?php namespace App\Http\Controllers\Webservices;

use \Illuminate\Support\Facades\Request;
use \Illuminate\Support\Facades\Response;
use \Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use App\Http\Middleware\VkUtility;
use App\Models\User;
use App\Models\UserSession;
use App\Models\NightclubPhoto;
use App\Models\Notification;
use App\Models\Nightclub;
use App\Models\NightclubCheckIn;
use App\Models\NightclubEvent;
use App\Models\NightclubFollower;
use App\Models\SuggestVenue;
use DB;

class NotificationController extends Controller {

    /*
    |--------------------------------------------------------------------------
    | Nightclub Controller
    |--------------------------------------------------------------------------
    |
    | This controller provides services to process nightclub records
    |
    */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }

    /**
     * Return list of all user notifications 
     *
     * @return Response
     */
    public function getList()
    {
        $apiName = 'notification/getList';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'exceptions' => array('array')
        );
        
        if(!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else
        {
            $exceptions = '';
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) 
            {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            }
            else if(is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first()))
            {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            }
            else
            {                   
                if(isset($_JSON['exceptions']) && !empty($_JSON['exceptions']))
                    $exceptions = join(',', $_JSON['exceptions']);
                
                $notifications = Notification::getList($userSession->userId, $exceptions);
                foreach($notifications as $notification){
                    $notification->timeElapsed = VkUtility::getTimeElapsedShort(date_create($notification->createDate), date_create());
                }
                $result = VkUtility::success($apiName, 'Records fetched successfully');
                $result['notifications'] = $notifications;
            }
        }
        return Response::json($result)->header("Connection","close");
    }  

    /**
     * Return list of all user notifications 
     *
     * @return Response
     */
    public function getFriendNotification()
    {
        $apiName = 'user/getFriendNotification';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'exceptions' => array('array')
        );
        
        if(!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else
        {
            if(isset($_JSON['exceptions']) && !empty($_JSON['exceptions']))
                    $exceptions = join(',', $_JSON['exceptions']);
                
            $exceptions = [];
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) 
            {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            }
            else if(is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first()))
            {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            }
            else
            {          
                if(isset($_JSON['exceptions']) && !empty($_JSON['exceptions']))
                    $exceptions = join(',', $_JSON['exceptions']);
                             
                $notifications = Notification::getFriendNotificationList($userSession->userId, $exceptions);
                foreach($notifications as $notification){
                    $notification->timeElapsed = VkUtility::getTimeElapsedShort(date_create($notification->createDate), date_create());
                    $nightclubPhotos = NightclubPhoto::getList($notification->nightclubId, $exceptions);
                    $notification->nightclubPhotos = $nightclubPhotos;
                    $notification->nightclubPhotosCount = count($nightclubPhotos);
                }
                $result = VkUtility::success($apiName, 'Records fetched successfully');
                $result['notifications'] = $notifications;
            }
        }
        return Response::json($result)->header("Connection","close");
    }    
}
