<?php namespace App\Http\Controllers\Webservices;

use \Illuminate\Support\Facades\Request;
use \Illuminate\Support\Facades\Response;
use \Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use App\Http\Middleware\VkUtility;
use App\Models\User;
use App\Models\UserSession;
use App\Models\Wink;
use App\Models\Notification;
use DB;
use App\Models\NightclubCheckIn;
use App\Models\NightclubCheckInHistory;

class CronController extends Controller {

    /*
    |--------------------------------------------------------------------------
    | Cron Controller
    |--------------------------------------------------------------------------
    |
    | This controller provides services to process cron jobs
    |
    */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

    }

    /**
     * Send Push Notification
     *
     * @return Response
     */
    public function sendPushNotification()
    {
        
        $notificationMessage = '';
        $notificationId = '';
        $senderUserId = '';
        $receiverUserId = '';
        $notificationList = Notification::where('isSent',0)->get();
        foreach($notificationList as $notification){
            $notificationId = $notification['id'];
            $senderUserId = $notification['senderUserId'];
            $receiverUserId = $notification['receiverUserId'];
            $notificationMessage = $notification['message'];

            //send push notification
            $selectedUser = DB::table('userSession as us')
                                ->join('user as u ','u.id', '=', 'us.userId')
                                ->select('us.*', 'u.id', 'u.receiveNotification')
                                ->where('us.userId',$receiverUserId)
                                ->first();

            $notification->isSent = 1;
            $notification->save();
            if(!is_null($selectedUser))
            {
                //&& !empty($selectedUser) && $selectedUser->deviceToken && $selectedUser->receiveNotification == 1
                $data = array(
                            'notificationId'=>1, 
                            'senderUserId'=>'',
                            'senderJabberId'=>'',
                        );
                VkUtility::sendApnsNotification($selectedUser->deviceToken, $notificationMessage, $selectedUser->deviceBadge, $data);
                
            }
        }
        echo "Notificaiton Send successfully."; die;
    }


    /**
     * Reset User Going out Status after 24 Hours
     *
     * @return Response
     */
    public function resetUserStatusToHistory()
    {
        $today = date('Y-m-d H:i:s');
        $nightclubCheckInList = NightclubCheckIn::where(DB::raw("(TIMESTAMPDIFF(hour,createDate,'$today'))"),'>=',24)->get();
        $checkinDataArray = array();
        foreach($nightclubCheckInList as $checkinData){
            $checkinDataArray[] = $checkinData->id;

            //Add Last Checked in Data to Checked in History

            $nightclubCheckInHistory = new NightclubCheckInHistory();
            $nightclubCheckInHistory->nightclubId = $checkinData->nightclubId;
            $nightclubCheckInHistory->userId = $checkinData->userId;
            $nightclubCheckInHistory->checkInDateTime = $checkinData->createDate;
            $nightclubCheckInHistory->checkOutDatetIme = $today;
            $nightclubCheckInHistory->save();
        }
        //Delete Last Checked in
        NightclubCheckIn::whereIn('id', $checkinDataArray)->delete();
        
        echo "User Going Out Status Reset successfully."; die;
    }

}
