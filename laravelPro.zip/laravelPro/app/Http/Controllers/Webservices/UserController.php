<?php

namespace App\Http\Controllers\Webservices;

use \Illuminate\Support\Facades\Request;
use \Illuminate\Support\Facades\Response;
use \Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Controller;
use App\Http\Middleware\VkUtility;
use App\Http\Middleware\VkXmpp;
use App\Models\User;
use App\Models\Friend;
use App\Models\NightclubFollower;
use App\Models\UserSession;
use App\Models\ReportUser;
use App\Models\BlockUser;
use \App\Models\TaggedUser;
use \Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;
use App\Models\ChatRoom;
use App\Models\ChatRoomOccupant;
use App\Models\Notification;
use App\Models\Wink;

class UserController extends Controller {
    /*
      |--------------------------------------------------------------------------
      | User Controller
      |--------------------------------------------------------------------------
      |
      | This controller provides services to process user records
      |
     */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        
    }

    /**
     * Check uniqeness of given email
     *
     * @return Response
     */
    public function validateEmail() {
        $apiName = 'user/validateEmail';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'email' => array('required', 'email', 'unique:user,email')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $result = VkUtility::success($apiName, 'Email is unique');
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * Register a user and save record in database
     *
     * @return Response
     */
    public function signup() {
        $apiName = 'user/signup';
        $deviceToken = '';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'facebookId' => array('alpha_num'),
            'email' => array('required', 'email', 'unique:user,email'),
            'password' => array('required_without:facebookId'),
            'firstName' => array('required', 'string', 'min:1'),
            'surName' => array('string'),
            'postcode' => array('string'),
            'country' => array('string'),
            'phone' => array('string'),
            'latitude' => array('required','numeric'),
            'longitude' => array('numeric'),
            'age' => array('integer', 'between:1,100'),
            'relationshipStatus' => array('string'),
            'gender' => array('in:m,f'),
            'aboutMe' => array('string'),
            'lookingFor' => array('in:m,f,b'),
            'isOpenToChat' => array('in:0,1'),
            'deviceToken' => array('string'),
            'role' => array( 'in:User'),
        );

        $message = array('latitude.required' => 'The location field is required.');
        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules, $message);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $user = new User();
                $user->email = $_JSON['email'];

                if (isset($_JSON['facebookId']) && !empty($_JSON['facebookId']))
                    $user->facebookId = $_JSON['facebookId'];

                if (isset($_JSON['password']) && !empty($_JSON['password']))
                    $user->password = VkUtility::getEncryptedPassword($_JSON['password'], $_JSON['email']);

                $user->firstName = $_JSON['firstName'];
                $user->surName = $_JSON['surName'];
                $user->gender = $_JSON['gender'];
                $user->isOpenToChat = $_JSON['isOpenToChat'];

                if (isset($_JSON['lookingFor']) && !empty($_JSON['lookingFor']))
                    $user->lookingFor = $_JSON['lookingFor'];

                if (isset($_JSON['age']) && !empty($_JSON['age']))
                    $user->age = $_JSON['age'];

                if (isset($_JSON['phone']) && !empty($_JSON['phone']))
                    $user->phone = $_JSON['phone'];

                if (isset($_JSON['relationshipStatus']) && !empty($_JSON['relationshipStatus']))
                    $user->relationshipStatus = $_JSON['relationshipStatus'];

                if (isset($_JSON['aboutMe']) && !empty($_JSON['aboutMe']))
                    {
                    $aboutMe = base64_decode($_JSON['aboutMe']);
                    $user->aboutMe = $aboutMe;
                    }
                    
                if (isset($_JSON['role']) && !empty($_JSON['role']))
                    $user->role = $_JSON['role'];
                else
                    $user->role = 'user';

                if (isset($_JSON['latitude']) && !empty($_JSON['latitude']) && isset($_JSON['longitude']) && !empty($_JSON['longitude'])) {
                    $addressComponents = VkUtility::getAddressComponentsFromLatLong($_JSON['latitude'], $_JSON['longitude']);
                    $user->latitude = $_JSON['latitude'];
                    $user->longitude = $_JSON['longitude'];
                    $user->current_latitude = $_JSON['latitude'];
                    $user->current_longitude = $_JSON['longitude'];
                    if($addressComponents['administrativeAreaLevel2'] && $addressComponents['administrativeAreaLevel1'])
                        $user->location = $addressComponents['administrativeAreaLevel2'].', '.$addressComponents['administrativeAreaLevel1'];
                    else
                        $user->location = '';
                    //$user->location = $addressComponents['formattedAddress'];
                    $user->postcode = $addressComponents['postalCode'];
                    $user->country = $addressComponents['country'];
                    $user->state = $addressComponents['administrativeAreaLevel1'];
                    $user->city = $addressComponents['administrativeAreaLevel2'];

                } else if (isset($_JSON['postcode']) && !empty($_JSON['postcode']) && isset($_JSON['country']) && !empty($_JSON['country'])) {
                    $locationComponents = VkUtility::getLocationFromPostcode($_JSON['postcode'], $_JSON['country']);
                    $user->latitude = $locationComponents['latitude'];
                    $user->longitude = $locationComponents['longitude'];
                    $user->current_latitude = $_JSON['latitude'];
                    $user->current_longitude = $_JSON['longitude'];
                    //$user->location = $locationComponents['formattedAddress'];
                    if($addressComponents['administrativeAreaLevel2'] && $addressComponents['administrativeAreaLevel1'])
                        $user->location = $addressComponents['administrativeAreaLevel2'].', '.$addressComponents['administrativeAreaLevel1'];
                    else
                        $user->location = '';
                    $user->postcode = $_JSON['postcode'];
                    $user->country = $_JSON['country'];
                    $user->state = $addressComponents['administrativeAreaLevel1'];
                    $user->city = $addressComponents['administrativeAreaLevel2'];
                } 
                $user->save();
                //$xmppPrefix = env('XMPP_PREFIX', 'bendrDev');
                $xmppPrefix = env('XMPP_PREFIX');
                $xmppHost = env('XMPP_HOST');

                //comment following line (this is for testing only) and uncomment the next one
                //$xmppResponse = array('res'=>0, 'text'=>'');
                $xmppResponse = VkXmpp::registerUser($xmppHost, $xmppPrefix . $user->id, $xmppPrefix . $user->id); //user id would also be used as password in xmpp
                if ($xmppResponse['res'] == 1) {   //error
                    $user->delete();
                    $result = VkUtility::error($apiName, 99, $xmppResponse['text']);        //xmpp error message
                } else {
                    //save image with user id as name
                    if (isset($_JSON['image']) && !empty($_JSON['image'])) {
                        $imageDir = public_path() . config('constants.userImage');
                        $thumbDir = public_path() . config('constants.userThumb');
                        $maxWidth = config('constants.thumbMaxWidth');
                        $user->image = VkUtility::saveBase64ImagePng($_JSON['image'], $imageDir, $thumbDir, $maxWidth);
                    } else if (isset($_JSON['imageUrl']) && !empty($_JSON['imageUrl'])) {
                         try {
                            $fileName = uniqid('', true) . '.jpeg';
                            $imagePath = public_path() . '/images/user/';
                            $thumbPath = public_path() . '/images/user/thumb/';
                            $imageUrl = base64_decode($_JSON['imageUrl']);
                            $image = $imageUrl;
                            if (strpos($imageUrl, '(null)') !== false) {
                                $image = str_replace('(null)', $_JSON['facebookId'], $imageUrl);        
                            }
                            if(@copy($image, $imagePath . $fileName)){
                            $maxWidth = config('constants.thumbMaxWidth');
                            $thumb = VkUtility::makeThumbImage($imagePath, $thumbPath, $fileName,$maxWidth);
                            $user->image = $fileName;
                            }
                        } catch (Exception $e) {
                            
                        }
                    } 

                    $user->jabberId = $xmppPrefix . $user->id . '@localhost';  // . '@' . $xmppHost;
                    $user->save();

                    if (isset($_JSON['deviceToken']))
                        $deviceToken = $_JSON['deviceToken'];

                    $result = VkUtility::success($apiName, 'User registered successfully');
                    $result['user'] = User::getUserById($user->id, 0, 1);
                    $result['sessionId'] = $this->login($user->id, 'user', $deviceToken);
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * Reset user's password and send email to user
     *
     * @return Response
     */ 
    public function resetPassword() {
        $apiName = 'user/resetPassword';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'email' => array('required', 'email')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $user = User::where(array('email' => $_JSON['email']))->first();
                if (is_null($user) || empty($user)) {
                    $result = VkUtility::error($apiName, 99, 'Please check your email.');
                } else {
                    $password = VkUtility::randomString(6);
                    $user->password = VkUtility::getEncryptedPassword($password, $_JSON['email']);
                    $user->save();

                    $result = VkUtility::success($apiName, 'User password reset successfully');

                    //send email
                    $email = $_JSON['email'];
                    Mail::send('emails.resetPassword', ['password' => $password], function($message) use ($user) {
                        $message->from('support@bendr.com', 'Bendr');
                        $message->to($user->email);
                        $message->subject('Bendr - New password');
                    });
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * Update user profile details
     *
     * @return Response
     */
    public function updateProfile() {
        $apiName = 'user/updateProfile';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'firstName' => array('string'),
            'surName' => array('string'),
            'postcode' => array('string'),
            'country' => array('string'),
            'phone' => array('string'),
            'latitude' => array('numeric'),
            'longitude' => array('numeric'),
            'age' => array('integer', 'between:1,100'),
            'relationshipStatus' => array('string'),
            'gender' => array('in:m,f'),
            'aboutMe' => array('string'),
            'lookingFor' => array('in:m,f,b'),
            'isOpenToChat' => array('in:0,1')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first();
                if (is_null($userSession))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else {

//                    $user = User::with('userSession')->whereHas('userSession', function($q)
//                    {
//                        $q->where('sessionId', '=', $_JSON['sessionId']);
//
//                    })->first();

                    $user = User::where('id', '=', $userSession->userId)->first();
                    if (is_null($user))
                        $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                    else {

                        if (isset($_JSON['firstName']) && !empty($_JSON['firstName']))
                            $user->firstName = $_JSON['firstName'];
                        else
                            $user->firstName = '';

                        if (isset($_JSON['surName']) && !empty($_JSON['surName']))
                            $user->surName = $_JSON['surName'];
                        else
                            $user->surName = '';

                        if (isset($_JSON['age']) && !empty($_JSON['age']))
                            $user->age = $_JSON['age'];
                        else
                            $user->age = 0;

                        if (isset($_JSON['gender']) && !empty($_JSON['gender']))
                            $user->gender = $_JSON['gender'];

                        if (isset($_JSON['lookingFor']) && !empty($_JSON['lookingFor']))
                            $user->lookingFor = $_JSON['lookingFor'];
                        else
                            $user->lookingFor = '';

                        if (isset($_JSON['isOpenToChat']))
                            $user->isOpenToChat = $_JSON['isOpenToChat'];
                        else
                            $user->isOpenToChat = 0;

                        if (isset($_JSON['phone']) && !empty($_JSON['phone']))
                            $user->phone = $_JSON['phone'];
                        else
                            $user->phone = '';

                        if (isset($_JSON['relationshipStatus']) && !empty($_JSON['relationshipStatus']))
                            $user->relationshipStatus = $_JSON['relationshipStatus'];
                        else
                            $user->relationshipStatus = '';

                        if (isset($_JSON['aboutMe']) && !empty($_JSON['aboutMe']))
                        {
                            $aboutMe = base64_decode($_JSON['aboutMe']);
                            $user->aboutMe = $aboutMe;
                        }
                        else
                            $user->aboutMe = '';

                        if (isset($_JSON['latitude']) && !empty($_JSON['latitude']) && isset($_JSON['longitude']) && !empty($_JSON['longitude'])) {
                            $addressComponents = VkUtility::getAddressComponentsFromLatLong($_JSON['latitude'], $_JSON['longitude']);
                            $user->latitude = $_JSON['latitude'];
                            $user->longitude = $_JSON['longitude'];
                            $user->location = $addressComponents['formattedAddress'];
                            $user->postcode = $addressComponents['postalCode'];
                            $user->country = $addressComponents['country'];
                        } else if (isset($_JSON['postcode']) && !empty($_JSON['postcode']) && isset($_JSON['country']) && !empty($_JSON['country'])) {
                            $user->postcode = $_JSON['postcode'];
                            $user->country = $_JSON['country'];

                            $locationComponents = VkUtility::getLocationFromPostcode($_JSON['postcode'], $_JSON['country']);
                            $user->latitude = $locationComponents['latitude'];
                            $user->longitude = $locationComponents['longitude'];
                            $user->location = $locationComponents['formattedAddress'];
                        }

                        if (isset($_JSON['image']) && !empty($_JSON['image'])) {
                            $imageDir = public_path() . config('constants.userImage');
                            $thumbDir = public_path() . config('constants.userThumb');
                            $maxWidth = config('constants.thumbMaxWidth');

                            $xmppPrefix = env('XMPP_PREFIX', 'bendr');
                            $user->image = VkUtility::saveBase64ImagePng($_JSON['image'], $imageDir, $thumbDir, $maxWidth);
                        }

                        $user->save();

                        $result = VkUtility::success($apiName, 'User record saved successfully');
                        $result['user'] = User::getUserById($user->id, 0, 1);

                        $nightclubsFollowed = NightclubFollower::getList($user->id, 0, $user->id);
                        $result['user']->nightclubFollowCount = count($nightclubsFollowed);
                    }
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * set if user is open to chat or not
     *
     * @return Response
     */
    public function setOpenToChat() {
        $apiName = 'user/setOpenToChat';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'isOpenToChat' => array('required', 'in:0,1')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first();
                if (is_null($userSession))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else {
                    $user = User::where('id', '=', $userSession->userId)->first();
                    if (is_null($user))
                        $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                    else {
                        if (isset($_JSON['isOpenToChat']))
                            $user->isOpenToChat = $_JSON['isOpenToChat'];
                        else
                            $user->isOpenToChat = 0;

                        $user->save();

                        $result = VkUtility::success($apiName, 'User record saved successfully');
                        $result['user'] = User::getUserById($user->id, 0, 1);

                        $nightclubsFollowed = NightclubFollower::getList($user->id, 0, $user->id);
                        $result['user']->nightclubFollowCount = count($nightclubsFollowed);
                    }
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }
    
    public function receiveNotification() {
        $apiName = 'user/receiveNotification';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'receiveNotification' => array('required', 'in:0,1')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first();
                if (is_null($userSession))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else {
                    $user = User::where('id', '=', $userSession->userId)->first();
                    if (is_null($user))
                        $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                    else {
                        if (isset($_JSON['receiveNotification']))
                            $user->receiveNotification = $_JSON['receiveNotification'];
                        else
                            $user->receiveNotification = 0;

                        $user->save();

                        $result = VkUtility::success($apiName, 'User record saved successfully');
                        $result['user'] = User::getUserById($user->id, 0, 1);

                        $nightclubsFollowed = NightclubFollower::getList($user->id, 0, $user->id);
                        $result['user']->nightclubFollowCount = count($nightclubsFollowed);
                    }
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * Change user password
     *
     * @return Response
     */
    public function changePassword() {
        $apiName = 'user/changePassword';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'oldPassword' => array('required', 'string'),
            'newPassword' => array('required', 'string')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first();
                if (is_null($userSession))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else {
                    $user = User::where('id', '=', $userSession->userId)->first();
                    if (is_null($user))
                        $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                    else {
                        $oldPassword = VkUtility::getEncryptedPassword($_JSON['oldPassword'], $user->email);
                        $newPassword = VkUtility::getEncryptedPassword($_JSON['newPassword'], $user->email);

                        if ($oldPassword != $user->password)
                            $result = VkUtility::error($apiName, 99, 'Invalid password. Please try again.');
                        else {
                            $user->password = $newPassword;
                            $user->save();

                            $result = VkUtility::success($apiName, 'Password changed successfully');
                        }
                    }
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * Get user profile details
     *
     * @return Response
     */
    public function getProfile() {
        $apiName = 'user/getProfile';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'selectedUserId' => array('required', 'integer')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first();
                if (is_null($userSession))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else {
                    $user = User::where('id', '=', $userSession->userId)->first();
                    $selectedUser = User::getUserById($_JSON['selectedUserId'], $userSession->userId, 0);

                    if (is_null($user))
                        $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                    else if (is_null($selectedUser) || empty($selectedUser))
                        $result = VkUtility::error($apiName, 99, 'Selected user does not exist.');
                    else {
                        
                        // $nightclubsFollowed = NightclubFollower::getList($user->id, 0, $selectedUser->id);
                        // $selectedUser->nightclubFollowCount = count($nightclubsFollowed);
                        
                        $result = VkUtility::success($apiName, 'User record fetched successfully');
                        $result['user'] = $selectedUser;
                    }
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * Get user profile details
     *
     * @return Response
     */
    public function getFriendsProfile() {
        $apiName = 'user/getFriendsProfile';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'selectedUserId' => array('required', 'integer')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first();
                if (is_null($userSession))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else {
                    $user = User::where('id', '=', $userSession->userId)->first();
                    $selectedUser = User::getFriendsProfile($_JSON['selectedUserId'], $userSession->userId, 0, 0);

                    if (is_null($user))
                        $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                    else if (is_null($selectedUser) || empty($selectedUser))
                        $result = VkUtility::error($apiName, 99, 'Selected user does not exist.');
                    else {
                        
                        // $nightclubsFollowed = NightclubFollower::getList($user->id, 0, $selectedUser->id);
                        // $selectedUser->nightclubFollowCount = count($nightclubsFollowed);
                        
                        $result = VkUtility::success($apiName, 'User record fetched successfully');
                        $result['user'] = $selectedUser;
                    }
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * Get user profile details by email addresses
     *
     * @return Response
     */
    public function getByEmails() {
        $apiName = 'user/getByEmails';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'emails' => array('required', 'array')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first();
                if (is_null($userSession))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else {
                    $emails = "'" . join("','", $_JSON['emails']) . "'";
                    $selectedUsers = User::getUserByEmails($emails, $userSession->userId);
                    $result = VkUtility::success($apiName, 'User records fetched successfully');
                    $result['selectedUsers'] = $selectedUsers;
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * Get user profile details by facebook ids
     *
     * @return Response
     */
    public function getByFacebookIds() {
        $apiName = 'user/getByFacebookIds';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'facebookIds' => array('required', 'array')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first();
                if (is_null($userSession))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else {
                    $facebookIds = "'" . join("','", $_JSON['facebookIds']) . "'";
                    $selectedUsers = User::getUserByFacebookIds($facebookIds, $userSession->userId);
                    $result = VkUtility::success($apiName, 'User records fetched successfully');
                    $result['selectedUsers'] = $selectedUsers;
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * Update user's default filter settings
     *
     * @return Response
     */
    public function saveFilter() {
        $apiName = 'user/saveFilter';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'filterNearMe' => array('in:0,1'),
            'filterLat' => array('string'),
            'filterLong' => array('string'),
            'filterVenueType' => array('string'),
            'filterMusicGenre' => array('string'),
            'filterDressCode' => array('string'),
            'filterBudget' => array('numeric'),
            'filterPopularity' => array('string'),
            'filterMaxDistance' => array('numeric'),
            'filterVenueSubType' => array('string'),
            'filterSubMusicGenre' => array('string'),
            'filterMyClubs' => array('string'),
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first();
                if (is_null($userSession))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else {
                    $user = User::where('id', '=', $userSession->userId)->first();
                    if (is_null($user))
                        $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                    else {

                        if (isset($_JSON['filterNearMe']) && !empty($_JSON['filterNearMe']))
                            $user->filterNearMe = $_JSON['filterNearMe'];
                        else
                            $user->filterNearMe = null;

                        if (isset($_JSON['filterLat']) && !empty($_JSON['filterLat']))
                            $user->latitude = $_JSON['filterLat'];

                        if (isset($_JSON['filterLong']) && !empty($_JSON['filterLong']))
                            $user->longitude = $_JSON['filterLong'];

                        if (isset($_JSON['filterVenueType']) && !empty($_JSON['filterVenueType']))
                            $user->filterVenueType = $_JSON['filterVenueType'];
                        else
                            $user->filterVenueType = null;

                        if (isset($_JSON['filterMusicGenre']) && !empty($_JSON['filterMusicGenre']))
                            $user->filterMusicGenre = $_JSON['filterMusicGenre'];
                        else
                            $user->filterMusicGenre = null;

                        if (isset($_JSON['filterSubMusicGenre']) && !empty($_JSON['filterSubMusicGenre']))
                            $user->filterSubMusicGenre = $_JSON['filterSubMusicGenre'];
                        else
                            $user->filterSubMusicGenre = null;

                        if (isset($_JSON['filterDressCode']) && !empty($_JSON['filterDressCode']))
                            $user->filterDressCode = $_JSON['filterDressCode'];
                        else
                            $user->filterDressCode = null;

                        if (isset($_JSON['filterBudget']) && !empty($_JSON['filterBudget']))
                            $user->filterBudget = $_JSON['filterBudget'];
                        else
                            $user->filterBudget = null;

                        if (isset($_JSON['filterPopularity']) && !empty($_JSON['filterPopularity']))
                            $user->filterPopularity = $_JSON['filterPopularity'];
                        else
                            $user->filterPopularity = null;

                        if (isset($_JSON['filterMaxDistance']) && !empty($_JSON['filterMaxDistance']))
                            $user->filterMaxDistance = $_JSON['filterMaxDistance'];
                        else
                            $user->filterMaxDistance = null;

                        if (isset($_JSON['filterVenueSubType']) && !empty($_JSON['filterVenueSubType']))
                            $user->filterVenueSubType = $_JSON['filterVenueSubType'];
                        else
                            $user->filterVenueSubType = null;

                        if (isset($_JSON['filterMyClubs']) && !empty($_JSON['filterMyClubs']))
                            $user->filterMyClubs = $_JSON['filterMyClubs'];
                        else
                            $user->filterMyClubs = null;

                        $user->save();

                        $result = VkUtility::success($apiName, 'Filter settings saved successfully');
                        $result['user'] = User::getUserById($user->id, 0, 1);
                    }
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * Logout user and terminate current session
     *
     * @return Response
     */
    public function logout() {
        $apiName = 'user/logout';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first();
                if (is_null($userSession))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else {
                    $user = User::where('id', '=', $userSession->userId)->first();
                    if (is_null($user))
                        $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                    else {

                        $user->filterMyClubs = null;
                        $user->filterNearMe = null;
                        $user->filterVenueType = null;
                        $user->filterMusicGenre = null;
                        $user->filterPopularity = null;
                        $user->filterBudget = null;
                        $user->filterDressCode = null;
                        $user->filterSubMusicGenre = null;
                        $user->filterVenueSubType = null;
                        $user->save();
                        $userSession->delete();

                        $result = VkUtility::success($apiName, 'User logged out successfully');
                    }
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * Check user email and password and allow to login if the credentials correct
     *
     * @return Response
     */
    public function signin() {
        $apiName = 'user/signin';
        $deviceToken = '';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'email' => array('required', 'email', 'exists:user,email,isDisabled,0'),
            'password' => array('required'),
            'deviceToken' => array('string')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $check_role = 'user';
                $user = User::getUserByEmail($_JSON['email'], 0, 1, 1,$check_role);
                $encryptedPassword = VkUtility::getEncryptedPassword($_JSON['password'], $_JSON['email']);
                if (is_null($user) || empty($user))
                    $result = VkUtility::error($apiName, 99, 'Email does not exist. Please check the email.');
                else if ($user->password != $encryptedPassword)
                    $result = VkUtility::error($apiName, 99, 'Incorrect email or password.');
                else {
                    if (isset($_JSON['deviceToken']))
                        $deviceToken = $_JSON['deviceToken'];

                    $result = VkUtility::success($apiName, 'User signed in successfully');
                    $userData = User::getUserById($user->id, 0, 1);
                    unset($user->password);
                    $result['user'] = $userData;
                    $result['sessionId'] = $this->login($user->id, 'user', $deviceToken);
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * Check user facebookId and allow to login if the id correct
     *
     * @return Response
     */
    public function signinFb() {
        $apiName = 'user/signinFb';
        $deviceToken = '';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'facebookId' => array('required', 'alpha_num'),
            'email' => array('email'),
            'firstName' => array('string', 'min:1'),
            'surName' => array('string'),
            'age' => array('integer', 'between:1,100'),
            'relationshipStatus' => array('string'),
            'gender' => array('in:m,f'),
            'deviceToken' => array('string')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $fbUser = User::getUserByFacebookId($_JSON['facebookId'], 0, 1);
                
                if (is_null($fbUser) || empty($fbUser))
                    $result = VkUtility::error($apiName, 99, 'User record does not exist. Please signup.');
                else {
                    $user = User::find($fbUser->id);

                    if (isset($_JSON['email']) && !empty($_JSON['email']))
                        $user->email = $_JSON['email'];

                    if (isset($_JSON['firstName']) && !empty($_JSON['firstName']))
                        $user->firstName = $_JSON['firstName'];

                    if (isset($_JSON['surName']) && !empty($_JSON['surName']))
                        $user->surName = $_JSON['surName'];

                    if (isset($_JSON['age']) && !empty($_JSON['age']))
                        $user->age = $_JSON['age'];

                    if (isset($_JSON['relationshipStatus']) && !empty($_JSON['relationshipStatus']))
                        $user->relationshipStatus = $_JSON['relationshipStatus'];

                    if (isset($_JSON['gender']) && !empty($_JSON['gender']))
                        $user->gender = $_JSON['gender'];

                    //save image
                    if (isset($_JSON['imageUrl']) && !empty($_JSON['imageUrl'])) {
                        try{
                        $fileName = uniqid('', true) . '.jpeg';
                        $imagePath = public_path() . '/images/user/';
                        $thumbPath = public_path() . '/images/user/thumb/';
                        $imageUrl = base64_decode($_JSON['imageUrl']);
                            $image = $imageUrl;
                            if (strpos($imageUrl, '(null)') !== false) {
                                $image = str_replace('(null)', $_JSON['facebookId'], $imageUrl);        
                            }
                        if(@copy($image, $imagePath . $fileName)){
                        $maxWidth = config('constants.thumbMaxWidth');
                        $thumb = VkUtility::makeThumbImage($imagePath, $thumbPath, $fileName,$maxWidth);
                        $user->image = $fileName;
                        }
                        }
                        catch(Exception $e){
                            
                        }
                    }
                    $xmppResponse = array('res'=>0, 'text'=>'');
                    $xmppPrefix = env('XMPP_PREFIX');
                    $xmppHost = env('XMPP_HOST');
                    //$xmppResponse = VkXmpp::registerUser($xmppPrefix . $user->id, $xmppPrefix . $user->id); //user id would also be used as password in xmpp
                    if ($xmppResponse['res'] == 1) {   //error
                        $user->delete();
                        $result = VkUtility::error($apiName, 99, $xmppResponse['text']);        //xmpp error message
                    } else {
                        $user->jabberId = $xmppPrefix . $user->id . '@localhost';  // . '@' . $xmppHost;
                    }

                    $user->save();

                    if (isset($_JSON['deviceToken']))
                        $deviceToken = $_JSON['deviceToken'];

                   
                    $result = VkUtility::success($apiName, 'User signed in successfully');
                    $result['user'] = $user;
                    $result['sessionId'] = $this->login($user->id, 'user', $deviceToken);
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    private function login($userId, $role, $deviceToken = '') {
        UserSession::where('deviceToken', '=', $deviceToken)->delete();
        $userSession = UserSession::where('userId', '=', $userId)->first();
        if (is_null($userSession) || empty($userSession)) {
            $userSession = new UserSession();
            $userSession->userId = $userId;
            $userSession->role = $role;
            $userSession->deviceToken = $deviceToken;
        }
        $i = 0;
        do {
            $sessionId = sha1(microtime());
            $userSession->deviceToken = $deviceToken;
            $userSession->sessionId = $sessionId;
            // Safety guard
            if (++$i > 10) {
                throw new Exception('Unknown error 1.', WS_ERR_UNKNOWN);
            }
        } while (!$userSession->save());

        return $sessionId;
    }

    /**
     * get list of nightclubs followed by a user
     *
     * @return Response
     */
    public function getFollowedClubs() {
        $apiName = 'user/getFollowedClubs';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'selectedUserId' => array('required', 'integer'),
            'searchText' => array('string'),
            'exceptions' => array('array')
        );

        $userSession = null;
        $exceptions = '';
        $searchText = '';

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else if (is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first())) {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            } else {

                if (isset($_JSON['searchText']) && !empty($_JSON['searchText']))
                    $searchText = filter_var($_JSON['searchText'], FILTER_SANITIZE_STRING);

                if (isset($_JSON['exceptions']) && !empty($_JSON['exceptions']))
                    $exceptions = join(',', $_JSON['exceptions']);

                $nightclubsFollowed = NightclubFollower::getList($userSession->userId, 0, $_JSON['selectedUserId'], '', $exceptions, $searchText);

                $result = VkUtility::success($apiName, 'Records fetched successfully.');
                $result['nightclubsFollowed'] = $nightclubsFollowed;
                $result['nightclubsFollowedCount'] = count($nightclubsFollowed);
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * get list of friends ordered by distance
     *
     * @return Response
     */
    public function getFriendsNearBy() {
        $apiName = 'user/getFriendsNearBy';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'latitude' => array('numeric'),
            'longitude' => array('numeric'),
            'searchText' => array('string'),
            'exceptions' => array('array')
        );

        $userSession = null;

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else if (is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first())) {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            } else {
                $latitude = 0;
                $longitude = 0;
                $searchText = '';
                $exceptions = '';

                if (isset($_JSON['latitude']) && !empty($_JSON['latitude']))
                    $latitude = filter_var($_JSON['latitude'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

                if (isset($_JSON['longitude']) && !empty($_JSON['longitude']))
                    $longitude = filter_var($_JSON['longitude'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

                if (isset($_JSON['searchText']) && !empty($_JSON['searchText']))
                    $searchText = filter_var($_JSON['searchText'], FILTER_SANITIZE_STRING);

                if (isset($_JSON['exceptions']) && !empty($_JSON['exceptions']))
                    $exceptions = join(',', $_JSON['exceptions']);

                $friends = User::getFriendsNearByFriendsAndStrangers($userSession->userId, $latitude, $longitude, $searchText, $exceptions);
                //$friendRequests = Friend::getList(0,$userSession->userId);
                
                $result = VkUtility::success($apiName, 'Records fetched successfully');
                $result['friends'] = $friends;
                //$result['friendRequests'] = count($friendRequests);
            }
        }
        return Response::json($result)->header("Connection","close");
    }
    
    public function getMyFriends() {
        $apiName = 'user/getMyFriends';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'latitude' => array('numeric'),
            'longitude' => array('numeric'),
            'searchText' => array('string'),
            'exceptions' => array('array')
        );

        $userSession = null;

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else if (is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first())) {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            } else {
                $latitude = 0;
                $longitude = 0;
                $searchText = '';
                $exceptions = '';

                if (isset($_JSON['latitude']) && !empty($_JSON['latitude']))
                    $latitude = filter_var($_JSON['latitude'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

                if (isset($_JSON['longitude']) && !empty($_JSON['longitude']))
                    $longitude = filter_var($_JSON['longitude'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

                if (isset($_JSON['searchText']) && !empty($_JSON['searchText']))
                    $searchText = filter_var($_JSON['searchText'], FILTER_SANITIZE_STRING);

                if (isset($_JSON['exceptions']) && !empty($_JSON['exceptions']))
                    $exceptions = join(',', $_JSON['exceptions']);

                $forFriendsUserId = $userSession->userId;
                $friends = User::getFriendsOfFriend($userSession->userId,$forFriendsUserId, $latitude, $longitude, $searchText, $exceptions);
                
                $result = VkUtility::success($apiName, 'Records fetched successfully');
                $result['friends'] = $friends;
            }
        }
        return Response::json($result)->header("Connection","close");
    }
    
    public function getFriendsOfFriend() {
        $apiName = 'user/getFriendsOfFriend';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'latitude' => array('numeric'),
            'longitude' => array('numeric'),
            'searchText' => array('string'),
            'exceptions' => array('array'),
            'selectedUserId' => array('required')
        );

        $userSession = null;

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else if (is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first())) {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            } else if (is_null($users = User::where('id','=',$_JSON['selectedUserId'])->first())) {
                $result = VkUtility::error($apiName, 101, 'selected user does not exist');
            } else {
                $latitude = 0;
                $longitude = 0;
                $searchText = '';
                $exceptions = '';

                if (isset($_JSON['latitude']) && !empty($_JSON['latitude']))
                    $latitude = filter_var($_JSON['latitude'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

                if (isset($_JSON['longitude']) && !empty($_JSON['longitude']))
                    $longitude = filter_var($_JSON['longitude'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

                if (isset($_JSON['searchText']) && !empty($_JSON['searchText']))
                    $searchText = filter_var($_JSON['searchText'], FILTER_SANITIZE_STRING);

                if (isset($_JSON['exceptions']) && !empty($_JSON['exceptions']))
                    $exceptions = join(',', $_JSON['exceptions']);

                
                $friends = User::getFriendsOfFriend($userSession->userId,$users->id, $latitude, $longitude, $searchText, $exceptions);
                
                $result = VkUtility::success($apiName, 'Records fetched successfully');
                $result['friends'] = $friends;
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * get list of strangers ordered by distance
     *
     * @return Response
     */
    public function getStrangersNearBy() {
        $apiName = 'user/getStrangersNearBy';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'latitude' => array('numeric'),
            'longitude' => array('numeric'),
            'searchText' => array('string'),
            'exceptions' => array('array')
        );

        $userSession = null;

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else if (is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first())) {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            } else {
                $latitude = 0;
                $longitude = 0;
                $searchText = '';
                $exceptions = '';

                if (isset($_JSON['latitude']) && !empty($_JSON['latitude']))
                    $latitude = filter_var($_JSON['latitude'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

                if (isset($_JSON['longitude']) && !empty($_JSON['longitude']))
                    $longitude = filter_var($_JSON['longitude'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

                if (isset($_JSON['searchText']) && !empty($_JSON['searchText']))
                    $searchText = filter_var($_JSON['searchText'], FILTER_SANITIZE_STRING);

                if (isset($_JSON['exceptions']) && !empty($_JSON['exceptions']))
                    $exceptions = join(',', $_JSON['exceptions']);

                $strangers = User::getStrangersNearBy($userSession->userId, $latitude, $longitude, $searchText, $exceptions);

                $result = VkUtility::success($apiName, 'Records fetched successfully.');
                $result['strangers'] = $strangers;
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * Send push notification to a user
     *
     * @return Response
     */
    public function sendNotification() {
        $apiName = 'user/sendNotification';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'selectedJabberId' => array('required', 'string'),
            'message' => array('required', 'string')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else if (is_null($userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first())) {
                $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
            } else {
                $user = User::where('id', '=', $userSession->userId)->first();
                $selectedJabberId = filter_var($_JSON['selectedJabberId'],FILTER_SANITIZE_STRING);
                $selectedUser = User::where('jabberId', '=', $selectedJabberId)->first();
                $message = base64_decode($_JSON['message']);
                //$trimMessage = substr($message, 0, 100).'...';

                if (is_null($user))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else if (is_null($selectedUser) || empty($selectedUser))
                    $result = VkUtility::error($apiName, 99, 'Selected user does not exist.');
                else {
                    //send push notification
                    $selectedUserSession = UserSession::where('userId', '=', $selectedUser->id)->first();
                    if (!is_null($selectedUserSession) && !empty($selectedUserSession) && $selectedUserSession->deviceToken && $selectedUser->receiveNotification == 1) {
                        
                        $data = array(
                            'notificationType'=>config('constants.defaultChatNotificationType'), 
                            'senderUserId' => $userSession->userId,
                            'senderJabberId' => $user->jabberId,
                        );

                        VkUtility::sendApnsNotification($selectedUserSession->deviceToken, $message, $selectedUserSession->deviceBadge, $data);
                    }

                    $result = VkUtility::success($apiName, 'Notification sent successfully');
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    public function deactivateUserAccount() {
        $apiName = '1324activateAccount';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first();
                if (is_null($userSession))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else {
                    $user = User::where('id', '=', $userSession->userId)->first();
                    if (is_null($user))
                        $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                    else {
                        
                        $updateUsers = User::decrementFriendCount($user->id);
                        
                        $updateNightclubs = NightclubFollower::decrementFollowerCount($user->id);
                        
                        // Transfer Group Ownership to other users
                        $allChatRoom = ChatRoom::where('ownerUserId',$user->id)->get();
                        
                        foreach($allChatRoom as $chatRoom)
                        {
                            //find next occupant
                            $nextOccupant = ChatRoomOccupant::where('chatRoomJabberId', '=', $chatRoom->jabberId)->orderBy('createDate', 'asc')->first();
                            if(is_null($nextOccupant) || empty($nextOccupant))
                            {
                                //no occupant, delete chat room
                                $chatRoom->delete();
                            }
                            else
                            {
                                //make the next occupant admin
                                $chatRoom->ownerUserId = $nextOccupant->occupantUserId;
                                $chatRoom->save();
                            }
                        }

                        $user->delete();

                        $result = VkUtility::success($apiName, 'User account deleted successfully.');
                    }
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    public function reportUser() {
        $apiName = 'user/reportUser';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'reportedUserId' => array('required'),
            'reportReason' => array('string')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first();
                if (is_null($userSession))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else {
                    $user = User::where('id', '=', $userSession->userId)->first();
                    if (is_null($user))
                        $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                    else {
                        $reportReason = " ";

                        if (isset($_JSON['reportReason']) && !empty($_JSON['reportReason']))
                            $reportReason = filter_var($_JSON['reportReason'], FILTER_SANITIZE_STRING);

                        $userReport = new ReportUser();
                        $userReport->reporterUserId = $user->id;
                        $userReport->reportedUserId = $_JSON['reportedUserId'];
                        $userReport->reportReason = $reportReason;
                        $userReport->save();

                        $result = VkUtility::success($apiName, 'User reported successfully');
                    }
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    public function blockUser() {
        $apiName = 'user/blockUser';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'blockedUserId' => array('required','integer'),
            'blockReason' => array('string')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first();
                if (is_null($userSession))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else {
                    $user = User::where('id', '=', $userSession->userId)->first();
                    $blockUser = User::where('id', '=', $_JSON['blockedUserId'])->first();
                    if (is_null($blockUser))
                        //$result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                        $result = VkUtility::success($apiName, 'No data exist for selected user.');
                    else {
                        $blockReason = " ";

                        if (isset($_JSON['blockReason']) && !empty($_JSON['blockReason']))
                            $blockReason = filter_var($_JSON['blockReason'], FILTER_SANITIZE_STRING);

                        // Remove Old Notifications
                        Notification::where('senderUserId',$user->id)->where('receiverUserId',$_JSON['blockedUserId'])->delete();
                        Notification::where('receiverUserId',$user->id)->where('senderUserId',$_JSON['blockedUserId'])->delete();

                        // Do Unfriend
                        Friend::where('senderUserId', '=', $user->id)->where('receiverUserId', '=', $_JSON['blockedUserId'])->delete();
                        Friend::where('receiverUserId', '=', $user->id)->where('senderUserId', '=', $_JSON['blockedUserId'])->delete();

                        // Remove Wink
                        Wink::where('senderUserId', '=', $user->id)->where('receiverUserId', '=', $_JSON['blockedUserId'])->delete();
                        Wink::where('receiverUserId', '=', $user->id)->where('senderUserId', '=', $_JSON['blockedUserId'])->delete();

                        $userBlock = new BlockUser();
                        $userBlock->userId = $user->id;
                        $userBlock->blockedUserId = $_JSON['blockedUserId'];
                        $userBlock->blockReason = $blockReason;
                        $userBlock->save();

                        //Decreasse Login User friend count
                        $user->friendCount -= 1;
                        $user->save();
                        
                        //Decreasse Unfriend User friend count
                        $blockUser = User::where('id', '=', $_JSON['blockedUserId'])->first();
                        $blockUser->friendCount -= 1;
                        $blockUser->save();


                        $blockUser = User::where('id', '=', $_JSON['blockedUserId'])->first();

                        if (!is_null($blockUser) && !empty($blockUser) && $blockUser->deviceToken) {
                            
                            $data = array(
                                'notificationType'=>config('constants.defaultChatNotificationType'), 
                                'blockedJabberId' => $blockUser->jabberId,
                                'userJabberId' => $user->jabberId
                            );
                            $message = "$user->firstName $user->surName has block you.";
                            VkUtility::sendApnsNotification($blockUser->deviceToken, $message, $blockUser->deviceBadge, $data);
                        }

                        $result = VkUtility::success($apiName, 'User blocked successfully');
                        $result['blockUserJabberId'] = $blockUser->jabberId;
                    }
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    public function updateProfilePic() {
        $apiName = 'user/updateProfilePic';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'image' => array('required')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first();
                if (is_null($userSession))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else {

//                    $user = User::with('userSession')->whereHas('userSession', function($q)
//                    {
//                        $q->where('sessionId', '=', $_JSON['sessionId']);
//
//                    })->first();

                    $user = User::where('id', '=', $userSession->userId)->first();
                    if (is_null($user))
                        $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                    else {


                        if (isset($_JSON['image']) && !empty($_JSON['image'])) {
                            $imageDir = public_path() . config('constants.userImage');
                            $thumbDir = public_path() . config('constants.userThumb');
                            $maxWidth = config('constants.thumbMaxWidth');

                            $user->image = VkUtility::saveBase64ImagePng($_JSON['image'], $imageDir, $thumbDir, $maxWidth);
                        }

                        $user->save();

                        $result = VkUtility::success($apiName, 'User image updated successfully');
                        $result['user'] = User::getUserById($user->id, 0, 1);

                        $nightclubsFollowed = NightclubFollower::getList($user->id, 0, $user->id);
                        $result['user']->nightclubFollowCount = count($nightclubsFollowed);
                    }
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }

    /**
     * Update user current location (lat,long)
     *
     * @return Response
     */
    public function updateUserLocation() {
        $apiName = 'user/updateUserLocation';
        $_JSON = VkUtility::getJsonInput();
        $validationRules = array(
            'sessionId' => array('required'),
            'current_latitude' => array('numeric', 'required'),
            'current_longitude' => array('numeric', 'required')
        );

        if (!isset($_JSON) || empty($_JSON))
            $result = VkUtility::error($apiName, 99, 'No input received.');
        else {
            $validator = Validator::make($_JSON, $validationRules);
            if ($validator->fails()) {
                $result = VkUtility::error($apiName, 99, $validator->errors()->first());
            } else {
                $userSession = UserSession::where('sessionId', '=', $_JSON['sessionId'])->first();
                if (is_null($userSession))
                    $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                else {

                    $user = User::where('id', '=', $userSession->userId)->first();
                    if (is_null($user))
                        $result = VkUtility::error($apiName, 101, 'Your session has expired. Please login again.');
                    else {

                        if (isset($_JSON['current_latitude']) && !empty($_JSON['current_latitude']) && isset($_JSON['current_longitude']) && !empty($_JSON['current_longitude'])) {
                            $user->current_latitude = $_JSON['current_latitude'];
                            $user->current_longitude = $_JSON['current_longitude'];
                        } 

                        $user->save();
                        $result = VkUtility::success($apiName, 'User record saved successfully');
                    }
                }
            }
        }
        return Response::json($result)->header("Connection","close");
    }
}
