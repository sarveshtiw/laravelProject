<?php

namespace App\Http\Controllers;

use App\Models\Nightclub;
use App\Models\NightclubPhoto;
use App\Models\User;
use DB;
use App\Models\VenueType;
use App\Models\MusicGenre;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use App\Http\Middleware\VkUtility;
use \Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Response;

class NightclubController extends Controller {
    /*
      |--------------------------------------------------------------------------
      | Nightclub Controller
      |--------------------------------------------------------------------------
      |
      | This controller renders forms to create a nightclub record
      | And a list of all nightclub records
      |
     */

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('auth');
    }

    /**
     * Show the nightclub records to the user.
     *
     * @return Response
     */
    public function index() {
        $clientTimeZone = config('constants.defaultClientTimeZone');
        if($_COOKIE['clientTimeZone'])
            $clientTimeZone = $_COOKIE['clientTimeZone'];

        if(\Auth::user()->role == "club admin")
        {
            $nightclubDetails = Nightclub::getById(\Auth::user()->nightclubId);

            $monOpeningTime = date('H:i',strtotime($nightclubDetails->monOpeningTime));
            $givenMonOpeningTime = new \DateTime($monOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
            $givenMonOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
            $nightclubDetails->monOpeningTime = $givenMonOpeningTime->format("h:i a");

            $monClosingTime = date('H:i',strtotime($nightclubDetails->monClosingTime));
            $givenMonClosingTime = new \DateTime($monClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
            $givenMonClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
            $nightclubDetails->monClosingTime = $givenMonClosingTime->format("h:i a"); 

            $tueOpeningTime = date('H:i',strtotime($nightclubDetails->tueOpeningTime));
            $givenTueOpeningTime = new \DateTime($tueOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
            $givenTueOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
            $nightclubDetails->tueOpeningTime = $givenTueOpeningTime->format("h:i a");

            $tueClosingTime = date('H:i',strtotime($nightclubDetails->tueClosingTime));
            $givenTueClosingTime = new \DateTime($tueClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
            $givenTueClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
            $nightclubDetails->tueClosingTime = $givenTueClosingTime->format("h:i a"); 

            $wedOpeningTime = date('H:i',strtotime($nightclubDetails->wedOpeningTime));
            $givenWedOpeningTime = new \DateTime($wedOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
            $givenWedOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
            $nightclubDetails->wedOpeningTime = $givenWedOpeningTime->format("h:i a");

            $wedClosingTime = date('H:i',strtotime($nightclubDetails->wedClosingTime));
            $givenWedClosingTime = new \DateTime($wedClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
            $givenWedClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
            $nightclubDetails->wedClosingTime = $givenWedClosingTime->format("h:i a"); 

            $thuOpeningTime = date('H:i',strtotime($nightclubDetails->thuOpeningTime));
            $givenThuOpeningTime = new \DateTime($thuOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
            $givenThuOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
            $nightclubDetails->thuOpeningTime = $givenThuOpeningTime->format("h:i a");

            $thuClosingTime = date('H:i',strtotime($nightclubDetails->thuClosingTime));
            $givenThuClosingTime = new \DateTime($thuClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
            $givenThuClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
            $nightclubDetails->thuClosingTime = $givenThuClosingTime->format("h:i a"); 

            $friOpeningTime = date('H:i',strtotime($nightclubDetails->friOpeningTime));
            $givenFriOpeningTime = new \DateTime($friOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
            $givenFriOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
            $nightclubDetails->friOpeningTime = $givenFriOpeningTime->format("h:i a");

            $friClosingTime = date('H:i',strtotime($nightclubDetails->friClosingTime));
            $givenFriClosingTime = new \DateTime($friClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
            $givenFriClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
            $nightclubDetails->friClosingTime = $givenFriClosingTime->format("h:i a"); 

            $satOpeningTime = date('H:i',strtotime($nightclubDetails->satOpeningTime));
            $givenSatOpeningTime = new \DateTime($satOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
            $givenSatOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
            $nightclubDetails->satOpeningTime = $givenSatOpeningTime->format("h:i a");

            $satClosingTime = date('H:i',strtotime($nightclubDetails->satClosingTime));
            $givenSatClosingTime = new \DateTime($satClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
            $givenSatClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
            $nightclubDetails->satClosingTime = $givenSatClosingTime->format("h:i a"); 

            $sunOpeningTime = date('H:i',strtotime($nightclubDetails->sunOpeningTime));
            $givenSunOpeningTime = new \DateTime($sunOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
            $givenSunOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
            $nightclubDetails->sunOpeningTime = $givenSunOpeningTime->format("h:i a");

            $sunClosingTime = date('H:i',strtotime($nightclubDetails->sunClosingTime));
            $givenSunClosingTime = new \DateTime($sunClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
            $givenSunClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
            $nightclubDetails->sunClosingTime = $givenSunClosingTime->format("h:i a"); 

            $nightclubImages = NightclubPhoto::getByClubId(\Auth::user()->nightclubId);

            return view('nightclub.view')->with('nightclubDetails', $nightclubDetails)->with('nightclubImages',$nightclubImages);
        } else{
            $nightclubs = Nightclub::paginate(10);
            
            foreach($nightclubs as $nightclub) 
            {
                $monOpeningTime = date('H:i',strtotime($nightclub->monOpeningTime));
                $givenMonOpeningTime = new \DateTime($monOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenMonOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->monOpeningTime = $givenMonOpeningTime->format("h:i a");

                $monClosingTime = date('H:i',strtotime($nightclub->monClosingTime));
                $givenMonClosingTime = new \DateTime($monClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenMonClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->monClosingTime = $givenMonClosingTime->format("h:i a"); 

                $tueOpeningTime = date('H:i',strtotime($nightclub->tueOpeningTime));
                $givenTueOpeningTime = new \DateTime($tueOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenTueOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->tueOpeningTime = $givenTueOpeningTime->format("h:i a");

                $tueClosingTime = date('H:i',strtotime($nightclub->tueClosingTime));
                $givenTueClosingTime = new \DateTime($tueClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenTueClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->tueClosingTime = $givenTueClosingTime->format("h:i a"); 

                $wedOpeningTime = date('H:i',strtotime($nightclub->wedOpeningTime));
                $givenWedOpeningTime = new \DateTime($wedOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenWedOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->wedOpeningTime = $givenWedOpeningTime->format("h:i a");

                $wedClosingTime = date('H:i',strtotime($nightclub->wedClosingTime));
                $givenWedClosingTime = new \DateTime($wedClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenWedClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->wedClosingTime = $givenWedClosingTime->format("h:i a"); 

                $thuOpeningTime = date('H:i',strtotime($nightclub->thuOpeningTime));
                $givenThuOpeningTime = new \DateTime($thuOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenThuOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->thuOpeningTime = $givenThuOpeningTime->format("h:i a");

                $thuClosingTime = date('H:i',strtotime($nightclub->thuClosingTime));
                $givenThuClosingTime = new \DateTime($thuClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenThuClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->thuClosingTime = $givenThuClosingTime->format("h:i a"); 

                $friOpeningTime = date('H:i',strtotime($nightclub->friOpeningTime));
                $givenFriOpeningTime = new \DateTime($friOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenFriOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->friOpeningTime = $givenFriOpeningTime->format("h:i a");

                $friClosingTime = date('H:i',strtotime($nightclub->friClosingTime));
                $givenFriClosingTime = new \DateTime($friClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenFriClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->friClosingTime = $givenFriClosingTime->format("h:i a"); 

                $satOpeningTime = date('H:i',strtotime($nightclub->satOpeningTime));
                $givenSatOpeningTime = new \DateTime($satOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenSatOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->satOpeningTime = $givenSatOpeningTime->format("h:i a");

                $satClosingTime = date('H:i',strtotime($nightclub->satClosingTime));
                $givenSatClosingTime = new \DateTime($satClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenSatClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->satClosingTime = $givenSatClosingTime->format("h:i a"); 

                $sunOpeningTime = date('H:i',strtotime($nightclub->sunOpeningTime));
                $givenSunOpeningTime = new \DateTime($sunOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenSunOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->sunOpeningTime = $givenSunOpeningTime->format("h:i a");

                $sunClosingTime = date('H:i',strtotime($nightclub->sunClosingTime));
                $givenSunClosingTime = new \DateTime($sunClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenSunClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->sunClosingTime = $givenSunClosingTime->format("h:i a"); 
            }
            return view('nightclub.index')->with('nightclubs', $nightclubs);
        }  
    }

    public function searchNightClub() {
        $nightclubName = trim(input::get('nightclubName'));
        $location = trim(input::get('location'));

        if($_COOKIE['clientTimeZone'])
            $clientTimeZone = $_COOKIE['clientTimeZone'];
        
        $searchCriteria['nightclubName'] = $nightclubName;
        $searchCriteria['location'] = $location;

        $nightclubs = Nightclub::where('nightclubName', 'LIKE', "%$nightclubName%")
                        ->where('location', 'LIKE', "%$location%")->paginate(10);

        foreach($nightclubs as $nightclub) 
        {
            $monOpeningTime = date('H:i',strtotime($nightclub->monOpeningTime));
                $givenMonOpeningTime = new \DateTime($monOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenMonOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->monOpeningTime = $givenMonOpeningTime->format("h:i a");

                $monClosingTime = date('H:i',strtotime($nightclub->monClosingTime));
                $givenMonClosingTime = new \DateTime($monClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenMonClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->monClosingTime = $givenMonClosingTime->format("h:i a"); 

                $tueOpeningTime = date('H:i',strtotime($nightclub->tueOpeningTime));
                $givenTueOpeningTime = new \DateTime($tueOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenTueOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->tueOpeningTime = $givenTueOpeningTime->format("h:i a");

                $tueClosingTime = date('H:i',strtotime($nightclub->tueClosingTime));
                $givenTueClosingTime = new \DateTime($tueClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenTueClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->tueClosingTime = $givenTueClosingTime->format("h:i a"); 

                $wedOpeningTime = date('H:i',strtotime($nightclub->wedOpeningTime));
                $givenWedOpeningTime = new \DateTime($wedOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenWedOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->wedOpeningTime = $givenWedOpeningTime->format("h:i a");

                $wedClosingTime = date('H:i',strtotime($nightclub->wedClosingTime));
                $givenWedClosingTime = new \DateTime($wedClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenWedClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->wedClosingTime = $givenWedClosingTime->format("h:i a"); 

                $thuOpeningTime = date('H:i',strtotime($nightclub->thuOpeningTime));
                $givenThuOpeningTime = new \DateTime($thuOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenThuOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->thuOpeningTime = $givenThuOpeningTime->format("h:i a");

                $thuClosingTime = date('H:i',strtotime($nightclub->thuClosingTime));
                $givenThuClosingTime = new \DateTime($thuClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenThuClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->thuClosingTime = $givenThuClosingTime->format("h:i a"); 

                $friOpeningTime = date('H:i',strtotime($nightclub->friOpeningTime));
                $givenFriOpeningTime = new \DateTime($friOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenFriOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->friOpeningTime = $givenFriOpeningTime->format("h:i a");

                $friClosingTime = date('H:i',strtotime($nightclub->friClosingTime));
                $givenFriClosingTime = new \DateTime($friClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenFriClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->friClosingTime = $givenFriClosingTime->format("h:i a"); 

                $satOpeningTime = date('H:i',strtotime($nightclub->satOpeningTime));
                $givenSatOpeningTime = new \DateTime($satOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenSatOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->satOpeningTime = $givenSatOpeningTime->format("h:i a");

                $satClosingTime = date('H:i',strtotime($nightclub->satClosingTime));
                $givenSatClosingTime = new \DateTime($satClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenSatClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->satClosingTime = $givenSatClosingTime->format("h:i a"); 

                $sunOpeningTime = date('H:i',strtotime($nightclub->sunOpeningTime));
                $givenSunOpeningTime = new \DateTime($sunOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenSunOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->sunOpeningTime = $givenSunOpeningTime->format("h:i a");

                $sunClosingTime = date('H:i',strtotime($nightclub->sunClosingTime));
                $givenSunClosingTime = new \DateTime($sunClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
                $givenSunClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
                $nightclub->sunClosingTime = $givenSunClosingTime->format("h:i a"); 
        }

        return view('nightclub.index')->with('nightclubs', $nightclubs)->with('searchCriteria', $searchCriteria);
    }

    public function showNightClubForm() {
        $nightclubImages = array();
        $nightclubId = base64_decode(input::get('nightclubId'));
        if(isset($nightclubId) && !empty($nightclubId)){
            $nightclubDetails = Nightclub::getById($nightclubId);
            $nightclubImages = NightclubPhoto::getByClubId($nightclubId);
            $venueTypeList = array();
            $venueTypeList = DB::table('venueType as vt')->where('isDisabled', 0)->get();
            $musicGenreList = array();
            $musicGenreList = DB::table('musicGenre as mg')->where('isDisabled', 0)->get();
            $userDetails = User::where('nightclubId', $nightclubId)->where('role', 'club admin')->first();
            return view('nightclub.create')->with('nightclubDetails', $nightclubDetails)->with('venueTypeList',$venueTypeList)->with('musicGenreList',$musicGenreList)->with('nightclubImages',$nightclubImages)->with('userDetails',$userDetails);
        }

        $venueTypeList = array();
        $venueTypeList = DB::table('venueType as vt')->where('isDisabled', 0)->get();
        $musicGenreList = array();
        $musicGenreList = DB::table('musicGenre as mg')->where('isDisabled', 0)->get();
        return view('nightclub.create')->with('venueTypeList',$venueTypeList)->with('musicGenreList',$musicGenreList)->with('nightclubImages',$nightclubImages);
    }

    public function createNightClub() {
        $nightclubDetails = input::all();
        
        $rules = array(
            'id' => array('numeric'),
            'name' => array('required'),
            'location' => array('required'),
            'coverImage' => array('required_without:id','image'),
            'logo' => array('required_without:id','image'),
            'hd_monOpeningTime' => array('required'),
            'hd_monClosingTime' => array('required'),
            'briefInfo' => array('required','string', 'max:256'),
            'venueType' => array('required','string'),
            'dressCode' => array('required','string'),
            'musicGenre' => array('required','string'),
            'popularity' => array('required','string'),
            'budget' => array('required','numeric'),
            'fbLink' => array('string'),
            'twtLink' => array('string'),
            'instLink' => array('string'),
            'email' => array('required', 'email', 'unique:user')
        );
        //echo '<pre>'; print_r($nightclubDetails);die;
        $nightclub = null;
        $message = array('coverImage.required_without' => 'The cover image field is required.', 'logo.required_without' => 'The logo field is required.', 'hd_monOpeningTime.required' => 'The club opening time field is required.', 'hd_monClosingTime.required' => 'The club closing time field is required.');
        if (isset($nightclubDetails['id']) && !empty($nightclubDetails['id'])) {

            $nightclub = Nightclub::where('id', '=', $nightclubDetails['id'])->first();
            if (is_null($nightclub) || empty($nightclub))
                return Redirect::to('nightclub/create')->withErrors(array('Invalid user id.'))->withInput($nightclubDetails);
            $userDetails = User::where('nightclubId', $nightclubDetails['id'])->where('role', 'club admin')->first();
            if (isset($nightclubDetails['email']) && !empty($nightclubDetails['email']) && !is_null($userDetails))
                $rules['email'] = array('email', 'unique:user,email,' . $userDetails->id);
        } else {
            $nightclub = new Nightclub();
        }
            
        $validator = Validator::make($nightclubDetails, $rules, $message);
        if ($validator->fails()) {
            return Redirect::to('nightclub/create')->withErrors($validator)->withInput($nightclubDetails);
        } else {
            if (isset($nightclubDetails['id']) && !empty($nightclubDetails['id'])) {
                $clubDetails = Nightclub::where('id', '=', $nightclubDetails['id'])->first();
                if (is_null($clubDetails)) {
                    abort(401, 'Unauthorized action 2.');
                }
                if (isset($nightclubDetails['coverImage']) && !empty($nightclubDetails['coverImage'])) {
                    $oldCoverPicName = $clubDetails->coverImage;
                    $coverImageDir = public_path() . config('constants.nightclubCoverImage');
                    $coverThumbDir = public_path() . config('constants.nightclubCoverThumb');

                    @unlink($coverImageDir . $oldCoverPicName);
                    @unlink($coverThumbDir . $oldCoverPicName);
                }
                if (isset($nightclubDetails['logo']) && !empty($nightclubDetails['logo'])) {
                    $oldLogoPicName = $clubDetails->logoImage;
                    $logoImageDir = public_path() . config('constants.nightclubLogoImage');
                    $logoThumbDir = public_path() . config('constants.nightclubLogoThumb');

                    @unlink($logoImageDir . $oldLogoPicName);
                    @unlink($logoThumbDir . $oldLogoPicName);
                }

                $nightclub = Nightclub::find($nightclubDetails['id']);
            } else {
                $nightclub = new Nightclub();
            }
            $nightclub->nightclubName = $nightclubDetails['name'];

            $clientTimeZone = config('constants.defaultClientTimeZone');
            if($_COOKIE['clientTimeZone'])
                $clientTimeZone = $_COOKIE['clientTimeZone'];
            
            $monOpeningTime = date('H:i',strtotime($nightclubDetails['hd_monOpeningTime']));
            $givenMonOpeningTime = new \DateTime($monOpeningTime, new \DateTimeZone($clientTimeZone));
            $givenMonOpeningTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcMonOpeningTime = $givenMonOpeningTime->format("H:i:s");

            $monClosingTime = date('H:i',strtotime($nightclubDetails['hd_monClosingTime']));
            $givenMonClosingTime = new \DateTime($monClosingTime, new \DateTimeZone($clientTimeZone));
            $givenMonClosingTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcMonClosingTime = $givenMonClosingTime->format("H:i:s");

            $tueOpeningTime = date('H:i',strtotime($nightclubDetails['hd_tueOpeningTime']));
            $givenTueOpeningTime = new \DateTime($tueOpeningTime, new \DateTimeZone($clientTimeZone));
            $givenTueOpeningTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcTueOpeningTime = $givenTueOpeningTime->format("H:i:s"); 

            $tueClosingTime = date('H:i',strtotime($nightclubDetails['hd_tueClosingTime']));
            $givenTueClosingTime= new \DateTime($tueClosingTime, new \DateTimeZone($clientTimeZone));
            $givenTueClosingTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcTueClosingTime = $givenTueClosingTime->format("H:i:s");

            $wedOpeningTime = date('H:i',strtotime($nightclubDetails['hd_wedOpeningTime']));
            $givenWedOpeningTime = new \DateTime($wedOpeningTime, new \DateTimeZone($clientTimeZone));
            $givenWedOpeningTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcWedOpeningTime = $givenWedOpeningTime->format("H:i:s"); 

            $wedClosingTime = date('H:i',strtotime($nightclubDetails['hd_wedClosingTime']));
            $givenWedClosingTime = new \DateTime($wedClosingTime, new \DateTimeZone($clientTimeZone));
            $givenWedClosingTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcWedClosingTime = $givenWedClosingTime->format("H:i:s");

            $thuOpeningTime = date('H:i',strtotime($nightclubDetails['hd_thuOpeningTime']));
            $givenThuOpeningTime = new \DateTime($thuOpeningTime, new \DateTimeZone($clientTimeZone));
            $givenThuOpeningTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcThuOpeningTime = $givenThuOpeningTime->format("H:i:s"); 

            $thuClosingTime = date('H:i',strtotime($nightclubDetails['hd_thuClosingTime']));
            $givenThuClosingTime = new \DateTime($thuClosingTime, new \DateTimeZone($clientTimeZone));
            $givenThuClosingTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcThuClosingTime = $givenThuClosingTime->format("H:i:s");

            $friOpeningTime = date('H:i',strtotime($nightclubDetails['hd_friOpeningTime']));
            $givenFriOpeningTime = new \DateTime($friOpeningTime, new \DateTimeZone($clientTimeZone));
            $givenFriOpeningTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcFriOpeningTime = $givenFriOpeningTime->format("H:i:s");

            $friClosingTime = date('H:i',strtotime($nightclubDetails['hd_friClosingTime']));
            $givenFriClosingTime = new \DateTime($friClosingTime, new \DateTimeZone($clientTimeZone));
            $givenFriClosingTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcFriClosingTime = $givenFriClosingTime->format("H:i:s"); 

            $satOpeningTime = date('H:i',strtotime($nightclubDetails['hd_satOpeningTime']));
            $givenSatOpeningTime = new \DateTime($satOpeningTime, new \DateTimeZone($clientTimeZone));
            $givenSatOpeningTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcSatOpeningTime = $givenSatOpeningTime->format("H:i:s");

            $satClosingTime = date('H:i',strtotime($nightclubDetails['hd_satClosingTime']));
            $givenSatClosingTime = new \DateTime($satClosingTime, new \DateTimeZone($clientTimeZone));
            $givenSatClosingTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcSatClosingTime = $givenSatClosingTime->format("H:i:s"); 

            $sunOpeningTime = date('H:i',strtotime($nightclubDetails['hd_sunOpeningTime']));
            $givenSunOpeningTime = new \DateTime($sunOpeningTime, new \DateTimeZone($clientTimeZone));
            $givenSunOpeningTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcSunOpeningTime = $givenSunOpeningTime->format("H:i:s");

            $sunClosingTime = date('H:i',strtotime($nightclubDetails['hd_sunClosingTime']));
            $givenSunClosingTime = new \DateTime($sunClosingTime, new \DateTimeZone($clientTimeZone));
            $givenSunClosingTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcSunClosingTime = $givenSunClosingTime->format("H:i:s"); 

            $nightclub->monOpeningTime = $utcMonOpeningTime;
            $nightclub->monClosingTime = $utcMonClosingTime;
            $nightclub->tueOpeningTime = $utcTueOpeningTime;
            $nightclub->tueClosingTime = $utcTueClosingTime;

            $nightclub->wedOpeningTime = $utcWedOpeningTime;
            $nightclub->wedClosingTime = $utcWedClosingTime;
            $nightclub->thuOpeningTime = $utcThuOpeningTime;
            $nightclub->thuClosingTime = $utcThuClosingTime;

            $nightclub->friOpeningTime = $utcFriOpeningTime;
            $nightclub->friClosingTime = $utcFriClosingTime;
            $nightclub->satOpeningTime = $utcSatOpeningTime;
            $nightclub->satClosingTime = $utcSatClosingTime;

            $nightclub->sunOpeningTime = $utcSunOpeningTime;
            $nightclub->sunClosingTime = $utcSunClosingTime;


            $nightclub->facebookLink = $nightclubDetails['facebookLink'];
            $nightclub->twitterLink = $nightclubDetails['twitterLink'];
            $nightclub->instagramLink = $nightclubDetails['instagramLink'];

            if (isset($nightclubDetails['briefInfo']) && !empty($nightclubDetails['briefInfo']))
                $nightclub->briefInfo = htmlspecialchars($nightclubDetails['briefInfo']);

            if (isset($nightclubDetails['subVenueType']) && !empty($nightclubDetails['subVenueType']) && $nightclubDetails['subVenueType'] !='N/A')
                $nightclub->subVenueType = $nightclubDetails['subVenueType'];

            if (isset($nightclubDetails['venueType']) && !empty($nightclubDetails['venueType']))
                $nightclub->venueType = $nightclubDetails['venueType'];

            if (isset($nightclubDetails['dressCode']) && !empty($nightclubDetails['dressCode']))
                $nightclub->dressCode = $nightclubDetails['dressCode'];

            if (isset($nightclubDetails['musicGenre']) && !empty($nightclubDetails['musicGenre']))
                $nightclub->musicGenre = $nightclubDetails['musicGenre'];

            if (isset($nightclubDetails['budget']) && !empty($nightclubDetails['budget']))
                $nightclub->budget = $nightclubDetails['budget'];
            
            if (isset($nightclubDetails['subMusicGenre']) && !empty($nightclubDetails['subMusicGenre']) && $nightclubDetails['subMusicGenre'] !='N/A')
                $nightclub->subMusicGenre = $nightclubDetails['subMusicGenre'];

            if (isset($nightclubDetails['popularity']) && !empty($nightclubDetails['popularity']))
                $nightclub->popularity = $nightclubDetails['popularity'];

            if (isset($nightclubDetails['location']) && !empty($nightclubDetails['location'])) {
                $locationComponents = VkUtility::getLocationFromPostcode($nightclubDetails['location']);
                $nightclub->latitude = $locationComponents['latitude'];
                $nightclub->longitude = $locationComponents['longitude'];
                $nightclub->location = $locationComponents['formattedAddress'];
            }

            if (isset($nightclubDetails['coverImage']) && !empty($nightclubDetails['coverImage'])) {
                $image = input::file('coverImage');
                $imageDir = public_path() . config('constants.nightclubCoverImage'); 
                $thumbDir = public_path() . config('constants.nightclubCoverThumb');
                $maxWidth = config('constants.thumbMaxWidth');
                $nightclub->coverImage = VkUtility::saveImageFile($image, $imageDir, $thumbDir, $maxWidth);
            }
            if (isset($nightclubDetails['logo']) && !empty($nightclubDetails['logo'])) {
                $image = input::file('logo');
                $imageDir = public_path() . config('constants.nightclubLogoImage');
                $thumbDir = public_path() . config('constants.nightclubLogoThumb');
                $maxWidth = config('constants.thumbMaxWidth');
                $nightclub->logo = VkUtility::saveImageFile($image, $imageDir, $thumbDir, $maxWidth);
            }

            $nightclub->save();

            if (isset($nightclubDetails['id']) && !empty($nightclubDetails['id'])) {
                return Redirect::to('nightclub/update/' . $nightclubDetails['id'])->withInput()->with('flash_message', 'Club Updated Successfully.');
            }

            if (isset($nightclubDetails['email']) && !empty($nightclubDetails['email'])) {

                $adminEmail = $nightclubDetails['email'];
                $pass = VkUtility::randomString(6);
                $password = VkUtility::getEncryptedPassword($pass, $adminEmail);

                $user = new User();
                $user->nightclubId = $nightclub->id;
                $emailString = explode('@', $nightclubDetails['email']);
                $username = $emailString[0];

                $user->username = $username;
                $user->role = "club admin";
                $user->email = $adminEmail;
                $user->password = $password;
                //$user->image = public_path() . config('constants.nightclubCoverThumb').$nightclub->logo;
                $user->save();

                $subject = "admin password";
                $data = array('role'=>'club admin', 'userName'=>$username, 'password' => $pass);

                \Mail::send('emails.sendAdminPassword', ['key' => $data], function($message)use($subject, $adminEmail) {
                    $message->to($adminEmail, 'Bendr Admin')->subject($subject);
                });
            }

            return Redirect::to('nightclub/create?nightclubId='.base64_encode($nightclub->id))->with('flash_message', 'Club Added Successfully. You can now add additional images for the Club');
        }
    }

    public function editNightClub() {
        $nightclubDetails = input::all();
        $rules = array(
            'id' => array('numeric'),
            'name' => array('required'),
            'location' => array('required'),
            'coverImage' => array('required_without:id','image'),
            'logo' => array('required_without:id','image'),
            'hd_monOpeningTime' => array('required'),
            'hd_monClosingTime' => array('required'),
            'briefInfo' => array('required','string', 'max:256'),
            'venueType' => array('required','string'),
            'dressCode' => array('required','string'),
            'musicGenre' => array('required','string'),
            // 'popularity' => array('required','string'),
            'budget' => array('required','numeric'),
            'fbLink' => array('string'),
            'twtLink' => array('string'),
            'instLink' => array('string'),
            'email' => array('required', 'email', 'unique:user')
        );

        $nightclub = null;
        $message = array('coverImage.required_without' => 'The cover image field is required.', 'logo.required_without' => 'The logo field is required.', 'hd_monOpeningTime.required' => 'The club opening time field is required.', 'hd_monClosingTime.required' => 'The club closing time field is required.');
        if (isset($nightclubDetails['id']) && !empty($nightclubDetails['id'])) {

            $nightclub = Nightclub::where('id', '=', $nightclubDetails['id'])->first();
            if (is_null($nightclub) || empty($nightclub))
                return Redirect::to('nightclub/create')->withErrors(array('Invalid user id.'))->withInput($nightclubDetails);
            $userDetails = User::where('nightclubId', $nightclubDetails['id'])->where('role', 'club admin')->first();
            if (isset($nightclubDetails['email']) && !empty($nightclubDetails['email']) && !is_null($userDetails))
                $rules['email'] = array('email', 'unique:user,email,' . $userDetails->id);
        } else {
            $nightclub = new Nightclub();
        }
            
        $validator = Validator::make($nightclubDetails, $rules, $message);
        if ($validator->fails()) {
            return Redirect::to('nightclub/update/' . $nightclubDetails['id'])->withInput($nightclubDetails)->withErrors($validator);
        } else {
            
            $clubDetails = Nightclub::where('id', '=', $nightclubDetails['id'])->first();
            if (is_null($clubDetails)) {
                abort(401, 'Unauthorized action 2.');
            }
            if (isset($nightclubDetails['coverImage']) && !empty($nightclubDetails['coverImage'])) {
                $oldCoverPicName = $clubDetails->coverImage;
                $coverImageDir = public_path() . config('constants.nightclubCoverImage');
                $coverThumbDir = public_path() . config('constants.nightclubCoverThumb');

                @unlink($coverImageDir . $oldCoverPicName);
                @unlink($coverThumbDir . $oldCoverPicName);
            }
            if (isset($nightclubDetails['logo']) && !empty($nightclubDetails['logo'])) {
                $oldLogoPicName = $clubDetails->logoImage;
                $logoImageDir = public_path() . config('constants.nightclubLogoImage');
                $logoThumbDir = public_path() . config('constants.nightclubLogoThumb');

                @unlink($logoImageDir . $oldLogoPicName);
                @unlink($logoThumbDir . $oldLogoPicName);
            }

            $nightclub = Nightclub::find($nightclubDetails['id']);
            
            $nightclub->nightclubName = $nightclubDetails['name'];
            
            $clientTimeZone = config('constants.defaultClientTimeZone');
            if($_COOKIE['clientTimeZone'])
                $clientTimeZone = $_COOKIE['clientTimeZone'];
            
            $monOpeningTime = date('H:i',strtotime($nightclubDetails['hd_monOpeningTime']));
            $givenMonOpeningTime = new \DateTime($monOpeningTime, new \DateTimeZone($clientTimeZone));
            $givenMonOpeningTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcMonOpeningTime = $givenMonOpeningTime->format("H:i:s");

            $monClosingTime = date('H:i',strtotime($nightclubDetails['hd_monClosingTime']));
            $givenMonClosingTime = new \DateTime($monClosingTime, new \DateTimeZone($clientTimeZone));
            $givenMonClosingTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcMonClosingTime = $givenMonClosingTime->format("H:i:s");

            $tueOpeningTime = date('H:i',strtotime($nightclubDetails['hd_tueOpeningTime']));
            $givenTueOpeningTime = new \DateTime($tueOpeningTime, new \DateTimeZone($clientTimeZone));
            $givenTueOpeningTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcTueOpeningTime = $givenTueOpeningTime->format("H:i:s"); 

            $tueClosingTime = date('H:i',strtotime($nightclubDetails['hd_tueClosingTime']));
            $givenTueClosingTime= new \DateTime($tueClosingTime, new \DateTimeZone($clientTimeZone));
            $givenTueClosingTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcTueClosingTime = $givenTueClosingTime->format("H:i:s");

            $wedOpeningTime = date('H:i',strtotime($nightclubDetails['hd_wedOpeningTime']));
            $givenWedOpeningTime = new \DateTime($wedOpeningTime, new \DateTimeZone($clientTimeZone));
            $givenWedOpeningTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcWedOpeningTime = $givenWedOpeningTime->format("H:i:s"); 

            $wedClosingTime = date('H:i',strtotime($nightclubDetails['hd_wedClosingTime']));
            $givenWedClosingTime = new \DateTime($wedClosingTime, new \DateTimeZone($clientTimeZone));
            $givenWedClosingTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcWedClosingTime = $givenWedClosingTime->format("H:i:s");

            $thuOpeningTime = date('H:i',strtotime($nightclubDetails['hd_thuOpeningTime']));
            $givenThuOpeningTime = new \DateTime($thuOpeningTime, new \DateTimeZone($clientTimeZone));
            $givenThuOpeningTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcThuOpeningTime = $givenThuOpeningTime->format("H:i:s"); 

            $thuClosingTime = date('H:i',strtotime($nightclubDetails['hd_thuClosingTime']));
            $givenThuClosingTime = new \DateTime($thuClosingTime, new \DateTimeZone($clientTimeZone));
            $givenThuClosingTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcThuClosingTime = $givenThuClosingTime->format("H:i:s");

            $friOpeningTime = date('H:i',strtotime($nightclubDetails['hd_friOpeningTime']));
            $givenFriOpeningTime = new \DateTime($friOpeningTime, new \DateTimeZone($clientTimeZone));
            $givenFriOpeningTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcFriOpeningTime = $givenFriOpeningTime->format("H:i:s");

            $friClosingTime = date('H:i',strtotime($nightclubDetails['hd_friClosingTime']));
            $givenFriClosingTime = new \DateTime($friClosingTime, new \DateTimeZone($clientTimeZone));
            $givenFriClosingTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcFriClosingTime = $givenFriClosingTime->format("H:i:s"); 

            $satOpeningTime = date('H:i',strtotime($nightclubDetails['hd_satOpeningTime']));
            $givenSatOpeningTime = new \DateTime($satOpeningTime, new \DateTimeZone($clientTimeZone));
            $givenSatOpeningTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcSatOpeningTime = $givenSatOpeningTime->format("H:i:s");

            $satClosingTime = date('H:i',strtotime($nightclubDetails['hd_satClosingTime']));
            $givenSatClosingTime = new \DateTime($satClosingTime, new \DateTimeZone($clientTimeZone));
            $givenSatClosingTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcSatClosingTime = $givenSatClosingTime->format("H:i:s"); 

            $sunOpeningTime = date('H:i',strtotime($nightclubDetails['hd_sunOpeningTime']));
            $givenSunOpeningTime = new \DateTime($sunOpeningTime, new \DateTimeZone($clientTimeZone));
            $givenSunOpeningTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcSunOpeningTime = $givenSunOpeningTime->format("H:i:s");

            $sunClosingTime = date('H:i',strtotime($nightclubDetails['hd_sunClosingTime']));
            $givenSunClosingTime = new \DateTime($sunClosingTime, new \DateTimeZone($clientTimeZone));
            $givenSunClosingTime->setTimezone(new \DateTimeZone(config('constants.UTCTimeZone')));
            $utcSunClosingTime = $givenSunClosingTime->format("H:i:s"); 

            $nightclub->monOpeningTime = $utcMonOpeningTime;
            $nightclub->monClosingTime = $utcMonClosingTime;
            $nightclub->tueOpeningTime = $utcTueOpeningTime;
            $nightclub->tueClosingTime = $utcTueClosingTime;

            $nightclub->wedOpeningTime = $utcWedOpeningTime;
            $nightclub->wedClosingTime = $utcWedClosingTime;
            $nightclub->thuOpeningTime = $utcThuOpeningTime;
            $nightclub->thuClosingTime = $utcThuClosingTime;

            $nightclub->friOpeningTime = $utcFriOpeningTime;
            $nightclub->friClosingTime = $utcFriClosingTime;
            $nightclub->satOpeningTime = $utcSatOpeningTime;
            $nightclub->satClosingTime = $utcSatClosingTime;

            $nightclub->sunOpeningTime = $utcSunOpeningTime;
            $nightclub->sunClosingTime = $utcSunClosingTime;

            $nightclub->facebookLink = $nightclubDetails['facebookLink'];
            $nightclub->twitterLink = $nightclubDetails['twitterLink'];
            $nightclub->instagramLink = $nightclubDetails['instagramLink'];


            $nightclub->briefInfo = htmlspecialchars($nightclubDetails['briefInfo']);
            $nightclub->venueType = $nightclubDetails['venueType'];
            $nightclub->dressCode = $nightclubDetails['dressCode'];
            $nightclub->musicGenre = $nightclubDetails['musicGenre'];
            $nightclub->budget = $nightclubDetails['budget'];
            // $nightclub->popularity = $nightclubDetails['popularity'];
            if (isset($nightclubDetails['popularity']) && !empty($nightclubDetails['popularity']))
                $nightclub->popularity = $nightclubDetails['popularity'];
            
            if ($nightclubDetails['subMusicGenre'] !='N/A')
                $nightclub->subMusicGenre = $nightclubDetails['subMusicGenre'];

            if ($nightclubDetails['subVenueType'] !='N/A')
                $nightclub->subVenueType = $nightclubDetails['subVenueType'];
            

            if (isset($nightclubDetails['location']) && !empty($nightclubDetails['location'])) {
                $locationComponents = VkUtility::getLocationFromPostcode($nightclubDetails['location']);
                $nightclub->latitude = $locationComponents['latitude'];
                $nightclub->longitude = $locationComponents['longitude'];
                $nightclub->location = $locationComponents['formattedAddress'];
            }

            if (isset($nightclubDetails['coverImage']) && !empty($nightclubDetails['coverImage'])) {
                $image = input::file('coverImage');
                $imageDir = public_path() . config('constants.nightclubCoverImage'); 
                $thumbDir = public_path() . config('constants.nightclubCoverThumb');
                $maxWidth = config('constants.thumbMaxWidth');
                $nightclub->coverImage = VkUtility::saveImageFile($image, $imageDir, $thumbDir, $maxWidth);
            }
            if (isset($nightclubDetails['logo']) && !empty($nightclubDetails['logo'])) {
                $image = input::file('logo');
                $imageDir = public_path() . config('constants.nightclubLogoImage');
                $thumbDir = public_path() . config('constants.nightclubLogoThumb');
                $maxWidth = config('constants.thumbMaxWidth');
                $nightclub->logo = VkUtility::saveImageFile($image, $imageDir, $thumbDir, $maxWidth);
            }

            $nightclub->save();
            

            if (isset($nightclubDetails['email']) && !empty($nightclubDetails['email'])) {
                $user = User::where('id', '=', $nightclubDetails['userId'])->first();
                $user->email = $nightclubDetails['email'];
                //$user->image = public_path() . config('constants.nightclubCoverThumb').$nightclub->logo;
                $user->save();
            }
            if (isset($nightclubDetails['id']) && !empty($nightclubDetails['id'])) {
                return Redirect::to('nightclub/update/' . $nightclubDetails['id'])->withInput()->with('flash_message', 'Club Updated Successfully.');
            }
        }
    }

    public function updateNightClub($id) {
        $venueTypeList = array();
        $venueTypeList = DB::table('venueType as vt')->where('isDisabled', 0)->get();
        $musicGenreList = array();
        $musicGenreList = DB::table('musicGenre as mg')->where('isDisabled', 0)->get();
        $nightclubDetails = Nightclub::getById($id);
        $nightclubImages = NightclubPhoto::getByClubId($id);

        $clientTimeZone = config('constants.defaultClientTimeZone');
        if($_COOKIE['clientTimeZone'])
            $clientTimeZone = $_COOKIE['clientTimeZone'];
        

        $monOpeningTime = date('H:i',strtotime($nightclubDetails->monOpeningTime));
        $givenMonOpeningTime = new \DateTime($monOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenMonOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->monOpeningTime = $givenMonOpeningTime->format("h:i a");

        $monClosingTime = date('H:i',strtotime($nightclubDetails->monClosingTime));
        $givenMonClosingTime = new \DateTime($monClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenMonClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->monClosingTime = $givenMonClosingTime->format("h:i a"); 

        $tueOpeningTime = date('H:i',strtotime($nightclubDetails->tueOpeningTime));
        $givenTueOpeningTime = new \DateTime($tueOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenTueOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->tueOpeningTime = $givenTueOpeningTime->format("h:i a");

        $tueClosingTime = date('H:i',strtotime($nightclubDetails->tueClosingTime));
        $givenTueClosingTime = new \DateTime($tueClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenTueClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->tueClosingTime = $givenTueClosingTime->format("h:i a"); 

        $wedOpeningTime = date('H:i',strtotime($nightclubDetails->wedOpeningTime));
        $givenWedOpeningTime = new \DateTime($wedOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenWedOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->wedOpeningTime = $givenWedOpeningTime->format("h:i a");

        $wedClosingTime = date('H:i',strtotime($nightclubDetails->wedClosingTime));
        $givenWedClosingTime = new \DateTime($wedClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenWedClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->wedClosingTime = $givenWedClosingTime->format("h:i a"); 

        $thuOpeningTime = date('H:i',strtotime($nightclubDetails->thuOpeningTime));
        $givenThuOpeningTime = new \DateTime($thuOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenThuOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->thuOpeningTime = $givenThuOpeningTime->format("h:i a");

        $thuClosingTime = date('H:i',strtotime($nightclubDetails->thuClosingTime));
        $givenThuClosingTime = new \DateTime($thuClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenThuClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->thuClosingTime = $givenThuClosingTime->format("h:i a"); 

        $friOpeningTime = date('H:i',strtotime($nightclubDetails->friOpeningTime));
        $givenFriOpeningTime = new \DateTime($friOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenFriOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->friOpeningTime = $givenFriOpeningTime->format("h:i a");

        $friClosingTime = date('H:i',strtotime($nightclubDetails->friClosingTime));
        $givenFriClosingTime = new \DateTime($friClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenFriClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->friClosingTime = $givenFriClosingTime->format("h:i a"); 

        $satOpeningTime = date('H:i',strtotime($nightclubDetails->satOpeningTime));
        $givenSatOpeningTime = new \DateTime($satOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenSatOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->satOpeningTime = $givenSatOpeningTime->format("h:i a");

        $satClosingTime = date('H:i',strtotime($nightclubDetails->satClosingTime));
        $givenSatClosingTime = new \DateTime($satClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenSatClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->satClosingTime = $givenSatClosingTime->format("h:i a"); 

        $sunOpeningTime = date('H:i',strtotime($nightclubDetails->sunOpeningTime));
        $givenSunOpeningTime = new \DateTime($sunOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenSunOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->sunOpeningTime = $givenSunOpeningTime->format("h:i a");

        $sunClosingTime = date('H:i',strtotime($nightclubDetails->sunClosingTime));
        $givenSunClosingTime = new \DateTime($sunClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenSunClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->sunClosingTime = $givenSunClosingTime->format("h:i a");  


        $userDetails = User::where('nightclubId', $id)->first();
        if (\Auth::user()->role == "admin") {
            return view('nightclub/edit')->with('nightclubDetails', $nightclubDetails)->with('userDetails', $userDetails)->with('venueTypeList',$venueTypeList)->with('musicGenreList',$musicGenreList)->with('nightclubImages',$nightclubImages);
        } elseif (\Auth::user()->role == "club admin" && \Auth::user()->nightclubId == $id) {
            return view('nightclub/edit')->with('nightclubDetails', $nightclubDetails)->with('userDetails', $userDetails)->with('venueTypeList',$venueTypeList)->with('musicGenreList',$musicGenreList)->with('nightclubImages',$nightclubImages);
        } else {
            abort(401, 'Unauthorized action');
        }
    }

    public function deactivateNightClub() {
        $id = input::get('id');
        $data = input::get('data');

        $nightclub = new Nightclub();
        $nightclub = Nightclub::find($id);
        $nightclub->disableReason = $data;
        $nightclub->isDisabled = 1;
        $nightclub->save();

        return "nightclub successfully deactivated";
    }

    public function activateNightClub() {
        $id = input::get('clubId');
        $nightclub = new Nightclub();
        $nightclub = Nightclub::find($id);
        $nightclub->disableReason = " ";
        $nightclub->isDisabled = 0;
        $nightclub->save();

        return "nightclub successfully activated";
    }

    public function viewDetailsNightClub($id) {
        $clientTimeZone = config('constants.defaultClientTimeZone');
        if($_COOKIE['clientTimeZone'])
            $clientTimeZone = $_COOKIE['clientTimeZone'];
        
        $nightclubDetails = Nightclub::getById($id);
        $nightclubImages = NightclubPhoto::getByClubId($id);

        $monOpeningTime = date('H:i',strtotime($nightclubDetails->monOpeningTime));
        $givenMonOpeningTime = new \DateTime($monOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenMonOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->monOpeningTime = $givenMonOpeningTime->format("h:i a");

        $monClosingTime = date('H:i',strtotime($nightclubDetails->monClosingTime));
        $givenMonClosingTime = new \DateTime($monClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenMonClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->monClosingTime = $givenMonClosingTime->format("h:i a"); 

        $tueOpeningTime = date('H:i',strtotime($nightclubDetails->tueOpeningTime));
        $givenTueOpeningTime = new \DateTime($tueOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenTueOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->tueOpeningTime = $givenTueOpeningTime->format("h:i a");

        $tueClosingTime = date('H:i',strtotime($nightclubDetails->tueClosingTime));
        $givenTueClosingTime = new \DateTime($tueClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenTueClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->tueClosingTime = $givenTueClosingTime->format("h:i a"); 

        $wedOpeningTime = date('H:i',strtotime($nightclubDetails->wedOpeningTime));
        $givenWedOpeningTime = new \DateTime($wedOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenWedOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->wedOpeningTime = $givenWedOpeningTime->format("h:i a");

        $wedClosingTime = date('H:i',strtotime($nightclubDetails->wedClosingTime));
        $givenWedClosingTime = new \DateTime($wedClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenWedClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->wedClosingTime = $givenWedClosingTime->format("h:i a"); 

        $thuOpeningTime = date('H:i',strtotime($nightclubDetails->thuOpeningTime));
        $givenThuOpeningTime = new \DateTime($thuOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenThuOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->thuOpeningTime = $givenThuOpeningTime->format("h:i a");

        $thuClosingTime = date('H:i',strtotime($nightclubDetails->thuClosingTime));
        $givenThuClosingTime = new \DateTime($thuClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenThuClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->thuClosingTime = $givenThuClosingTime->format("h:i a"); 

        $friOpeningTime = date('H:i',strtotime($nightclubDetails->friOpeningTime));
        $givenFriOpeningTime = new \DateTime($friOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenFriOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->friOpeningTime = $givenFriOpeningTime->format("h:i a");

        $friClosingTime = date('H:i',strtotime($nightclubDetails->friClosingTime));
        $givenFriClosingTime = new \DateTime($friClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenFriClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->friClosingTime = $givenFriClosingTime->format("h:i a"); 

        $satOpeningTime = date('H:i',strtotime($nightclubDetails->satOpeningTime));
        $givenSatOpeningTime = new \DateTime($satOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenSatOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->satOpeningTime = $givenSatOpeningTime->format("h:i a");

        $satClosingTime = date('H:i',strtotime($nightclubDetails->satClosingTime));
        $givenSatClosingTime = new \DateTime($satClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenSatClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->satClosingTime = $givenSatClosingTime->format("h:i a"); 

        $sunOpeningTime = date('H:i',strtotime($nightclubDetails->sunOpeningTime));
        $givenSunOpeningTime = new \DateTime($sunOpeningTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenSunOpeningTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->sunOpeningTime = $givenSunOpeningTime->format("h:i a");

        $sunClosingTime = date('H:i',strtotime($nightclubDetails->sunClosingTime));
        $givenSunClosingTime = new \DateTime($sunClosingTime, new \DateTimeZone(config('constants.UTCTimeZone')));
        $givenSunClosingTime->setTimezone(new \DateTimeZone($clientTimeZone));
        $nightclubDetails->sunClosingTime = $givenSunClosingTime->format("h:i a"); 

        return view('nightclub.view')->with('nightclubDetails', $nightclubDetails)->with('nightclubImages', $nightclubImages);
    }

    public function viewAssignedNightclub() {
        $nightclubDetails = Nightclub::getById(\Auth::user()->nightclubId);
        return view('nightclub.viewAssignedClub')->with('nightclubDetails', $nightclubDetails);
    }

    public function getSubVenueList(){
        $venueInput = input::all();
        $subVenueList = DB::table('venueType as vt')
                        ->join('venueSubType as vst', 'vt.id', '=', 'vst.venueTypeId')
                        ->where('vt.venueTypeName', '=', $venueInput['venueType'])
                        ->select('vst.venueSubTypeName')
                        ->get();
        echo json_encode($subVenueList);
    }

    public function getSubMusicGenreList(){
        $musicInput = input::all();
        $subVenueList = $subMusicList = DB::table('musicGenre as mg')
                        ->join('subMusicGenre as smg', 'mg.id', '=', 'smg.musicGenreId')
                        ->where('mg.musicGenreName', '=', $musicInput['musicGenre'])
                        ->select('smg.subMusicGenreName')
                        ->get();
        echo json_encode($subVenueList);
    }

    public function deleteClubImages(){
        $nightclubId = input::get('nightclubId');
        $nightclubPhotoId = input::get('nightclubPhotoId');
        $actionPage = input::get('actionPage');

        $nightclubImages = NightclubPhoto::where('id',$nightclubPhotoId)->where('nightclubId',$nightclubId)->first();
        if(is_null($nightclubImages)){
         abort(401, 'Unauthorized action');
        }
        if(\Auth::user()->role == 'admin' || \Auth::user()->role == 'club admin'){
            NightclubPhoto::where('id',$nightclubPhotoId)->where('nightclubId',$nightclubId)->delete();
            $nightclubDetails = Nightclub::getById($nightclubId);
            $nightclubImages = NightclubPhoto::getByClubId($nightclubId);
            
            if($actionPage=='edit'){
                return Redirect::to('nightclub/update/'.$nightclubId)->with('flash_message', 'Club Photo Deleted Successfully.');
            }else{
                return Redirect::to('nightclub/viewCreateEvent?nightclubId='.base64_encode($nightclubId))->with('flash_message', 'Club Photo Deleted Successfully.');
            }
        }
        else{
           abort(401, 'Unauthorized action');
        }
    }

    public function uploadClubMultipleImages(){
      
        $image = input::file('myfile');
        
        $clubPhoto = new NightclubPhoto();
        if (isset($image) && !empty($image)) {
            $imageDir = public_path() . config('constants.nightclubPhotoImage');
            $thumbDir = public_path() . config('constants.nightclubPhotoThumb');
            $maxWidth = config('constants.thumbMaxWidth');
            $clubPhoto->image = VkUtility::saveImageFile($image, $imageDir, $thumbDir, $maxWidth);
        }
        $clubPhoto->nightclubId = input::get('id');
        $clubPhoto->save();
            
        return "success";
    }

    public function validateUserEmail()
    {
        $userDetails = input::all();
        $userEmail = $userDetails['userEmail'];
        $data = array();
        if(filter_var($userEmail, FILTER_VALIDATE_EMAIL)) {
            $user = User::where('email', 'LIKE', "%$userEmail%")->first();
            if (!is_null($user)) 
            {
                $data['type']  = 'error';
                $data['message'] = 'This email already exist.';
            } 
            else 
            {
                $data['type']  = 'success';
                $data['message'] = 'Valid Email.';
            }
        }
        else 
        {
            $data['type']  = 'error';
            $data['message'] = 'Invalid Email.';
        }
        echo json_encode($data);
    }

}
