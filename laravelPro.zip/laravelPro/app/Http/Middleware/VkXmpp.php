<?php 
namespace App\Http\Middleware;

/*
 * VkXmpp: ejabberd_xmlrpc implementation 
 */
class VkXmpp
{
//    public static function xmppRegisterUser($userName, $password, $node)
//    {
//        $output;
//        $status;
//        $result = [];
//        
//        //exec('sudo -u ejabberd /usr/sbin/ejabberdctl register '.$userName.' '.$node.' '.$password.' 2>&1', $output, $status);
//        exec('sudo -u daemon /Applications/ejabberd-15.04/bin/ejabberdctl register '.$userName.' '.$node.' '.$password.' 2>&1', $output, $status);
//        if($output == 0)
//        {
//            $result = ['success'=>true, 'status'=>$status, 'message'=>'User registered successfully.'];
//        }
//        else
//        {
//            // Failure, $output has the details
//            $message = '';
//            foreach($output as $o)
//            {
//                $message .= $o . "\n";
//            }
//            
//            $result = ['success'=>false, 'status'=>$status, 'message'=>$message];
//            $result['currentUser'] = exec('whoami');
//        }
//        
//        return $result;
//    }
    
    private static function sendRequest($xmppHost, $command, $params)
    {
//        $param_auth = array("user"=>"admin", "server"=>"localhost", "password"=>"password");
//        $param_comm = array("user"=>"testuser", "host"=>"localhost");
//        $param = array($param_auth, $param_comm);
        
        $request = xmlrpc_encode_request($command, $params, (array('encoding' => 'utf-8')));
        
        $context = stream_context_create(array('http' => array(
            'method' => "POST",
            'header' => "User-Agent: XMLRPC::Client mod_xmlrpc\r\n" .
                        "Content-Type: text/xml\r\n" .
                        "Content-Length: ".strlen($request),
            'content' => $request
        )));
        
        $file = file_get_contents("http://$xmppHost:4560/RPC2", false, $context);
        
        $response = xmlrpc_decode($file);
        
        if (xmlrpc_is_fault($response)) {
            trigger_error("xmlrpc: $response[faultString] ($response[faultCode])");
        } else {
            return $response;
        }
    }
    
    public static function registerUser($xmppHost, $userName, $password)
    {
        //$host = 'localhost'; //'54.66.144.43';
        $command = 'register';
        $params = array('user'=>$userName, 'host'=>'localhost', 'password'=>$password);
        $response = self::sendRequest($xmppHost, $command, $params);
        return $response;
    }
}
