<?php 
namespace App\Http\Middleware;
use Illuminate\Support\Facades\File;

class VkUtility 
{
    public static function randomString($length = 10)
    {
        //$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ@!';
        
        //without similar looking characters
        $characters = '23456789abdefghjkmnpqrstwxyzABDEFGHJKMNPQRSTWXYZ@!';
        $randomString = '';
        for ($i = 0; $i < $length; ++$i)
        {
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $randomString;
    }

    public static function randomStringAlpha($length = 10)
    {
        $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomString = '';
        for ($i = 0; $i < $length; ++$i)
        {
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $randomString;
    }

    public static function randomStringNum($length = 10)
    {
        $characters = '23456789';
        $randomString = '';
        for ($i = 0; $i < $length; ++$i)
        {
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $randomString;
    }

    // sendApnsNotification: sends push notification
    // $deviceToken: string, device token
    // $message: string, the message to be sent
//     public static function sendApnsNotification($deviceToken, $message, $deviceBadge=0, $data=array())
//     {
//         // path to certificate file
//         //$certFile = 'bendr_apns_dev1.pem'
//         $certFile = 'bendrDev.pem';
// //       echo $certFile;
// //        if(file_exists($certFile))
// //            echo ' file found.';
// //        else
// //            echo ' file not found.';
// //        die;
//         // passphrase
//         $passPhrase = 'abcd';

//         $streamContext = stream_context_create();
//         stream_context_set_option($streamContext,'ssl', 'local_cert', $certFile);
//         stream_context_set_option($streamContext, 'ssl', 'passphrase', $passPhrase);
//         //$apns = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195',$error,$errorString,60,STREAM_CLIENT_CONNECT, $streamContext);
//         $apns = stream_socket_client('ssl://gateway.push.apple.com:2195',$error,$errorString,60,STREAM_CLIENT_CONNECT, $streamContext);

//         $load = array(
//             'aps' => array(
//                 'alert' => $message,
//                 'badge' => $deviceBadge,
//                 'sound' => 'default',
//                 'data' => $data
//             ));
//         $payload = json_encode($load);

//         $apnsMessage = chr(0) . chr(0) . chr(32);

//         $apnsMessage .= pack('H*', str_replace(' ','',$deviceToken));
//         $apnsMessage .= chr(0) . chr(strlen($payload)) . $payload;

//         fwrite($apns, $apnsMessage);
//         fclose($apns);
//         //echo "Just Wrote ".$payload; die;
//     }

    // sendApnsNotification: sends push notification
    // $deviceToken: string, device token
    // $message: string, the message to be sent
    public static function sendApnsNotification($deviceToken, $message, $deviceBadge=0, $data=array())
    {
        //path to certificate file
        $certFile = env('APPLE_CERTIFICATE', 'Bender_Dev.pem');
        //$certFilePath = public_path($certFile);
        //echo $certFile;
        //echo (file_exists($certFile)) ? 'exists' : 'not found'; die;
        
        // passphrase
        $passPhrase = env('APPLE_PASSPHRASE', '');
        
        //is to use sandbox
        $sandbox = env('APPLE_SANDBOX', false);
        //print_r(array($certFile, $passPhrase, $sandbox)); die;
        $streamContext = stream_context_create();
        stream_context_set_option($streamContext,'ssl', 'local_cert', $certFile);
        stream_context_set_option($streamContext, 'ssl', 'passphrase', $passPhrase);
        
        if($sandbox)
            $apns = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195',$error,$errorString,60,STREAM_CLIENT_CONNECT, $streamContext);
        else
            $apns = stream_socket_client('ssl://gateway.push.apple.com:2195',$error,$errorString,60,STREAM_CLIENT_CONNECT, $streamContext);

        $load = array(
            'aps' => array(
                'alert' => $message,
                'badge' => $deviceBadge,
                'sound' => 'default',
                'data' => $data,
                'content-available'=>1
            ));
        
        $payload = json_encode($load);

        // echo $certFile;
        // echo $sandbox;
        // echo $payload; die;

        $apnsMessage = chr(0) . chr(0) . chr(32);

        $apnsMessage .= pack('H*', str_replace(' ','',$deviceToken));
        $apnsMessage .= chr(0) . chr(strlen($payload)) . $payload;

        fwrite($apns, $apnsMessage);
        fclose($apns);

        // echo "Just Wrote $payload at device token $deviceToken"; die;
        // self::LogInFile($payload . "deviceToken = $deviceToken");
    }

    public static function sendAndroidApnsNotification($deviceToken, $message, $deviceBadge = 0, $data = [])
    {
        // API access key from Google API's Console
        $androidApiAccessKey = env('ANDROID_API_ACCESS_KEY', 'AIzaSyB7ba191T5z9RxgzxVP-9WOtyQj6IlPmY4');
        // prep the bundle
        $msg = array(
            'message' => $message,
            'title' => 'Bendr',
            'subtitle'  => '',
            'tickerText'    => '',
            'vibrate'   => 1,
            'sound'     => 1,
            'largeIcon' => 'large_icon',
            'smallIcon' => 'small_icon',
            'datamsg' => $data
        );
        
        $fields = array(
            'registration_ids' => array($deviceToken),
            'data' => $msg
        );

        $headers = array(
            'Authorization: key=' . $androidApiAccessKey,
            'Content-Type: application/json'
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://android.googleapis.com/gcm/send');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
        curl_close($ch);
        
        // echo $result; die;
        // self::LogInFile(json_encode($fields) . "deviceToken = $deviceToken");
    }

    public static function getLocationFromPostcode($postcode="", $address="")
    {
        $url = "http://maps.googleapis.com/maps/api/geocode/json?address=" . urlencode($postcode . " " . $address) . "&sensor=false";
        $result_string = file_get_contents($url);
        $result = json_decode($result_string, true);

        $values = array('formattedAddress'=>'', 'latitude'=>0, 'longitude'=>0);
        if(isset($result['results'][0]))
        {
            $values['formattedAddress'] = $result['results'][0]['formatted_address'];
            $values['latitude'] = $result['results'][0]['geometry']['location']['lat'];
            $values['longitude'] = $result['results'][0]['geometry']['location']['lng'];
        }

        return $values;
    }

    public static function saveBase64ImagePng($base64Image, $imageDir, $thumbDir='', $maxWidth=0)
    {
        //set name of the image file
        $fileName = uniqid('', true) . '.png';

        $base64Image = trim($base64Image);
        $base64Image = str_replace('data:image/png;base64,', '', $base64Image);
        $base64Image = str_replace('data:image/jpg;base64,', '', $base64Image);
        $base64Image = str_replace('data:image/jpeg;base64,', '', $base64Image);
        $base64Image = str_replace('data:image/gif;base64,', '', $base64Image);
        $base64Image = str_replace(' ', '+', $base64Image);

        $imageData = base64_decode($base64Image);
        $image = imagecreatefromstring($imageData);
        $filePath = $imageDir . $fileName;

        if(imagepng($image, $filePath))
        {
            if($thumbDir)
            {
                $maxWidth = ($maxWidth) ? $maxWidth : 160;
                $thumb = new VkThumb($imageDir . $fileName);
                $thumb->setDestination($thumbDir);
                $thumb->setMaxSize($maxWidth);
                $thumb->create();
            }

            return $fileName;
        }
        else
            return '';
    }

    public static function saveBase64ImagePngWithName($name, $base64Image, $imageDir, $thumbDir='', $maxWidth=0)
    {
        //set name of the image file
        $fileName = $name . '.png';

        $base64Image = trim($base64Image);
        $base64Image = str_replace('data:image/png;base64,', '', $base64Image);
        $base64Image = str_replace('data:image/jpg;base64,', '', $base64Image);
        $base64Image = str_replace('data:image/jpeg;base64,', '', $base64Image);
        $base64Image = str_replace('data:image/gif;base64,', '', $base64Image);
        $base64Image = str_replace(' ', '+', $base64Image);

        $imageData = base64_decode($base64Image);
        $image = imagecreatefromstring($imageData);
        $filePath = $imageDir . $fileName;

        if(imagepng($image, $filePath))
        {
            if($thumbDir)
            {
                $maxWidth = ($maxWidth) ? $maxWidth : 160;
                $thumb = new VkThumb($imageDir . $fileName);
                $thumb->setDestination($thumbDir);
                $thumb->setMaxSize($maxWidth);
                $thumb->create();
            }

            return $fileName;
        }
        else
            return '';
    }

    public static function saveBase64ImagePngInSizes($base64Image, $imageDir, $sizes=array())
    {
        //set name of the image file
        $time = microtime(true);
        $micro = sprintf("%06d",($time - floor($time)) * 1000000);
        $date = new DateTime(date('Y-m-d H:i:s.'.$micro, $time));
        $fileName = $date->format("YmdHisu") . '.png';

        $base64Image = trim($base64Image);
        $base64Image = str_replace('data:image/png;base64,', '', $base64Image);
        $base64Image = str_replace('data:image/jpg;base64,', '', $base64Image);
        $base64Image = str_replace('data:image/jpeg;base64,', '', $base64Image);
        $base64Image = str_replace('data:image/gif;base64,', '', $base64Image);
        $base64Image = str_replace(' ', '+', $base64Image);

        $imageData = base64_decode($base64Image);
        $image = imagecreatefromstring($imageData);
        $filePath = $imageDir . '/' . $fileName;

        if(imagepng($image, $filePath))
        {
            if(count($sizes) > 0)
            {
                foreach ($sizes as $size)
                {
                    $maxWidth = $size;

                    //the following line is set due to sudden change in thumb size from 50 to 70
                    //to avoid changes at multiple places just before sending new build
                    if($size == 50)
                        $maxWidth = 70;

                    $thumbDir = $imageDir . '/thumb' . $size;
                    if (!file_exists($thumbDir))
                        mkdir($thumbDir, 0777, true);

                    $thumb = new VkThumb($imageDir . '/' . $fileName);
                    $thumb->setDestination($thumbDir);
                    $thumb->setMaxSize($maxWidth);
                    $thumb->create();
                }
            }

            return $fileName;
        }
        else
            return '';
    }

    public static function saveStringImagePng($stringImage, $imageDir, $thumbDir='', $maxWidth=0)
    {
        //set name of the image file
        $time = microtime(true);
        $micro = sprintf("%06d",($time - floor($time)) * 1000000);
        $date = new DateTime(date('Y-m-d H:i:s.'.$micro, $time));
        $fileName = $date->format("YmdHisu") . '.png';

        $image = imagecreatefromstring($stringImage);
        $filePath = $imageDir . '/' . $fileName;

        if(imagepng($image, $filePath))
        {
            if($thumbDir)
            {
                $maxWidth = ($maxWidth) ? $maxWidth : 160;
                $thumb = new VkThumb($imageDir . '/' . $fileName);
                $thumb->setDestination($thumbDir);
                $thumb->setMaxSize($maxWidth);
                $thumb->create();
            }

            return $fileName;
        }
        else
            return '';
    }
    
    public static function saveImageFile($file, $imageDir, $thumbDir='', $maxWidth=0){
        $fileName = uniqid('', true) . '.png';
        
        $filePath = $imageDir . '/' . $fileName;
        $image1 = file::get($file);
        $image = imagecreatefromstring($image1);

        if(imagepng($image, $filePath))
        {
            if($thumbDir)
            {
                $maxWidth = ($maxWidth) ? $maxWidth : 160;
                $thumb = new VkThumb($imageDir . '/' . $fileName);
                $thumb->setDestination($thumbDir);
                $thumb->setMaxSize($maxWidth);
                $thumb->create();
            }

            return $fileName;
        }
        else
            return '';
    }
    
    public static function makeThumbImage($imageDir,$thumbDir='',$fileName,$maxWidth=0){
        if($thumbDir)
            {
                $maxWidth = ($maxWidth) ? $maxWidth : 160;
                $thumb = new VkThumb($imageDir . '/' . $fileName);
                $thumb->setDestination($thumbDir);
                $thumb->setMaxSize($maxWidth);
                $thumb->create();
            }

            return $fileName;
       
    }

    public static function uniqueMultiArray($input)
    {
        $serialized = array_map('serialize', $input);
        $unique = array_unique($serialized);
        return array_intersect_key($input, $unique);
    }

    public static function LogInFile($val)
    {
        try
        {
            $fp = fopen('error/error.log', 'a');
            fwrite($fp, '\n\n' . $val);
            fclose($fp);
        }
        catch(Exception $e){}
    }

    // public static function to read parameters from config.php file
    public static function yiiParam($name, $default = '')
    {
        if (isset(Yii::app()->params[$name]))
            return Yii::app()->params[$name];
        else
            return $default;
    }

    public static function imagePath($imageKey)
    {
        return Yii::app()->getBaseUrl(true) .  yiiParam($imageKey);
    }

    public static function thumbPath($imageKey)
    {
        return Yii::app()->getBaseUrl(true) .  yiiParam($imageKey) . 'thumb/';
    }

    public static function getTimeLeft($dateTime1, $dateTime2)
    {
        $difference = date_diff($dateTime1, $dateTime2, TRUE);
        $timeElapsed = '';

        if($difference->y > 1)
            $timeElapsed = $difference->y . ' years left';
        else if($difference->y == 1)
            $timeElapsed = '1 year left';
        else if($difference->m > 1)
            $timeElapsed = $difference->m . ' months left';
        else if($difference->m == 1)
            $timeElapsed = '1 month left';
        else if($difference->d > 1)
            $timeElapsed = $difference->d . ' days left';
        else if($difference->d == 1)
            $timeElapsed = '1 day left';
        else if($difference->h > 1)
            $timeElapsed = $difference->h . ' hours left';
        else if($difference->h == 1)
            $timeElapsed = '1 hour left';
        else if($difference->i > 1)
            $timeElapsed = $difference->i . ' minutes left';
        else if($difference->i == 1)
            $timeElapsed = '1 minute left';
        else if($difference->s > 1)
            $timeElapsed = $difference->s . ' seconds left';
        else if($difference->s == 1)
            $timeElapsed = '1 second left';

        return $timeElapsed;
    }

    public static function getTimeElapsed($dateTime1, $dateTime2)
    {
        $difference = date_diff($dateTime1, $dateTime2, TRUE);
        $timeElapsed = '';

        if($difference->y > 1)
            $timeElapsed = $difference->y . ' years ago';
        else if($difference->y == 1)
            $timeElapsed = '1 year ago';
        else if($difference->m > 1)
            $timeElapsed = $difference->m . ' months ago';
        else if($difference->m == 1)
            $timeElapsed = '1 month ago';
        else if($difference->d > 1)
            $timeElapsed = $difference->d . ' days ago';
        else if($difference->d == 1)
            $timeElapsed = '1 day ago';
        else if($difference->h > 1)
            $timeElapsed = $difference->h . ' hours ago';
        else if($difference->h == 1)
            $timeElapsed = '1 hour ago';
        else if($difference->i > 1)
            $timeElapsed = $difference->i . ' minutes ago';
        else if($difference->i == 1)
            $timeElapsed = '1 minute ago';
        else if($difference->s > 1)
            $timeElapsed = $difference->s . ' seconds ago';
        else if($difference->s == 1)
            $timeElapsed = '1 second ago';

        return $timeElapsed;
    }

    public static function getTimeElapsed2($dateTime1, $dateTime2)
    {
        $difference = date_diff($dateTime1, $dateTime2, TRUE);
        $timeElapsed = '';

        if($difference->y > 1)
            $timeElapsed = $difference->y . ' years ago';
        else if($difference->y == 1)
        {
            if($difference->m > 1)
                $timeElapsed = '1 year ' . $difference->m . ' months ago';
            else if($difference->m == 1)
                $timeElapsed = '1 year 1 month ago';
            else
                $timeElapsed = '1 year ago';
        }
        else if($difference->m > 1)
            $timeElapsed = $difference->m . ' months ago';
        else if($difference->m == 1)
        {
            if($difference->d > 1)
                $timeElapsed = '1 month ' . $difference->d . ' days ago';
            else if($difference->d == 1)
                $timeElapsed = '1 month 1 day ago';
            else
                $timeElapsed = '1 month ago';
        }
        else if($difference->d > 1)
            $timeElapsed = $difference->d . ' days ago';
        else if($difference->d == 1)
        {
            if($difference->h > 1)
                $timeElapsed = '1 day ' . $difference->h . ' hours ago';
            else if($difference->h == 1)
                $timeElapsed = '1 day 1 hour ago';
            else
                $timeElapsed = '1 day ago';
        }
        else if($difference->h > 1)
            $timeElapsed = $difference->h . ' hours ago';
        else if($difference->h == 1)
        {
            if($difference->i > 1)
                $timeElapsed = '1 hour ' . $difference->i . ' minutes ago';
            else if($difference->i == 1)
                $timeElapsed = '1 hour 1 minute ago';
            else
                $timeElapsed = '1 hour ago';
        }
        else if($difference->i > 1)
            $timeElapsed = $difference->i . ' minutes ago';
        else if($difference->i == 1)
        {
            if($difference->s > 1)
                $timeElapsed = '1 minute ' . $difference->s . ' seconds ago';
            else if($difference->s == 1)
                $timeElapsed = '1 minute 1 second ago';
            else
                $timeElapsed = '1 minute ago';
        }
        else if($difference->s > 1)
            $timeElapsed = $difference->s . ' seconds ago';
        else if($difference->s == 1)
            $timeElapsed = '1 second ago';

        return $timeElapsed;
    }

    public static function getTimeElapsedShort($dateTime1, $dateTime2)
    {
        $difference = date_diff($dateTime1, $dateTime2, TRUE);
        $timeElapsed = '';

        if($difference->y > 1)
            $timeElapsed = $difference->y . 'y';
        else if($difference->y == 1)
        {
            if($difference->m > 1)
                $timeElapsed = '1y ';
            else if($difference->m == 1)
                $timeElapsed = '1y';
            else
                $timeElapsed = '1y';
        }
        else if($difference->m > 1)
            $timeElapsed = $difference->m . 'mo';
        else if($difference->m == 1)
        {
            if($difference->d > 1)
                $timeElapsed = '1mo';
            else if($difference->d == 1)
                $timeElapsed = '1mo';
            else
                $timeElapsed = '1mo';
        }
        else if($difference->d > 1)
            $timeElapsed = $difference->d . 'd';
        else if($difference->d == 1)
        {
            if($difference->h > 1)
                $timeElapsed = '1d';
            else if($difference->h == 1)
                $timeElapsed = '1d';
            else
                $timeElapsed = '1d';
        }
        else if($difference->h > 1)
            $timeElapsed = $difference->h . 'h';
        else if($difference->h == 1)
        {
            if($difference->i > 1)
                $timeElapsed = '1h';
            else if($difference->i == 1)
                $timeElapsed = '1h';
            else
                $timeElapsed = '1h';
        }
        else if($difference->i > 1)
            $timeElapsed = $difference->i . 'm';
        else if($difference->i == 1)
        {
            if($difference->s > 1)
                $timeElapsed = '1m ' . $difference->s . 's';
            else if($difference->s == 1)
                $timeElapsed = '1m';
            else
                $timeElapsed = '1m';
        }
        else if($difference->s > 1)
            $timeElapsed = $difference->s . 's';
        else if($difference->s == 1)
            $timeElapsed = '1s';

        return $timeElapsed;
    }

    public static function getAddressFromLatLong($latitude, $longitude)
    {
        $url = 'http://maps.googleapis.com/maps/api/geocode/json?latlng='.trim($latitude).','.trim($longitude).'&sensor=false';
        $json = @file_get_contents($url);
        $data=json_decode($json);

        $status = $data->status;
        if($status=="OK")
            return $data->results[0]->formatted_address;
        else
            return '';
    }

    public static function getCityFromLatLong($latitude, $longitude)
    {
        $url = 'http://maps.googleapis.com/maps/api/geocode/json?latlng='.trim($latitude).','.trim($longitude).'&sensor=false';
        $json = @file_get_contents($url);
        $data=json_decode($json);

        $status = $data->status;
        if($status=="OK")
        {
            $addressComponents = $data->results[0]->address_components;
            $administrativeAreaLevel2 = getAddressComponent($addressComponents, 'administrative_area_level_2');
            $administrativeAreaLevel1 = getAddressComponent($addressComponents, 'administrative_area_level_1');
            $country = getAddressComponent($addressComponents, 'country');

            if(!empty($administrativeAreaLevel2))
                return $administrativeAreaLevel2;
            else if(!empty($administrativeAreaLevel1))
                return $administrativeAreaLevel1;
            else
                return $country;
        }
        else
            return '';
    }

    public static function getAddressComponentsFromLatLong($latitude, $longitude)
    {
        $url = 'http://maps.googleapis.com/maps/api/geocode/json?latlng='.trim($latitude).','.trim($longitude).'&sensor=false';
        $json = @file_get_contents($url);
        $data=json_decode($json);
        $components = array(
            'sublocalityLevel1' => '', 
            'locality' => '', 
            'administrativeAreaLevel2' => '', 
            'administrativeAreaLevel1' => '', 
            'country' => '', 
            'postalCode' => '', 
            'formattedAddress' => ''
        );
        
        $status = $data->status;
        if($status=="OK")
        {
            $addressComponents = $data->results[0]->address_components;
            $components['sublocalityLevel1'] = self::getAddressComponent($addressComponents, 'sublocality_level_1');
            $components['locality'] = self::getAddressComponent($addressComponents, 'locality');
            $components['administrativeAreaLevel2'] = self::getAddressComponent($addressComponents, 'administrative_area_level_2');
            $components['administrativeAreaLevel1'] = self::getAddressComponent($addressComponents, 'administrative_area_level_1');
            $components['country'] = self::getAddressComponent($addressComponents, 'country');
            $components['postalCode'] = self::getAddressComponent($addressComponents, 'postal_code');
            $components['formattedAddress'] = $data->results[0]->formatted_address;
        }
        
        return $components;
    }

    public static function getAddressComponent($addressComponents, $type)
    {
        for($i=0; $i<count($addressComponents); $i++)
        {
            if(in_array($type, $addressComponents[$i]->types))
                return $addressComponents[$i]->long_name;
        }
        return '';
    }

    public static function compareDistance($a, $b)
    {
        if(!isset($a['distance']) || !isset($b['distance']))
            return 0;

        if($a['distance'] == $a['distance'])
            return 0;

        return ($a['distance'] < $b['distance']) ? -1 : 1;
    }
    
    public static function getJsonInput()
    {
        $jsonInput = file_get_contents("php://input");
        $jsonInput = utf8_encode($jsonInput);
        //$jsonInput = str_replace('\"', '"', $jsonInput);
        //$jsonInput = html_entity_decode($jsonInput);
        //$jsonInput = stripslashes($jsonInput);
        $_JSON = json_decode($jsonInput, 1);
        return $_JSON;
    }
    
    public static function getBase64JsonInput()
    {
        $inputBase64 = file_get_contents("php://input");
        $inputJson = base64_decode($inputBase64);
//        LogInFile($inputJson);
        //$inputJson = utf8_encode($inputJson);
        //LogInFile($inputJson);
        $_JSON = json_decode($inputJson, 1);
        //LogInFile($_JSON);
        return $_JSON;
    }
    
    public static function error($api, $errorCode, $text)
    {
        return array('api'=>$api, 'status'=>'error', 'errorCode'=>$errorCode, 'apiMessage'=>$text);
    }
    
    public static function success($api, $text)
    {
        return array('api'=>$api, 'status'=>'OK', 'apiMessage'=>$text);
    }
    
    public static function getEncryptedPassword($password, $saltText)
    {
        $salt = md5($saltText);
        $encryptedPassword = crypt($password, $salt);
        return $encryptedPassword;
    }
}
