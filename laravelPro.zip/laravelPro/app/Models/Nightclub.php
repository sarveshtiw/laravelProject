<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use \Illuminate\Support\Facades\DB;

class Nightclub extends Model {

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'nightclub';

    /*
     * Disable timestamps fields
     */
    //public $timestamps = false;
    
    /*
     * use different columns for created_at and updated_at
     */
    const CREATED_AT = 'createDate';
    const UPDATED_AT = 'updateDate';
    
    
    
    public static function getQuery($latitude=0, $longitude=0, $userId=0, $myClubs=0)
    {
        $coverImagePath = asset('/images/nightclub/cover') . '/';
        $coverThumbPath = asset('/images/nightclub/cover/thumb') . '/';
        $logoImagePath = asset('/images/nightclub/logo') . '/';
        $logoThumbPath = asset('/images/nightclub/logo/thumb') . '/';
        
        $sql = 'SELECT n.id';
        $sql .= ',n.nightclubName';
        $sql .= ',IFNULL(n.location, "") as location';
        $sql .= ',IFNULL(CONCAT("' . $coverImagePath . '",n.coverImage), "") as coverImage';
        $sql .= ',IFNULL(CONCAT("' . $coverThumbPath . '",n.coverImage), "") as coverThumb';
        $sql .= ',IFNULL(CONCAT("' . $logoImagePath . '",n.logo), "") as logoImage';
        $sql .= ',IFNULL(CONCAT("' . $logoThumbPath . '",n.logo), "") as logoThumb';
        $sql .= ',IFNULL(n.latitude, "") as latitude';
        $sql .= ',IFNULL(n.longitude, "") as longitude';
        $sql .= ',IFNULL(n.briefInfo, "") as briefInfo';
        $sql .= ',IFNULL(n.subVenueType, "") as subVenueType';
        $sql .= ',IFNULL(n.venueType, "") as venueType';
        $sql .= ',IFNULL(n.dressCode, "") as dressCode';
        $sql .= ',IFNULL(n.musicGenre, "") as musicGenre';
        $sql .= ',IFNULL(n.subMusicGenre, "") as subMusicGenre';
        $sql .= ',IFNULL(n.budget, "") as budget';
        $sql .= ',IFNULL(n.popularity, "") as popularity';
        $sql .= ',IFNULL(n.followerCount, "") as followerCount';
        $sql .= ',IFNULL(n.checkinCount, "") as checkinCount';
        $sql .= ',IFNULL(TIME_FORMAT(n.monOpeningTime, "%H:%i"), "") as monOpeningTime';
        $sql .= ',IFNULL(TIME_FORMAT(n.monClosingTime, "%H:%i"), "") as monClosingTime';
        $sql .= ',IFNULL(TIME_FORMAT(n.tueOpeningTime, "%H:%i"), "") as tueOpeningTime';
        $sql .= ',IFNULL(TIME_FORMAT(n.tueClosingTime, "%H:%i"), "") as tueClosingTime';
        $sql .= ',IFNULL(TIME_FORMAT(n.wedOpeningTime, "%H:%i"), "") as wedOpeningTime';
        $sql .= ',IFNULL(TIME_FORMAT(n.wedClosingTime, "%H:%i"), "") as wedClosingTime';
        $sql .= ',IFNULL(TIME_FORMAT(n.thuOpeningTime, "%H:%i"), "") as thuOpeningTime';
        $sql .= ',IFNULL(TIME_FORMAT(n.thuClosingTime, "%H:%i"), "") as thuClosingTime';
        $sql .= ',IFNULL(TIME_FORMAT(n.friOpeningTime, "%H:%i"), "") as friOpeningTime';
        $sql .= ',IFNULL(TIME_FORMAT(n.friClosingTime, "%H:%i"), "") as friClosingTime';
        $sql .= ',IFNULL(TIME_FORMAT(n.satOpeningTime, "%H:%i"), "") as satOpeningTime';
        $sql .= ',IFNULL(TIME_FORMAT(n.satClosingTime, "%H:%i"), "") as satClosingTime';
        $sql .= ',IFNULL(TIME_FORMAT(n.sunOpeningTime, "%H:%i"), "") as sunOpeningTime';
        $sql .= ',IFNULL(TIME_FORMAT(n.sunClosingTime, "%H:%i"), "") as sunClosingTime';
        $sql .= ',IFNULL(n.facebookLink, "") as facebookLink';
        $sql .= ',IFNULL(n.twitterLink, "") as twitterLink';
        $sql .= ',IFNULL(n.instagramLink, "") as instagramLink';
        $sql .= ",DEGREES(ACOS(SIN(RADIANS($latitude)) * SIN(RADIANS(n.latitude)) + COS(RADIANS($latitude)) * COS(RADIANS(n.latitude)) * COS(RADIANS($longitude - n.longitude)))) * 111.1893006 as distance";
        if($userId)
            $sql .= ',IF(nf.userId is null, 0, 1) as iFollowIt';
        
        $sql .= ' FROM nightclub n ';
        
        if(!empty($myClubs)){
            $sql .= " inner join nightclubFollower nf on nf.nightclubId = n.id AND nf.userId=" . $userId;
        }
        else if($userId){
            $sql .= " left join nightclubFollower nf on nf.nightclubId = n.id AND nf.userId=" . $userId;
        }
        
        return $sql;
    }
    
    public static function getList($nearMe, $latitude, $longitude, $location, $venueType, $dressCode = 1, $musicGenre, $budget = 1, $popularity, $maxDistance=0, $sortBy='iFollowIt DESC, distance ASC', $exceptions = '',$searchText = '', $userId = 0, $myClubs = 0, $subVenueType='', $subMusicGenre ='')
    {
        $sql = self::getQuery($latitude, $longitude, $userId, $myClubs);
        $sql .= ' WHERE 1';
        
        $sql .= ' AND n.isDisabled=0';
        
        if(!empty($location))
            $sql .= " AND n.location LIKE '%$location%'";
        
        if(!empty($venueType))
            $sql .= " AND n.venueType in ($venueType)";

        if(!empty($subVenueType))
            $sql .= " AND (n.subVenueType in ($subVenueType) or n.subVenueType is null  OR n.subVenueType = '')";
        
        if(!empty($dressCode))
            $sql .= " AND n.dressCode = '$dressCode'";
        
        if(!empty($musicGenre))
            $sql .= " AND n.musicGenre in ($musicGenre)";

        if(!empty($subMusicGenre))
            $sql .= " AND (n.subMusicGenre in ($subMusicGenre) or n.subMusicGenre is null  OR n.subMusicGenre = '')";
        
        if(!empty($budget))
            $sql .= " AND n.budget = $budget";
        
        if(!empty($popularity))
            $sql .= " AND n.popularity = '$popularity'";

        if(!empty($searchText))
            $sql .= " AND (n.nightclubName LIKE '%$searchText%' OR n.venueType LIKE '%$searchText%')";
        
        if(!empty($exceptions))
            $sql .= " AND n.id NOT IN($exceptions)";

        $maxDistance = 250;
        if(($nearMe)==1)
            $sql .= " HAVING distance <= $maxDistance";
        
        $sql .= " ORDER BY $sortBy";
        $sql .= " LIMIT 15";

        //echo $sql; die;
        $records = DB::select($sql);
        
        return $records;
    }
    
    public static function getNearestNightclubInRange($latitude, $longitude, $maxDistance=.1)
    {
        $sql = self::getQuery($latitude, $longitude);
        $sql .= ' WHERE 1';
        $sql .= ' AND n.isDisabled=0';
        $sql .= " HAVING distance <= $maxDistance";
        
        $sql .= " ORDER BY distance";
        $sql .= " LIMIT 1";
        
        $records = DB::select($sql);
        
        if(empty($records))
            return null;        //new \stdClass ();
        else
            return $records[0];
    }
    
    public static function getById($id, $latitude=0, $longitude=0, $userId=0)
    {
        $sql = self::getQuery($latitude, $longitude, $userId);
        $sql .= ' WHERE n.id =' . $id;
        $records = DB::select($sql);
        
        if(empty($records))
            return null;        //new \stdClass ();
        else
            return $records[0];
    }
    
}
