<?php namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Passwords\CanResetPassword;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\CanResetPassword as CanResetPasswordContract;

use Illuminate\Support\Facades\DB;

class User extends Model implements AuthenticatableContract, CanResetPasswordContract {

    use Authenticatable, CanResetPassword;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'user';

    /*
     * Disable timestamps fields
     */
    //public $timestamps = false;

    /*
     * use different columns for created_at and updated_at
     */
    const CREATED_AT = 'createDate';
    const UPDATED_AT = 'updateDate';
    
    /*
     * use different column for remember_token column
     */
    public function getRememberToken()
    {
        return $this->rememberToken;
    }

    public function setRememberToken($value)
    {
        $this->rememberToken = $value;
    }

    public function getRememberTokenName()
    {
        return 'rememberToken';
    }

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['userName', 'email', 'password'];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = ['password'];
    
    /**
     * relationship with userSession table
     */
    public function userSession()
    {
        return $this->hasOne('UserSession');
    }
    
    /*
     * check user's role matches with one of the given roles
     * @param $roles an array of roles
     */
    public function hasRole($roles)
    {
        $userRoles = explode(',', $this->role);
        foreach($roles as $role)
        {
            if(in_array($role, $userRoles))
                return true;
        }
        
        return false;
    }
    
    public static function getQuery($userId=0, $includeFilter=0, $includePassword=0, $includeDetails=1, $latitude=0, $longitude=0)
    {
        $imagePath = asset('/images/user') . '/';
        $thumbPath = asset('/images/user/thumb') . '/';
        
        $sql = 'SELECT u.id';
        $sql .= ',u.role';
        $sql .= ',IFNULL(u.jabberId, "") as jabberId';
        $sql .= ',IFNULL(u.firstName, "") as firstName';
        $sql .= ',IFNULL(u.surName, "") as surName';
        $sql .= ',IFNULL(CONCAT("' . $imagePath . '",u.image), "") as image';
        $sql .= ',IFNULL(CONCAT("' . $thumbPath . '",u.image), "") as thumb';
        $sql .= ',IFNULL(u.gender, "") as gender';
        
        if($includeDetails)
        {
            $sql .= ',IFNULL(u.facebookId, "") as facebookId';
            $sql .= ',IFNULL(u.email, "") as email';
            $sql .= ',IFNULL(u.location, "") as location';
            $sql .= ',IFNULL(u.postcode, "") as postcode';
            $sql .= ',IFNULL(u.country, "") as country';
            $sql .= ',IFNULL(u.phone, "") as phone';
            $sql .= ',IFNULL(u.age, "") as age';
            $sql .= ',IFNULL(u.relationshipStatus, "") as relationshipStatus';
            $sql .= ',IFNULL(u.aboutMe, "") as aboutMe';
            $sql .= ',IFNULL(u.lookingFor, "") as lookingFor';
            $sql .= ',IFNULL(u.latitude, "") as latitude';
            $sql .= ',IFNULL(u.longitude, "") as longitude';
            $sql .= ',IFNULL(u.receiveNotification, "") as receiveNotification';
            $sql .= ',IFNULL(u.isOpenToChat, "") as isOpenToChat';
            $sql .= ',u.friendCount';
            $sql .= ',u.nightclubFollowCount';
            
            if($latitude && $longitude)
                $sql .= ",DEGREES(ACOS(SIN(RADIANS($latitude)) * SIN(RADIANS(u.latitude)) + COS(RADIANS($latitude)) * COS(RADIANS(u.latitude)) * COS(RADIANS($longitude - u.longitude)))) * 111.1893006 as distance";
            else
                $sql .= ",0 as distance";
        }
        
        if($includeFilter)
        {
            $sql .= ',IFNULL(u.filterNearMe, "") as filterNearMe';
            $sql .= ',IFNULL(u.filterLocation, "") as filterLocation';
            $sql .= ',IFNULL(u.filterVenueType, "") as filterVenueType';
            $sql .= ',IFNULL(u.filterMusicGenre, "") as filterMusicGenre';
            $sql .= ',IFNULL(u.filterSubMusicGenre, "") as filterSubMusicGenre';
            $sql .= ',IFNULL(u.filterDressCode, "") as filterDressCode';
            $sql .= ',IFNULL(u.filterBudget, "") as filterBudget';
            $sql .= ',IFNULL(u.filterPopularity, "") as filterPopularity';
            $sql .= ',IFNULL(u.filterVenueSubType, "") as filterVenueSubType';
            $sql .= ',IFNULL(u.filterMyClubs, "") as filterMyClubs';
        }
        
        if($includePassword)
        {
            $sql .= ',u.password';
        }
        
        if($userId)
        {
            $sql .= ',IFNULL(f.senderUserId, "") as senderUserId';
            $sql .= ',IF(f.friendStatus is null, 0, f.friendStatus) as isFriendStatus';
            $sql .= ',if(bu.blockedUserId is null, 0, 1) as blockedStatus';    /*0 not blocked, 1 blocked */
            $sql .= ',if(nchi.userId is null, 0, 1) as isGoing';    /*0 in-Active, 1 Going Out */
        }

        
        $sql .= ' FROM user u';
        
        if($userId)
        {
            $sql .= " LEFT JOIN friend f ON ((f.senderUserId=u.id AND f.receiverUserId=$userId) OR (f.receiverUserId=u.id AND f.senderUserId=$userId)) ";
            $sql .= " LEFT JOIN blockUser bu ON bu.blockedUserId=u.id AND bu.blockedUserId=$userId";
            $sql .= " LEFT JOIN nightclubCheckIn nchi ON nchi.userId=u.id AND nchi.userId=$userId";
        }

        return $sql;
    }
    
    public static function getFriendsProfile($friendsUserId=0, $userId=0, $latitude=0, $longitude=0)
    {
        $imagePath = asset('/images/user') . '/';
        $thumbPath = asset('/images/user/thumb') . '/';
        
        $sql = 'SELECT u.id';
        $sql .= ',u.role';
        $sql .= ',IFNULL(u.jabberId, "") as jabberId';
        $sql .= ',IFNULL(u.firstName, "") as firstName';
        $sql .= ',IFNULL(u.surName, "") as surName';
        $sql .= ',IFNULL(CONCAT("' . $imagePath . '",u.image), "") as image';
        $sql .= ',IFNULL(CONCAT("' . $thumbPath . '",u.image), "") as thumb';
        $sql .= ',IFNULL(u.gender, "") as gender';
        
        $sql .= ',IFNULL(u.facebookId, "") as facebookId';
        $sql .= ',IFNULL(u.email, "") as email';
        $sql .= ',IFNULL(u.location, "") as location';
        $sql .= ',IFNULL(u.postcode, "") as postcode';
        $sql .= ',IFNULL(u.country, "") as country';
        $sql .= ',IFNULL(u.phone, "") as phone';
        $sql .= ',IFNULL(u.age, "") as age';
        $sql .= ',IFNULL(u.relationshipStatus, "") as relationshipStatus';
        $sql .= ',IFNULL(u.aboutMe, "") as aboutMe';
        $sql .= ',IFNULL(u.lookingFor, "") as lookingFor';
        $sql .= ',IFNULL(u.latitude, "") as latitude';
        $sql .= ',IFNULL(u.longitude, "") as longitude';
        $sql .= ',IFNULL(u.receiveNotification, "") as receiveNotification';
        $sql .= ',IFNULL(u.isOpenToChat, "") as isOpenToChat';
        $sql .= ',u.friendCount';
        $sql .= ',u.nightclubFollowCount';
        
        if($latitude && $longitude)
            $sql .= ",DEGREES(ACOS(SIN(RADIANS($latitude)) * SIN(RADIANS(u.latitude)) + COS(RADIANS($latitude)) * COS(RADIANS(u.latitude)) * COS(RADIANS($longitude - u.longitude)))) * 111.1893006 as distance";
        else
            $sql .= ",0 as distance";

        $sql .= ',IFNULL(u.filterNearMe, "") as filterNearMe';
        $sql .= ',IFNULL(u.filterLocation, "") as filterLocation';
        $sql .= ',IFNULL(u.filterVenueType, "") as filterVenueType';
        $sql .= ',IFNULL(u.filterMusicGenre, "") as filterMusicGenre';
        $sql .= ',IFNULL(u.filterSubMusicGenre, "") as filterSubMusicGenre';
        $sql .= ',IFNULL(u.filterDressCode, "") as filterDressCode';
        $sql .= ',IFNULL(u.filterBudget, "") as filterBudget';
        $sql .= ',IFNULL(u.filterPopularity, "") as filterPopularity';
        $sql .= ',IFNULL(u.filterVenueSubType, "") as filterVenueSubType';
        $sql .= ',IFNULL(u.filterMyClubs, "") as filterMyClubs';

        $sql .= ',IFNULL(f.senderUserId, "") as senderUserId';
        $sql .= ',IF(f.friendStatus is null, 0, f.friendStatus) as isFriendStatus';
        $sql .= ',if(bu.blockedUserId is null, 0, 1) as blockedStatus';    /*0 not blocked, 1 blocked */
        $sql .= ',if(nchi.userId is null, 0, 1) as isGoing';    /*0 in-Active, 1 Going Out */
        $sql .= ',IF(w.winkStatus = 2 , 1, 0) as isWinkedBoth';
  
        $sql .= ' FROM user u';
        
        $sql .= " LEFT JOIN friend f ON ((f.senderUserId=u.id AND f.receiverUserId=$userId) OR (f.receiverUserId=u.id AND f.senderUserId=$userId))";
        $sql .= " LEFT JOIN blockUser bu ON ((bu.userId=u.id AND bu.blockedUserId=$userId) OR (bu.blockedUserId=u.id AND bu.userId=$userId))";
        //$sql .= " LEFT JOIN blockUser bu ON bu.blockedUserId=u.id AND bu.blockedUserId=$friendsUserId";
        //$sql .= " LEFT JOIN blockUser bu ON bu.blockedUserId=u.id AND bu.blockedUserId=$friendsUserId";
        $sql .= " LEFT JOIN nightclubCheckIn nchi ON nchi.userId=u.id AND nchi.userId=$friendsUserId";
        $sql .= " LEFT JOIN wink w ON ((w.senderUserId=u.id AND w.receiverUserId=$userId) OR (w.receiverUserId=u.id AND w.senderUserId=$userId))";

        $sql .= ' WHERE 1';
        $sql .= " AND u.id = $friendsUserId";
        $records = DB::select($sql);
        
        if(empty($records))
            return null;        //new \stdClass ();
        else
            return $records[0];
    }

    public static function getUserById($selectedUserId, $userId=0, $includeFilter=0)
    {
        $sql = self::getQuery($selectedUserId, $includeFilter);
        $sql .= ' WHERE 1';
        $sql .= " AND u.id = $selectedUserId";
        $records = DB::select($sql);
        if(empty($records))
            return null;        //new \stdClass ();
        else
            return $records[0];
    }
    
    public static function getUserByEmail($email, $userId=0, $includeFilter=0, $includePassword=0)
    {
        $sql = self::getQuery($userId, $includeFilter, $includePassword);
        $sql .= ' WHERE 1';
        $sql .= ' AND u.isDisabled=0';
        $sql .= " AND u.email = '$email'";
        $sql .= " AND u.role = 'User'";
        
        $records = DB::select($sql);
        
        
        if(empty($records))
            return null;        //new \stdClass ();
        else
            return $records[0];
    }
    
    public static function getUserByEmails($emails, $userId=0)
    {
        $friendIds = Friend::getFriendIds($userId);
        //$friendIds = Friend::getFriendIdRequestLists($userId);
        
        $imagePath = asset('/images/user') . '/';
        $thumbPath = asset('/images/user/thumb') . '/';
        $sql = 'SELECT u.id';
        $sql .= ',u.role';
        $sql .= ',IFNULL(u.jabberId, "") as jabberId';
        $sql .= ',IFNULL(u.firstName, "") as firstName';
        $sql .= ',IFNULL(u.surName, "") as surName';
        $sql .= ',IFNULL(CONCAT("' . $imagePath . '",u.image), "") as image';
        $sql .= ',IFNULL(CONCAT("' . $thumbPath . '",u.image), "") as thumb';
        $sql .= ',IFNULL(u.gender, "") as gender';
        $sql .= ',IF(f.friendStatus = 1 , 1, 0) as isFriendStatus';
        $sql .= ' FROM user u';
        $sql .= " LEFT JOIN blockUser bu ON ((bu.userId=u.id AND bu.blockedUserId=$userId) OR (bu.blockedUserId=u.id AND bu.userId=$userId))";
        $sql .= " LEFT JOIN friend f ON ((f.senderUserId=u.id AND f.receiverUserId=$userId) OR (f.receiverUserId=u.id AND f.senderUserId=$userId)) AND f.friendStatus=1";
        $sql .= ' WHERE 1';
        $sql .= ' AND bu.blockedUserId IS NULL';
        $sql .= ' AND u.isDisabled=0';
        $sql .= ' AND u.role IN ("User")';
        $sql .= " AND u.email IN($emails)";
        if(strlen($friendIds)>0)
        $sql .= " AND u.id NOT IN($friendIds)";
        
        if($userId)
            $sql .= " AND u.id != $userId";
        $records = DB::select($sql);
        
        return $records;
    }
    
    public static function getUserByFacebookId($facebookId, $userId=0, $includeFilter=0)
    {
        $sql = self::getQuery($userId, $includeFilter, 0);
        $sql .= ' WHERE 1';
        $sql .= ' AND u.isDisabled=0';
        $sql .= " AND u.facebookId = '$facebookId'";
        $records = DB::select($sql);
        
        if(empty($records))
            return null;        //new \stdClass ();
        else
            return $records[0];
    }
    
    public static function getUserByFacebookIds($facebookIds, $userId=0)
    {
        $friendIds = Friend::getFriendIds($userId);
        //$friendIds = Friend::getFriendIdRequestLists($userId);
        $imagePath = asset('/images/user') . '/';
        $thumbPath = asset('/images/user/thumb') . '/';

        $sql = 'SELECT u.id';
        $sql .= ',u.role';
        $sql .= ',IFNULL(u.jabberId, "") as jabberId';
        $sql .= ',IFNULL(u.firstName, "") as firstName';
        $sql .= ',IFNULL(u.surName, "") as surName';
        $sql .= ',IFNULL(CONCAT("' . $imagePath . '",u.image), "") as image';
        $sql .= ',IFNULL(CONCAT("' . $thumbPath . '",u.image), "") as thumb';
        $sql .= ',IFNULL(u.gender, "") as gender';
        $sql .= ',IF(f.friendStatus = 1 , 1, 0) as isFriendStatus';
        $sql .= ' FROM user u';
        $sql .= " LEFT JOIN blockUser bu ON ((bu.userId=u.id AND bu.blockedUserId=$userId) OR (bu.blockedUserId=u.id AND bu.userId=$userId))";
        $sql .= " LEFT JOIN friend f ON ((f.senderUserId=u.id AND f.receiverUserId=$userId) OR (f.receiverUserId=u.id AND f.senderUserId=$userId)) AND f.friendStatus=1";
        $sql .= ' WHERE 1';
        $sql .= ' AND bu.blockedUserId IS NULL';
        $sql .= ' AND u.isDisabled=0';
        $sql .= ' AND u.role IN ("User")';
        $sql .= " AND u.facebookId IN($facebookIds)";
        if(strlen($friendIds)>0)
        $sql .= " AND u.id NOT IN($friendIds)";
        
        if($userId)
            $sql .= " AND u.id != $userId";
        
        $records = DB::select($sql);
        
        return $records;
    }
    
    public static function getFriendsNearBy($userId,$latitude=0, $longitude=0, $searchText='', $exceptions='')
    {
        $friendIds = Friend::getFriendIds($userId);
        
        if(is_null($friendIds) || empty($friendIds))
            return array();
        
        $sql = self::getQuery($userId, 0, 0, 1, $latitude, $longitude);
        $sql .= ' WHERE 1';
        $sql .= ' AND bu.blockedUserId is null';
        $sql .= ' AND u.isDisabled=0';
        $sql .= ' AND u.role IN ("user")';
        $sql .= " AND u.id != $userId";
        $sql .= " AND u.id IN($friendIds)";
        
        if($searchText)
            $sql .= " AND CONCAT_WS(' ', u.firstName, u.surName) LIKE '%$searchText%'";
        
        if($exceptions)
            $sql .= " AND u.id NOT IN($exceptions)";
        
        $sql .= ' ORDER BY distance, u.firstName, u.surName';
        //$sql .= " LIMIT 15";
        $records = DB::select($sql);
        
        return $records;
    }
       
    public static function getFriendsOfFriend($userId, $friendUserId, $latitude=0, $longitude=0, $searchText='', $exceptions='')
    {
        $friendIds = Friend::getFriendIds($friendUserId);
        
        if(is_null($friendIds) || empty($friendIds))
            return array();
        
        $sql = self::getQuery($userId, 0, 0, 1, $latitude, $longitude);
        $sql .= ' WHERE 1';
        $sql .= ' AND bu.blockedUserId is null';
        $sql .= ' AND u.isDisabled=0';
        $sql .= ' AND u.role IN ("user")';
        $sql .= " AND u.id != $userId";
        $sql .= " AND u.id != $friendUserId";
        $sql .= " AND u.id IN($friendIds)";
        
        if($searchText)
            $sql .= " AND CONCAT_WS(' ', u.firstName, u.surName) LIKE '%$searchText%'";
        
        if($exceptions)
            $sql .= " AND u.id NOT IN($exceptions)";
        
        $sql .= ' ORDER BY distance, u.firstName, u.surName';
        $sql .= " LIMIT 15";
        $records = DB::select($sql);
        
        return $records;
    }
       
    public static function getStrangersNearBy($userId, $latitude=0, $longitude=0, $searchText='', $exceptions='')
    {
        $friendIds = Friend::getFriendIds($userId);
        
        $sql = self::getQuery($userId, 0, 0, 1, $latitude, $longitude);
        $sql .= ' WHERE 1';
        $sql .= ' AND bu.blockedUserId is null';
        $sql .= ' AND u.isDisabled=0';
        $sql .= ' AND u.role IN ("user")';
        $sql .= " AND u.id != $userId";
        
        if(!is_null($friendIds) && !empty($friendIds))
            $sql .= " AND u.id NOT IN($friendIds)";
        
        if($searchText)
            $sql .= " AND CONCAT_WS(' ', u.firstName, u.surName) LIKE '%$searchText%'";
        
        if($exceptions)
            $sql .= " AND u.id NOT IN($exceptions)";
        
        $sql .= ' ORDER BY distance';
        //$sql .= " LIMIT 15";
        echo $sql; die;
        $records = DB::select($sql);
        
        return $records;
    }
    
    public static function getCheckedInUsers($userId, $nightclubId)
    {
        $checkedInUserIds = NightclubCheckIn::getCheckedInUserIds($nightclubId);
        
        
        if(is_null($checkedInUserIds) || empty($checkedInUserIds))
            return array();
        
        $sql = self::getQuery($userId, 0, 0, 0);
        $sql .= ' WHERE 1';
        $sql .= ' AND bu.blockedUserId is null';
        $sql .= ' AND u.isDisabled=0';
        $sql .= ' AND u.role IN ("user")';
        $sql .= " AND u.id != $userId";
        $sql .= " AND u.id IN($checkedInUserIds)";
        
        $records = DB::select($sql);
        
        return $records;
    }
    
    public static function decrementFriendCount($userId){
        $friendIds = Friend::getFriendIds($userId);
        if(!is_null($friendIds) && !empty($friendIds))
        {
        $sql  = "UPDATE user";
        $sql .= " SET friendCount = friendCount - 1";
        $sql .= " WHERE id IN($friendIds)";
        $sql .= " AND friendCount > 0";
          
          $result = DB::update($sql);
            return $result;
          
        }
          return " ";
    }

    //Old function for near by
    // public static function getFriendsNearByFriendsAndStrangers($userId,$latitude=0, $longitude=0, $searchText='', $exceptions=''){
        
    //     $imagePath = asset('/images/user') . '/';
    //     $thumbPath = asset('/images/user/thumb') . '/';
        
    //     $sql = 'SELECT u.id';
    //     $sql .= ',u.role';
    //     $sql .= ',IFNULL(u.jabberId, "") as jabberId';
    //     $sql .= ',IFNULL(u.firstName, "") as firstName';
    //     $sql .= ',IFNULL(u.surName, "") as surName';
    //     $sql .= ',IFNULL(u.isOpenToChat, "") as isOpenToChat';
    //     $sql .= ',IFNULL(CONCAT("' . $imagePath . '",u.image), "") as image';
    //     $sql .= ',IFNULL(CONCAT("' . $thumbPath . '",u.image), "") as thumb';
    //     $sql .= ',IFNULL(u.gender, "") as gender';
        
    //     $sql .= ',IF(f.friendStatus = 2 , 1, 0) as isFriendStatus';
    //     $sql .= ',IF(w.winkStatus = 2 , 1, 0) as isWinkedBoth';
    //     if($latitude && $longitude)
    //         $sql .= ",DEGREES(ACOS(SIN(RADIANS($latitude)) * SIN(RADIANS(u.latitude)) + COS(RADIANS($latitude)) * COS(RADIANS(u.latitude)) * COS(RADIANS($longitude - u.longitude)))) * 111.1893006 as distance";
    //     else
    //         $sql .= ",0 as distance";

    //     $sql .= ' FROM user u';
        
    //     $sql .= " LEFT JOIN friend f ON ((f.senderUserId=u.id AND f.receiverUserId=$userId) OR (f.receiverUserId=u.id AND f.senderUserId=$userId))";
    //     $sql .= " LEFT JOIN wink w ON ((w.senderUserId=u.id AND w.receiverUserId=$userId) OR (w.receiverUserId=u.id AND w.senderUserId=$userId))";
    //     //$sql .= " LEFT JOIN blockUser bu ON bu.blockedUserId=u.id AND bu.userId=$userId";
    //     $sql .= " LEFT JOIN blockUser bu ON ((bu.userId=u.id AND bu.blockedUserId=$userId) OR (bu.blockedUserId=u.id AND bu.userId=$userId))";

    //     $sql .= ' WHERE 1';
    //     $sql .= ' AND bu.blockedUserId is null';
    //     $sql .= ' AND u.isDisabled=0';
    //     $sql .= ' AND u.role IN ("user")';
    //     $sql .= " AND u.id != $userId";
    //     if(empty($searchText)){
    //         //$maxDistance = 0.5;
    //         $maxDistance = 500;
    //         $sql .= " HAVING distance <= $maxDistance";
    //     }
        
    //     if($searchText)
    //         $sql .= " AND CONCAT_WS(' ', u.firstName, u.surName) LIKE '%$searchText%'";
        
    //     if($exceptions)
    //         $sql .= " AND u.id NOT IN($exceptions)";
        
    //     $sql .= ' ORDER BY isFriendStatus DESC';
    //     $sql .= " LIMIT 25";
    //     $records = DB::select($sql);
        
    //     return $records;
    // }

    //New function for near by
    public static function getFriendsNearByFriendsAndStrangers($userId,$latitude=0, $longitude=0, $searchText='', $exceptions=''){
        
        $imagePath = asset('/images/user') . '/';
        $thumbPath = asset('/images/user/thumb') . '/';
        
        $sql = 'SELECT u.id';
        $sql .= ',u.role';
        $sql .= ',IFNULL(u.jabberId, "") as jabberId';
        $sql .= ',IFNULL(u.firstName, "") as firstName';
        $sql .= ',IFNULL(u.surName, "") as surName';
        $sql .= ',IFNULL(u.isOpenToChat, "") as isOpenToChat';
        $sql .= ',IFNULL(CONCAT("' . $imagePath . '",u.image), "") as image';
        $sql .= ',IFNULL(CONCAT("' . $thumbPath . '",u.image), "") as thumb';
        $sql .= ',IFNULL(u.gender, "") as gender';
        
        $sql .= ',IF(f.friendStatus = 2 , 1, 0) as isFriendStatus';
        $sql .= ',IF(w.winkStatus = 2 , 1, 0) as isWinkedBoth';
        if($latitude && $longitude)
            $sql .= ",DEGREES(ACOS(SIN(RADIANS($latitude)) * SIN(RADIANS(u.current_latitude)) + COS(RADIANS($latitude)) * COS(RADIANS(u.current_latitude)) * COS(RADIANS($longitude - u.current_longitude)))) * 111.1893006 as distance";
        else
            $sql .= ",0 as distance";

        $sql .= ' FROM user u';
        
        $sql .= " LEFT JOIN friend f ON ((f.senderUserId=u.id AND f.receiverUserId=$userId) OR (f.receiverUserId=u.id AND f.senderUserId=$userId))";
        $sql .= " LEFT JOIN wink w ON ((w.senderUserId=u.id AND w.receiverUserId=$userId) OR (w.receiverUserId=u.id AND w.senderUserId=$userId))";
        //$sql .= " LEFT JOIN blockUser bu ON bu.blockedUserId=u.id AND bu.userId=$userId";
        $sql .= " LEFT JOIN blockUser bu ON ((bu.userId=u.id AND bu.blockedUserId=$userId) OR (bu.blockedUserId=u.id AND bu.userId=$userId))";

        $sql .= ' WHERE 1';
        $sql .= ' AND bu.blockedUserId is null';
        $sql .= ' AND u.isDisabled=0';
        $sql .= ' AND u.role IN ("user")';
        $sql .= " AND u.id != $userId";
        if(empty($searchText)){
            //$maxDistance = 0.5;
            $maxDistance = 250;
            $sql .= " HAVING distance <= $maxDistance";
        }
        
        if($searchText)
            $sql .= " AND CONCAT_WS(' ', u.firstName, u.surName) LIKE '%$searchText%'";
        
        if($exceptions)
            $sql .= " AND u.id NOT IN($exceptions)";
        
        $sql .= ' ORDER BY distance ASC';
        $sql .= " LIMIT 25";
        $records = DB::select($sql);
        
        return $records;
    }
    
}