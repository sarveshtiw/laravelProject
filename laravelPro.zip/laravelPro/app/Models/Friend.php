<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use \Illuminate\Support\Facades\DB;

class Friend extends Model {

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'friend';

    /*
     * Disable timestamps fields
     */
    //public $timestamps = false;

    /*
     * use different columns for created_at and updated_at
     */
    const CREATED_AT = 'createDate';
    const UPDATED_AT = 'updateDate';
    
    public static function getQuery()
    {
        $imagePath = asset('/images/user') . '/';
        $thumbPath = asset('/images/user/thumb') . '/';
        
        $sql = 'SELECT f.id';
        $sql .= ',f.senderUserId';
        $sql .= ',IFNULL(u1.firstName, "") as senderFirstName';
        $sql .= ',IFNULL(u1.surName, "") as senderSurName';
        $sql .= ',IFNULL(u1.jabberId, "") as senderJabberId';
        $sql .= ',IFNULL(u1.latitude, "") as senderLatitude';
        $sql .= ',IFNULL(u1.longitude, "") as senderLongitude';
        $sql .= ',IFNULL(u1.country, "") as senderLocation';
        $sql .= ',IFNULL(CONCAT("' . $imagePath . '",u1.image), "") as senderImage';
        $sql .= ',IFNULL(CONCAT("' . $thumbPath . '",u1.image), "") as senderThumb';
        $sql .= ',f.receiverUserId';
        $sql .= ',f.createDate';
        $sql .= ',IFNULL(u2.firstName, "") as receiverFirstName';
        $sql .= ',IFNULL(u2.surName, "") as receiverSurName';
        $sql .= ',IFNULL(u2.jabberId, "") as receiverJabberId';
        $sql .= ',IFNULL(CONCAT("' . $imagePath . '",u2.image), "") as receiverImage';
        $sql .= ',IFNULL(CONCAT("' . $thumbPath . '",u2.image), "") as receiverThumb';
        $sql .= ',f.friendStatus';
        
        $sql .= ' FROM friend f';
        $sql .= ' JOIN user u1 ON f.senderUserId=u1.id';
        $sql .= ' JOIN user u2 ON f.receiverUserId=u2.id';
        
        return $sql;
    }
    
    public static function getFriend($userId, $friendUserId, $friendStatus=0)
    {
        $sql = self::getQuery();
        $sql .= ' WHERE 1';
        $sql .= ' AND u1.isDisabled=0';
        $sql .= ' AND u2.isDisabled=0';
        $sql .= " AND ((f.senderUserId=$userId AND f.receiverUserId=$friendUserId) OR (f.senderUserId=$friendUserId AND f.receiverUserId=$userId))";
        
        if($friendStatus)
            $sql .= " AND f.friendStatus = $friendStatus";      /* 1 sent, 2 accepted, 3 rejected */
        
        $records = DB::select($sql);
        
        if(empty($records))
            return null;
        else
            return $records[0];
    }
    
    public static function getList($senderUserId=0, $receiverUserId=0)
    {
        $sql = self::getQuery();
        $sql .= ' WHERE 1';
        $sql .= ' AND f.friendStatus = 1';      /* 1 sent, 2 accepted, 3 rejected */
        
        if($senderUserId)
            $sql .= " AND f.senderUserId = $senderUserId";
        
        if($receiverUserId)
            $sql .= " AND f.receiverUserId = $receiverUserId";
        $records = DB::select($sql);
        
        return $records;
    }
    
    public static function getFriendIds($userId)
    {
        $sql = 'SELECT f1.senderUserId as userId';
        $sql .= ' FROM friend f1';
        $sql .= ' WHERE f1.friendStatus = 2';      /* 1 sent, 2 accepted, 3 rejected */
        $sql .= " AND f1.receiverUserId=$userId";
        
        $sql .= ' UNION';
        
        $sql .= ' SELECT f2.receiverUserId as userId';
        $sql .= ' FROM friend f2';
        $sql .= ' WHERE f2.friendStatus = 2';      /* 1 sent, 2 accepted, 3 rejected */
        $sql .= " AND f2.senderUserId=$userId";
        
        $records = DB::select($sql);
        
        $friendIds = '';
        foreach($records as $record)
        {
            $friendIds .= $record->userId . ',';
        }
        $friendIds = rtrim($friendIds, ',');
        
        return $friendIds;
    }
    
    public static function getFriendIdRequestLists($userId)
    {
        $sql = 'SELECT f1.senderUserId as userId';
        $sql .= ' FROM friend f1';
        $sql .= ' WHERE f1.friendStatus = 2 or f1.friendStatus = 1';      /* 1 sent, 2 accepted, 3 rejected */
        $sql .= " AND f1.receiverUserId=$userId";
        
        $sql .= ' UNION';
        
        $sql .= ' SELECT f2.receiverUserId as userId';
        $sql .= ' FROM friend f2';
        $sql .= ' WHERE f2.friendStatus = 2 or f2.friendStatus = 1';      /* 1 sent, 2 accepted, 3 rejected */
        $sql .= " AND f2.senderUserId=$userId";
        
        $records = DB::select($sql);
        
        $friendIds = '';
        foreach($records as $record)
        {
            $friendIds .= $record->userId . ',';
        }
        $friendIds = rtrim($friendIds, ',');
        
        return $friendIds;
    }
}
