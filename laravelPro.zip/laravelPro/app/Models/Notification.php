<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use \Illuminate\Support\Facades\DB;

class Notification extends Model {

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'notification';

    /*
     * Disable timestamps fields
     */
    //public $timestamps = false;
    
    /*
     * use different columns for created_at and updated_at
     */
    const CREATED_AT = 'createDate';
    const UPDATED_AT = 'updateDate';
    
    
    
    public static function getQuery($userId=0)
    {
        $coverImagePath = asset('/images/nightclub/cover') . '/';
        $coverThumbPath = asset('/images/nightclub/cover/thumb') . '/';
        $logoImagePath = asset('/images/nightclub/logo') . '/';
        $logoThumbPath = asset('/images/nightclub/logo/thumb') . '/';
        $imagePath = asset('/images/user') . '/';
        $thumbPath = asset('/images/user/thumb') . '/';
        $userStatusImagePath = asset('/images/userstatus') . '/';
        $userStatusThumbPath = asset('/images/userstatus/thumb') . '/';
        
        $sql = 'SELECT n.id';
        $sql .= ',IFNULL(n.senderUserId, "") as senderUserId';
        $sql .= ',IFNULL(u.jabberId, "") as jabberId';
        $sql .= ',IFNULL(CONCAT_WS(" ", u.firstName, u.surName), "") as senderFullName';
        $sql .= ',IFNULL(u.firstName, "") as senderFirstName';
        $sql .= ',IFNULL(u.surName, "") as senderSurName';
        $sql .= ',IFNULL(CONCAT("' . $imagePath . '",u.image), "") as senderImage';
        $sql .= ',IFNULL(CONCAT("' . $thumbPath . '",u.image), "") as senderthumb';
        $sql .= ',IFNULL(CONCAT("' . $userStatusImagePath . '",n.notificationImage), "") as notificationImage';
        $sql .= ',IFNULL(CONCAT("' . $userStatusThumbPath . '",n.notificationImage), "") as notificationImageThumb';
        $sql .= ',IFNULL(n.deviceId, "") as deviceId';
        $sql .= ',IFNULL(n.nightclubId, "") as nightclubId';
        $sql .= ',IFNULL(n.deviceToken, "") as deviceToken';
        $sql .= ',IFNULL(n.deviceType, "") as deviceType';
        $sql .= ',IFNULL(nc.nightclubName, "") as nightclubName';
        $sql .= ',IFNULL(n.message, "") as message';
        $sql .= ',n.notificationType';
        $sql .= ',n.notificationButtonStatus';
        $sql .= ',IFNULL(n.createDate, "") as createDate';
        $sql .= ',IFNULL(n.updateDate, "") as updateDate';
        
        $sql .= ' FROM notification n ';
        $sql .= " inner join user u on u.id = n.senderUserId AND n.receiverUserId=" . $userId;
        $sql .= " left join nightclub nc on nc.id = n.nightclubId";
        
        return $sql;
    }
    public static function getFriendNotificationList($userId = 0, $exceptions = ''){

        $friendIds = Friend::getFriendIds($userId);
        if(is_null($friendIds) || empty($friendIds))
            return array();

        $coverImagePath = asset('/images/nightclub/cover') . '/';
        $coverThumbPath = asset('/images/nightclub/cover/thumb') . '/';
        $logoImagePath = asset('/images/nightclub/logo') . '/';
        $logoThumbPath = asset('/images/nightclub/logo/thumb') . '/';
        $imagePath = asset('/images/user') . '/';
        $thumbPath = asset('/images/user/thumb') . '/';
        $userStatusImagePath = asset('/images/userstatus') . '/';
        $userStatusThumbPath = asset('/images/userstatus/thumb') . '/';
        
        $sql = 'SELECT n.id';
        $sql .= ',IFNULL(n.senderUserId, "") as senderUserId';
        $sql .= ',IFNULL(u.jabberId, "") as jabberId';
        $sql .= ',IFNULL(CONCAT_WS(" ", u.firstName, u.surName), "") as senderFullName';
        $sql .= ',IFNULL(u.firstName, "") as senderFirstName';
        $sql .= ',IFNULL(u.surName, "") as senderSurName';
        $sql .= ',IFNULL(CONCAT("' . $imagePath . '",u.image), "") as senderImage';
        $sql .= ',IFNULL(CONCAT("' . $thumbPath . '",u.image), "") as senderthumb';
        $sql .= ',IFNULL(CONCAT("' . $userStatusImagePath . '",n.notificationImage), "") as notificationImage';
        $sql .= ',IFNULL(CONCAT("' . $userStatusThumbPath . '",n.notificationImage), "") as notificationImageThumb';
        $sql .= ',IFNULL(nc.nightclubName, "") as nightclubName';
        $sql .= ',IFNULL(n.deviceId, "") as deviceId';
        $sql .= ',IFNULL(n.nightclubId, "") as nightclubId';
        $sql .= ',IFNULL(n.deviceToken, "") as deviceToken';
        $sql .= ',IFNULL(n.deviceType, "") as deviceType';
        $sql .= ',IFNULL(n.message, "") as message';
        $sql .= ',n.notificationType';
        $sql .= ',n.notificationButtonStatus';
        $sql .= ',IFNULL(n.createDate, "") as createDate';
        $sql .= ',IFNULL(n.updateDate, "") as updateDate';
        
        $sql .= ' FROM notification n ';
        $sql .= " inner join user u on u.id = n.senderUserId AND n.receiverUserId=" . $userId;
        $sql .= " left join nightclub nc on nc.id = n.nightclubId";

        $sql .= ' WHERE 1';
        $sql .= ' AND n.notificationType IN (8,9,10,13)';
        if(!empty($exceptions))
            $sql .= " AND n.id NOT IN($exceptions)";

        
        $sql .= " ORDER BY createDate DESC";
        $sql .= " LIMIT 15";
        $records = DB::select($sql);
        
        return $records;
    }

    public static function getList($userId = 0, $exceptions = '')
    {
        $sql = self::getQuery($userId);
        $sql .= ' WHERE 1';
        $sql .= ' AND n.notificationType NOT IN (8,9,10,13)';

        if(!empty($exceptions))
            $sql .= " AND n.id NOT IN($exceptions)";
        
        $sql .= " ORDER BY createDate DESC";
        $sql .= " LIMIT 15";
        //echo $sql; die;
        $records = DB::select($sql);
        
        return $records;
    }
    
}
