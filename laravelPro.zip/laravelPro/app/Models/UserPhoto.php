<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use \Illuminate\Support\Facades\DB;

class UserPhoto extends Model {

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'userPhoto';

    /*
     * Disable timestamps fields
     */
    //public $timestamps = false;

    /*
     * use different columns for created_at and updated_at
     */
    const CREATED_AT = 'createDate';
    const UPDATED_AT = 'updateDate';
    
    
    
    public static function getQuery()
    {
        $imagePath = asset('/images/user') . '/';
        $thumbPath = asset('/images/user/thumb') . '/';
        
        $sql = 'SELECT up.id';
        $sql .= ',up.userId';
        $sql .= ',u.firstName';
        $sql .= ',IFNULL(CONCAT("' . $imagePath . '",up.image), "") as image';
        $sql .= ',IFNULL(CONCAT("' . $thumbPath . '",up.image), "") as thumb';
        $sql .= ',IFNULL(up.briefInfo, "") as briefInfo';
        $sql .= ' FROM userPhoto up';
        $sql .= ' JOIN user u ON up.userId=u.id';
        
        return $sql;
    }
    
    public static function getList($userId=0, $exceptions='')
    {
        $sql = self::getQuery();
        $sql .= ' WHERE 1';
        
        if($userId)
            $sql .= " AND up.userId = $userId";
        
        if($exceptions)
            $sql .= " AND up.id NOT IN($exceptions)";
        
        $sql .= " ORDER BY up.createDate DESC";
        $sql .= " LIMIT 15";
        
        $records = DB::select($sql);
        
        return $records;
    }
    
    public static function getById($userPhotoId)
    {
        $sql = self::getQuery();
        $sql .= ' WHERE 1';
        $sql .= " AND up.id = $userPhotoId";
        
        $records = DB::select($sql);
        
        return $records;
    }

}
