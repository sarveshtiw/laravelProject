<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use \Illuminate\Support\Facades\DB;

class TaggedUser extends Model {

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'taggedUser';

    /*
     * Disable timestamps fields
     */
    //public $timestamps = false;

    /*
     * use different columns for created_at and updated_at
     */
    const CREATED_AT = 'createDate';
    const UPDATED_AT = 'updateDate';
    
    
    public static function getQuery()
    {
        $imagePath = asset('/images/user') . '/';
        $thumbPath = asset('/images/user/thumb') . '/';
        
        $sql = 'SELECT tu.id';
        $sql .= ',tu.userId';
        $sql .= ',tu.taggedUserId';
        $sql .= ',IFNULL(tu.nightclubId, "") as nightclubId';
        $sql .= ',IFNULL(tu.eventId, "") as eventId';
        $sql .= ',IFNULL(u2.firstName, "") as UserFirstName';
        $sql .= ',IFNULL(u2.surName, "") as UserSurName';
        $sql .= ',IFNULL(u2.jabberId, "") as UserJabberId';
        $sql .= ',IFNULL(CONCAT("' . $imagePath . '",u2.image), "") as image';
        $sql .= ',IFNULL(CONCAT("' . $thumbPath . '",u2.image), "") as thumb';
        $sql .= ' FROM taggedUser tu';
        $sql .= ' JOIN user u2 ON tu.taggedUserId=u2.id';
        
        return $sql;
    }
    
    
    public static function getList($nightclubId=0, $eventId=0,$userId=0)
    {
        $sql = self::getQuery();
        $sql .= ' WHERE 1';
        
        if($nightclubId)
            $sql .= " AND tu.nightclubId = $nightclubId";
        
        if($eventId)
            $sql .= " AND tu.eventId = $eventId";
        
        if($userId)
            $sql .= " AND tu.userId = $userId";
        
        $records = DB::select($sql);
        
        return $records;
    }

}
