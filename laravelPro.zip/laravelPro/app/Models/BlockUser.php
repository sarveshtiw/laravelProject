<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use \Illuminate\Support\Facades\DB;

class BlockUser extends Model {

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'blockUser';

    /*
     * Disable timestamps fields
     */
    //public $timestamps = false;

    /*
     * use different columns for created_at and updated_at
     */
    const CREATED_AT = 'createDate';
    const UPDATED_AT = 'updateDate';
    
    
    public static function getQuery()
    {
        $imagePath = asset('/images/user') . '/';
        $thumbPath = asset('/images/user/thumb') . '/';
        
        $sql = 'SELECT bu.id';
        $sql .= ',bu.userId';
        $sql .= ',bu.blockedUserId';
        $sql .= ',IFNULL(u2.firstName, "") as blockedUserFirstName';
        $sql .= ',IFNULL(u2.surName, "") as blockedUserSurName';
        $sql .= ',IFNULL(u2.jabberId, "") as blockedUserJabberId';
        $sql .= ',IFNULL(CONCAT("' . $imagePath . '",u2.image), "") as blockedUserImage';
        $sql .= ',IFNULL(CONCAT("' . $thumbPath . '",u2.image), "") as blockedUserThumb';
        $sql .= ' FROM blockUser bu';
        $sql .= ' JOIN user u2 ON bu.blockedUserId=u2.id';
        
        return $sql;
    }
    
    public static function getBlockedUsers($userId)
    {
        $sql = self::getQuery();
        $sql .= ' WHERE 1';
        $sql .= " AND bu.userId=$userId";
        
        $records = DB::select($sql);
        
        if(empty($records))
            return null;
        else
            return $records[0];
    }
    
    public static function getList($userId=0, $blockedUserId=0)
    {
        $sql = self::getQuery();
        $sql .= ' WHERE 1';
        
        if($userId)
            $sql .= " AND bu.userId = $userId";
        
        if($blockedUserId)
            $sql .= " AND bu.blockedUserId = $blockedUserId";
        
        $records = DB::select($sql);
        
        return $records;
    }
    
    public static function getBlockedIds($userId)
    {
        $sql = 'SELECT bu.blockedUserId as blockedUserId';
        $sql .= ' FROM blockUser bu';
        $sql .= " WHERE bu.userId = $userId";      /* 1 sent, 2 accepted, 3 rejected */
        
        $records = DB::select($sql);
        
        $blockedIds = '';
        foreach($records as $record)
        {
            $blockedIds .= $record->userId . ',';
        }
        $blockedIds = rtrim($blockedIds, ',');
        
        return $blockedIds;
    }

}
