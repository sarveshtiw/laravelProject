@extends('login')
@section('title', 'Login')
@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="login-box">
            <!-- <div class="login-logo">
                <a href="{{ url('/auth/login') }}"><b>Bendr</b></a>
            </div> -->
            <div class="panel panel-default">
                <div class="panel-heading">Login</div>
                <div class="panel-body">
                    @if (count($errors) > 0)
                    <div class="alert alert-danger">
                        <strong>Sorry!</strong> There were some problems with your input.<br><br>
                        <ul>
                            @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                    @endif
                    @if (Session::has('flash_message'))
                    <div class="alert alert-success">
                        <button data-dismiss="alert" class="close">
                            ×
                        </button>
                        <strong>Success!</strong> {{ Session::get('flash_message') }}
                    </div>
                    @endif 
                     @if (Session::has('flash_error'))  
                    <div class="alert alert-danger">
                        <button data-dismiss="alert" class="close">
                            ×
                        </button>
                        <strong>Error!</strong> {{ Session::get('flash_error') }}
                    </div>
                    @endif 
                    @if (Session::has('email_error'))
                    <div class="alert alert-danger">
                        <button data-dismiss="alert" class="close">
                            ×
                        </button>
                        <strong>Error!</strong> {{ Session::get('email_error') }} <a style="color:#224D67" href="{{url('/user/sendConfirmEmail')}}"> Resend? </a>
                    </div>
                    @endif 
                    <form class="form-horizontal" id="submitForm" role="form" method="POST" action="{{ url('/auth/login') }}">
                        <input type="hidden" name="_token" value="{{ csrf_token() }}">

                        <div class="form-group">

                            <div class="col-md-12">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <!-- <i class="fa fa-envelope"></i> -->
                                        <i class="fa fa fa-user"></i>
                                    </span>
                                    <input type="text" class="form-control" name="userName" placeholder="User Name" value="{{ old('userName') }}">
                                </div>
                            </div>
                        </div>

                        <div class="form-group">

                            <div class="col-md-12">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="fa fa-lock"></i>
                                    </span>
                                    <input type="password" class="form-control" name="password" placeholder="Password">
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-12">
                                <div class="checkbox">
                                    <label style="padding-left: 0;">
                                        <input type="checkbox" name="remember"> Remember Me
                                    </label>
                                </div>
                            </div>
                        </div>


                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-8 col-xs-6">
                                    <a class="btn btn-link" href="{{ url('/password/email') }}">Forgot Your Password?</a>

                                </div>
                                <div class="col-md-4 col-xs-6 text-right" style="margin-left: -16px;">
                                    <button type="submit" id="loginButton" class="btn btn-primary">Login</button>
                                </div>
                            </div>

                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
@endsection
