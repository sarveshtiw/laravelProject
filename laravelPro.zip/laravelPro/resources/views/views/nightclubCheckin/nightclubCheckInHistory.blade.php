@extends('app')
@section('title','Club Check-in Report')
@section('content')
<link href="{{ asset('/css/monthPicker.css') }}" rel="stylesheet">
<section class="content-header">
    <h1>
        Club Check-in Report
    </h1>
</section>
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Club Check-in Report
                </div>
                <div class="panel-body">
                    <form class="form-horizontal" style="margin-bottom:9px;" method="POST" enctype="multipart/form-data" action="{{URL::to('nightclub/nightclubCheckIn/getCheckInHistory')}}">
                        <input type="hidden" name="nightclubId" value="{{{Auth::user()->nightclubId}}}">
                        <?php   $today = date('d-m-Y');
                                $defaultStartDate =  date('d-m-Y', strtotime($today . ' -9 day'));
                                $defaultEndDate =  date('d-m-Y', strtotime($today . ' -2 day')); 
                        ?>
                        <input type="hidden" name="nightclubId" value="{{{Auth::user()->nightclubId}}}">
                        <?php if(!empty(Input::old('startDate'))) { ?>
                            <input type="text" style="width: 180px; position: relative; margin-right:5px" class="form-control col-xs-4" placeholder="Start Date" name="startDate" id="startDate"
                                   value="{{{ Input::old('startDate', isset($startDate) ? $startDate : $defaultStartDate)}}}">
                        <?php } else {?>
                            <input type="text" style="width: 180px; position: relative; margin-right:5px" class="form-control col-xs-4" placeholder="Start Date" name="startDate" id="startDate"
                                   value="<?php echo $defaultStartDate; ?>">
                        <?php } ?>
                        <?php if(!empty(Input::old('endDate'))) { ?>
                            <input type="text" style="width: 180px; position: relative; margin-right:5px" class="form-control col-xs-4" placeholder="End Date" name="endDate" id="endDate"
                                value="{{{ Input::old('endDate', isset($endDate) ? $endDate : $defaultEndDate)}}}">
                        <?php } else {?>
                            <input type="text" style="width: 180px; position: relative; margin-right:5px" class="form-control col-xs-4" placeholder="End Date" name="endDate" id="endDate"
                                value="<?php echo $defaultEndDate;?>">
                        <?php } ?>
    
                        <button class="btn btn-default" style="position: relative;" type="submit"><i class="glyphicon glyphicon-search"></i></button>

                    </form>
                    <p style="text-align:left"><strong>Disclaimer</strong>: Male, Female count and Average Age are shown only if the user has provided them in his profile.</p>
                    @if (isset($checkInHistorys) && count($checkInHistorys) > 0)

                    <table class="table table-striped table-bordered table-hover table-responsive" id="mytable">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Total Check-in</th>
                                <th>Male</th>
                                <th>Female</th>
                                <th>Average Age</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($checkInHistorys as $checkInHistory)
                            <tr>
                                <td>{{ date('d-m-Y',strtotime($checkInHistory->date)) }}</td>
                                <td>{{ $checkInHistory->entries }}</td>
                                <td>{{ $checkInHistory->males }}</td>
                                <td>{{ $checkInHistory->females}}</td>
                                <td>{{ round($checkInHistory->ageAverage,1) }}</td>
                            </tr>
                            @endforeach
                        </tbody>

                    </table>
                    <?php echo isset($links)?$links:null ?>
                    @else
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> No records found.<br><br>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<script>
  $(document).ready(function(){
    var todayDate = new Date();
    $('#startDate').datetimepicker({ format:'d-m-Y', timepicker:false, maxDate:new Date(todayDate.getFullYear(),todayDate.getMonth(),todayDate.getDate() - 2)});
    $('#endDate').datetimepicker({ format:'d-m-Y', timepicker:false, maxDate:new Date(todayDate.getFullYear(),todayDate.getMonth(),todayDate.getDate() - 2)});
}); 
</script>


@endsection
