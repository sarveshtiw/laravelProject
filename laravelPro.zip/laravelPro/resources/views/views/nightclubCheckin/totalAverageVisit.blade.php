@extends('app')
@section('title','Average Time of Entry')
@section('content')
<section class="content-header">
    <h1>
        Average Time of Entry
    </h1>
</section>
<link href="{{ asset('/css/monthPicker.css') }}" rel="stylesheet">
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Average Time of Entry
                </div>
                <div class="panel-body">
                    <form class="form-horizontal" style="margin-bottom:9px;" method="POST" enctype="multipart/form-data" action="{{URL::to('nightclub/nightclubCheckIn/getAverageVisitTime')}}">
                        <input type="hidden" name="nightclubId" value="{{{Auth::user()->nightclubId}}}">
                        <?php   $today = date('d-m-Y');
                                $defaultStartDate =  date('d-m-Y', strtotime($today . ' -9 day'));
                                $defaultEndDate =  date('d-m-Y', strtotime($today . ' -2 day')); 
                        ?>
                        <input type="hidden" name="nightclubId" value="{{{Auth::user()->nightclubId}}}">
                        <?php if(!empty(Input::old('startDate'))) { ?>
                            <input type="text" style="width: 180px; position: relative; margin-right:5px" class="form-control col-xs-4" placeholder="Start Date" name="startDate" id="startDate"
                                   value="{{{ Input::old('startDate', isset($startDate) ? $startDate : $defaultStartDate)}}}">
                        <?php } else {?>
                            <input type="text" style="width: 180px; position: relative; margin-right:5px" class="form-control col-xs-4" placeholder="Start Date" name="startDate" id="startDate"
                                   value="<?php echo $defaultStartDate; ?>">
                        <?php } ?>
                        <?php if(!empty(Input::old('endDate'))) { ?>
                            <input type="text" style="width: 180px; position: relative; margin-right:5px" class="form-control col-xs-4" placeholder="End Date" name="endDate" id="endDate"
                                value="{{{ Input::old('endDate', isset($endDate) ? $endDate : $defaultEndDate)}}}">
                        <?php } else {?>
                            <input type="text" style="width: 180px; position: relative; margin-right:5px" class="form-control col-xs-4" placeholder="End Date" name="endDate" id="endDate"
                                value="<?php echo $defaultEndDate;?>">
                        <?php } ?>
    
                        <button class="btn btn-default" style="position: relative;" type="submit"><i class="glyphicon glyphicon-search"></i></button>

                    </form>

                    @if (isset($totalAverageVisit) && count($totalAverageVisit) > 0)

                    <table class="table table-striped table-bordered table-hover table-responsive" id="mytable">
                        <thead>
                            <tr>
                                <th>Total Users</th>
                                <th>Average Time(in hours)</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($totalAverageVisit as $totalAverage)
                            <tr>
                                <td>{{ $totalAverage->userCount }}</td>
                                <td>{{ round($totalAverage->averageExpendTime,2) }}</td>
                            </tr>
                            @endforeach
                        </tbody>

                    </table>
                    <?php echo isset($links)?$links:null ?>
                    @else
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> No records found.<br><br>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// $(function() {
//     $('.date-picker').datepicker( {
//         changeMonth: true,
//         changeYear: true,
//         showButtonPanel: true,
//         dateFormat: 'MM yy',
//         onClose: function(dateText, inst) { 
//             var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
//             var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
//             $(this).datepicker('setDate', new Date(year, month, 1));
//         }
//     });
// });
$(document).ready(function(){
    var todayDate = new Date();
    $('#startDate').datetimepicker({ format:'d-m-Y', timepicker:false, maxDate:new Date(todayDate.getFullYear(),todayDate.getMonth(),todayDate.getDate() - 2)});
    $('#endDate').datetimepicker({ format:'d-m-Y', timepicker:false, maxDate:new Date(todayDate.getFullYear(),todayDate.getMonth(),todayDate.getDate() - 2)});
}); 
  
</script>
@endsection
