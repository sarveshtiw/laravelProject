@extends('app')
@section('title','Terms & Conditions')
@section('content')

<style>
    p {
        padding: 5px;
    }
</style>
<section class="content-header">
    <h1>
        Terms & Conditions
    </h1>
</section>   
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Terms & Conditions
                    <b><a href="{{ url('setting/editTerms/1') }}" data-toggle="tooltip" data-placement="top" data-original-title="Edit" class="pull-right">Edit </a></b>
                </div>
                <div class="panel-body">
                    <!-- Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. -->
                    {{ $terms->description}}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
