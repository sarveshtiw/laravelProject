@extends('app')
@section('title','Reported Group List')
@section('content')

<section class="content-header">
    <h1>
        Reported Group List
    </h1>
</section>   
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Reported Group List
                </div>
                <div class="panel-body">
                    <form class="form-inline" style="margin-bottom:9px;" method="POST" enctype="multipart/form-data" action="{{URL::to('group/searchReportedGroups')}}">
                        <input type="text" class="form-control col-xs-4" style="width:180px; position: relative; margin-right:2px" placeholder="Group Name" name="groupName" value="{{{ Input::old('groupName', isset($searchCriteria) ? $searchCriteria['groupName'] : null)}}}">&nbsp;
                        <button class="btn btn-default" style="position: relative; margin-right:2px" type="submit"><i class="glyphicon glyphicon-search"></i></button>
                    </form>
                    @if (count($reportedGroups) > 0)
                    <table class="table table-striped table-bordered table-hover table-responsive" id="mytable">
                        <thead>
                            <tr>
                                <th>Reported Group</th>
                                <th>Reported By</th>
                                <th>Reported Date</th>
                                <!-- <th>Reported Reason</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($reportedGroups as $reportedGroup)
                            <tr>
                                <td>{{ ucwords($reportedGroup->chatRoomName) }}</td>
                                <td>{{ ucwords($reportedGroup->reportedByUserFirstName) }} {{ucwords($reportedGroup->reportedByUserSurName) }}</td>
                                <td>{{ date('d-m-Y h:i A', strtotime($reportedGroup->createDate)) }}</td>
                                <!-- <td>{{ ucwords($reportedGroup->reportReason) }}</td> -->
                            </tr>
                            @endforeach
                        </tbody>

                    </table>
                    <?php echo $reportedGroups->appends(Request::input())->render(); ?>
                    @else
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> No records found for reported groups.<br><br>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
