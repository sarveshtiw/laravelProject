@extends('app')
@section('title','Suggested Venue Details')
@section('content')

<section class="content-header">
    <h1>
        Suggested Venue Details
    </h1>
</section>   
<div class="content">
    <div class="col-sm-12">
        <div class="panel panel-default">
            
            <div class="panel-heading">
                <b>Suggested Venue Details</b>
                <div style="float:right">
                    <b><a style="position: relative;" href="{{ url('suggestvenue/list') }}">Back</a></b>
                </div>
            </div>

            <div class="panel-body">
                @if (isset($flash_message))  
                    <div class="alert alert-success">
                        <button data-dismiss="alert" class="close">
                            ×
                        </button>
                        <strong>Success!</strong> {{ $flash_message }}
                    </div>          
                @endif 
                <form class="" style="margin-bottom:9px;" method="POST" enctype="multipart/form-data" action="{{URL::to('suggestvenue/addSuggestVenue/'.$suggestedVenueDetails->id)}}">
                    @if (count($suggestedVenueDetails) > 0)
                        
                        <div class="form-group row">
                            <label class="control-label col-sm-3 leftalign">Venue Name : </label>
                            <label class="control-label col-sm-7 leftalign">{{ ucwords($suggestedVenueDetails->venueName) }}</label>
                        </div>

                        <div class="form-group row">
                            <label class="control-label col-sm-3 leftalign">Venue Type : </label>
                            <label class="control-label col-sm-7 leftalign">{{ ucwords($suggestedVenueDetails->venueTypeName) }}</label>
                        </div>

                        <div class="form-group row">
                            <label for="briefInfo" class="control-label col-sm-3 leftalign">Requested By :</label>
                            <label class="control-label col-sm-7 leftalign">{{ ucfirst($suggestedVenueDetails->firstName) }} {{ucfirst($suggestedVenueDetails->surName) }}</label>
                        </div>

                        <div class="form-group row">
                            <label for="briefInfo" class="control-label col-sm-3 leftalign">Owner :</label>
                            <label class="control-label col-sm-7 leftalign"> @if($suggestedVenueDetails->isClubOwner) Yes @else No @endif </label>
                        </div>

                        <div class="form-group row">
                            <label for="briefInfo" class="control-label col-sm-3 leftalign">Requested By :</label>
                            <label class="control-label col-sm-7 leftalign">{{ ucfirst($suggestedVenueDetails->firstName) }} {{ucfirst($suggestedVenueDetails->surName) }}</label>
                        </div>

                        <div class="form-group row">
                            <label for="briefInfo" class="control-label col-sm-3 leftalign">Location :</label>
                            <label class="control-label col-sm-3 leftalign">{{ ucfirst($suggestedVenueDetails->location) }}</label>
                        </div>

                        <div class="form-group row">
                            <label for="briefInfo" class="control-label col-sm-3 leftalign">Contact Details :</label>
                            <label class="control-label col-sm-7 leftalign">{{ ucfirst($suggestedVenueDetails->contactDetails) }}</label>
                        </div>

                        <div class="form-group row">
                            <label class="control-label col-sm-3 leftalign">Added:</label>
                            <label class="control-label col-sm-7 leftalign">@if(!empty($suggestedVenueDetails->sunClosingTime) && $suggestedVenueDetails->isAdded==1) Added @else Not Added @endif </label>
                        </div>

                        <div class="form-group row">
                            <label class="control-label col-sm-12 leftalign">
                                <table class="table table-striped table-bordered table-hover table-responsive">
                                    <tr>
                                        <th>Day</th>
                                        <th>Opening Time</th>
                                        <th>Closing Time</th>
                                    </tr>
                                    <tr>
                                        <td>Monday</td>
                                        <td>@if(!empty($suggestedVenueDetails->monOpeningTime)) {{ date('h:i A',strtotime($suggestedVenueDetails->monOpeningTime)) }} @endif</td>
                                        <td>@if(!empty($suggestedVenueDetails->monClosingTime)) {{ date('h:i A',strtotime($suggestedVenueDetails->monClosingTime)) }} @endif</td>
                                    </tr>
                                    <tr>
                                        <td>Tuesday</td>
                                        <td>@if(!empty($suggestedVenueDetails->tueOpeningTime)) {{ date('h:i A',strtotime($suggestedVenueDetails->tueOpeningTime)) }} @endif</td>
                                        <td>@if(!empty($suggestedVenueDetails->tueClosingTime)) {{ date('h:i A',strtotime($suggestedVenueDetails->tueClosingTime)) }} @endif</td>
                                    </tr>
                                    <tr>
                                        <td>Wednesday</td>
                                        <td>@if(!empty($suggestedVenueDetails->wedOpeningTime)) {{ date('h:i A',strtotime($suggestedVenueDetails->wedOpeningTime)) }} @endif</td>
                                        <td>@if(!empty($suggestedVenueDetails->wedClosingTime)) {{ date('h:i A',strtotime($suggestedVenueDetails->wedClosingTime)) }} @endif</td>
                                    </tr>
                                    <tr>
                                        <td>Thursday</td>
                                        <td>@if(!empty($suggestedVenueDetails->thuOpeningTime)) {{ date('h:i A',strtotime($suggestedVenueDetails->thuOpeningTime)) }} @endif</td>
                                        <td>@if(!empty($suggestedVenueDetails->thuClosingTime)) {{ date('h:i A',strtotime($suggestedVenueDetails->thuClosingTime)) }} @endif</td>
                                    </tr>
                                    <tr>
                                        <td>Friday</td>
                                        <td>@if(!empty($suggestedVenueDetails->friOpeningTime)) {{ date('h:i A',strtotime($suggestedVenueDetails->friOpeningTime)) }} @endif</td>
                                        <td>@if(!empty($suggestedVenueDetails->friClosingTime)) {{ date('h:i A',strtotime($suggestedVenueDetails->friClosingTime)) }} @endif</td>
                                    </tr>
                                    <tr>
                                        <td>Saturday</td>
                                        <td>@if(!empty($suggestedVenueDetails->satOpeningTime)) {{ date('h:i A',strtotime($suggestedVenueDetails->satOpeningTime)) }} @endif</td>
                                        <td>@if(!empty($suggestedVenueDetails->satClosingTime)) {{ date('h:i A',strtotime($suggestedVenueDetails->satClosingTime)) }} @endif</td>
                                    </tr>
                                    <tr>
                                        <td>Sunday</td>
                                        <td>@if(!empty($suggestedVenueDetails->sunOpeningTime)) {{ date('h:i A',strtotime($suggestedVenueDetails->sunOpeningTime)) }} @endif</td>
                                        <td>@if(!empty($suggestedVenueDetails->sunClosingTime)) {{ date('h:i A',strtotime($suggestedVenueDetails->sunClosingTime)) }} @endif</td>
                                    </tr>
                                </table>
                            </label>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 leftalign">
                                @if($suggestedVenueDetails->isAdded!=1)
                                    <button class="btn btn-default" style="position: relative; margin-right:2px" type="submit" name="clubAdded">Add</button></label>
                                @else
                                    <button class="btn btn-default" style="position: relative; margin-right:2px" type="submit" name="clubRevoked">Revoke</button></label>
                                @endif
                        </div>
                    @else
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> No records found for suggested venues.<br><br>
                        </div>
                    @endif
                </form>
            </div>
        </div>
    </div>
</div>
</div>
@endsection

