@extends('app')
@section('title','Suggested Venue List')
@section('content')

<section class="content-header">
    <h1>
        Suggested Venues
    </h1>
</section>   
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Suggested Venue</div>
                <div class="panel-body">

                    @if (count($suggestedVenueList) > 0)
                    <table class="table table-striped table-bordered table-hover table-responsive" id="mytable">
                        <thead>
                            <tr>
                                <th>Venue Name</th>
                                <th>Venue Type</th>
                                <th>Requested By</th>
                                <th>Location</th>
                                <th>Owner</th>
                                <th>is Added</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($suggestedVenueList as $suggestedVenue)
                            <tr>
                                <td><a href="{{url('/suggestvenue/suggestVenueDetails/'.$suggestedVenue->id)}}">{{ ucwords($suggestedVenue->venueName) }}</a></td>
                                <td>{{ ucfirst($suggestedVenue->venueTypeName) }}</td>
                                <td>{{ ucfirst($suggestedVenue->firstName) }} {{ucfirst($suggestedVenue->surName) }}</td>
                                <td>{{ ucfirst($suggestedVenue->location) }}</td>
                                <td>@if($suggestedVenue->isClubOwner) Yes @else No @endif </td>
                                <td>@if($suggestedVenue->isAdded) Added @else Not Added @endif</td>
                            </tr>
                            @endforeach
                        </tbody>

                    </table>
                    <?php echo $suggestedVenueList->appends(Request::input())->render(); ?>
                    @else
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> No records found for suggested venues.<br><br>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
