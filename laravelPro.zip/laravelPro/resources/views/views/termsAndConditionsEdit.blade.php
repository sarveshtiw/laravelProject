@extends('app')
@section('title','Terms & Conditions')
@section('content')

<section class="content-header">
    <h1>
        Edit Terms & Conditions
    </h1>
</section> 
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <form method="POST" enctype="multipart/form-data" action="{{URL::to('setting/updateTerms')}}"
                  files="true"   accept-charset="UTF-8">
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <input type="hidden" name="id" value="{{ isset($terms) ? $terms->id : null  }}">

                @if (Session::has('flash_message'))  
                <div class="alert alert-success">
                    <button data-dismiss="alert" class="close">
                        ×
                    </button>
                    <strong>Success!</strong> {{ Session::get('flash_message') }}
                </div>
                @endif 
                @if (Session::has('error_message')) 
                <div class="alert alert-danger">
                        <ul>
                            <li> {{Session::get('error_message')}} </li>
                        </ul>
                    </div>
                @endif
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <b>Terms & Conditions
                            </b>
                            <div style="float:right">
                                <b><a style="position: relative;" href="{{ url('setting/viewTerms') }}">Back</a></b>
                            </div>
                        </div>
                        <div class="panel-body">
                            <?php if ($errors->count() > 0) { ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php foreach ($errors->all() as $messages) { ?>
                                            <li> <?php echo $messages ?> </li>
                                        <?php } ?>
                                    </ul>
                                </div>
                            <?php } ?>
                            <div class="col-sm-5">
                                <div class="form-group row">
                                    <label for="name" class="control-label">Description</label>
                                    <div>
                                        <textarea type="text" class="form-control" id="description" name="description" placeholder="Description" style="height:400px;width:800px">{{{ Input::old('title', isset($terms) ? $terms->description : null)}}}</textarea>
                                    </div>

                                </div>

                                <div class="form-group">
                                    <div class="col-sm-12 row">
                                        <button type="submit" class="btn btn-primary">Save</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
</div>

</div>

@endsection


