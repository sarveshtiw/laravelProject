@extends('app')
@section('title','Unauthorized Access')
@section('content')
<section class="content-header">
    <h1>
        Unauthorized Access
    </h1>
    <!-- <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
    </ol> -->
</section>   
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Unauthorized Access</div>
                <div class="panel-body">
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> You are not authorized to access this page.<br><br>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
