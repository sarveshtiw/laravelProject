@extends('app')
@section('title','Event Details')
@section('content')

<section class="content-header">
    <h1>
        Import Events from Facebook
    </h1>
</section>
<div class="content">
    <form class="form-horizontal" method="POST" enctype="multipart/form-data"
          accesskey=""   accept-charset="UTF-8">
        <input type="hidden" name="_token" value="{{ csrf_token() }}">
        <input type="hidden" id="eventId" name="eventId" value="">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <b>Import Events from Facebook</b>
                    <div style="float:right">
                    </div>
                </div>
                <div class="panel-body">
                    <a href="{{$facebook_login_url }}">Import Events</a>
                </div>
            </div>
        </div>
    </form>
</div>
</div>
@endsection