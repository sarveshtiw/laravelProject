@extends('app')
@section('title','Edit Event')
@section('content')

<section class="content-header">
    <h1>
        Edit Event
    </h1>
</section> 
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <form method="POST" enctype="multipart/form-data" action="{{URL::to('nightclub/editEvent')}}"
                  files="true"   accept-charset="UTF-8"  onsubmit="return validateAddEvent()">
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <input type="hidden" name="nightclubId" value="{{ isset($nightclubEventDetails) ? $nightclubEventDetails->nightclubId : Auth::user()->nightclubId  }}">
                <input type="hidden" name="nightclubEventId" id="nightclubEventId" value="{{{ Input::old('nightclubEventId', isset($nightclubEventDetails) ? $nightclubEventDetails->nightclubEventId : null)}}}">
                <div class="alert alert-danger" style="display:none" id="jsAlertNotification">
                    <ul>
                        <span id="titleInput"><li> The title field is required. </li></span>
                        <span id="startDateInput"><li> The start date time field is required. </li></span>
                        <span id="endDateInput"><li> The end date time field is required. </li></span>
                        <span id="briefInfoInput"><li> The brief info field is required. </li></span>
                        <!-- <span id="eventImageInput"><li> The image field is required. </li></span> -->
                        <span id="eventAdminInput"><li> The event admin field is required. </li></span>
                    </ul>
                </div>
                @if (Session::has('flash_message'))  
                <div class="alert alert-success">
                    <button data-dismiss="alert" class="close">
                        ×
                    </button>
                    <strong>Success!</strong> {{ Session::get('flash_message') }}
                </div>
                @endif 
                @if (Session::has('error_message')) 
                <div class="alert alert-danger">
                        <ul>
                            <li> {{Session::get('error_message')}} </li>
                        </ul>
                    </div>
                @endif
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <b>Edit Event
                            </b>
                            <div style="float:right">
                                <b><a style="position: relative;" href="{{ url('nightclub/allEventDetails') }}">Back</a></b>
                            </div>
                        </div>
                        <div class="panel-body">
                            <?php if ($errors->count() > 0) { ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php foreach ($errors->all() as $messages) { ?>
                                            <li> <?php echo $messages ?> </li>
                                        <?php } ?>
                                    </ul>
                                </div>
                            <?php } ?>
                            <div class="col-sm-5">
                                <div class="form-group row">
                                    <label for="name" class="control-label">Title <span class="required_span">*</span></label>
                                    <div>
                                        <input type="text" class="form-control" id="title" name="title" placeholder="Title"
                                               value="{{{ Input::old('title', isset($nightclubEventDetails) ? $nightclubEventDetails->title : null)}}}">
                                    </div>

                                </div>


                                <div class="form-group row">
                                    <label for="startDayTime" class="control-label">Start Date Time <span class="required_span">*</span></label>
                                    <div>
                                        <input id="startDateTime" name="startDateTime" class="form-control" type="text" 
                                               value="{{{Input::old('startDateTime',isset($nightclubEventDetails)?$nightclubEventDetails->startDateTime : null)}}}" placeholder="Start Date Time">
                                    </div>

                                </div>
                                <div class="form-group row">
                                    <label for="endDateTime" class="control-label">End Date Time <span class="required_span">*</span></label>
                                    <div>
                                        <input id="endDateTime" name="endDateTime" class="form-control" type="text" 
                                               value="{{{Input::old('endDateTime',isset($nightclubEventDetails)?$nightclubEventDetails->endDateTime : null)}}}" placeholder="End Date Time">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="briefInfo" class="control-label">Brief Info <span class="required_span">*</span></label>
                                    <div>
                                        ​<textarea id="info" maxlength="{{config('constants.descriptionAllowedCharacters')}}" name="briefInfo" rows="5" cols="52" class="form-control" placeholder="Brief Info">{{{Input::old('briefInfo',isset($nightclubEventDetails) ? $nightclubEventDetails->briefInfo : null)}}}</textarea>
                                        <span id="briefInfo_count" style="float:right">{{abs(strlen($nightclubEventDetails->briefInfo) - config('constants.descriptionAllowedCharacters'))}}  Characters</span>
                                    </div>
                                </div>
                                @if(\Auth::user()->role == "club admin")
                                <div class="form-group row">
                                    <label for="userEmail" class="control-label">Event Admin<!-- <span class="required_span">*</span> --></label>
                                    <div>
                                        <select name="userEmail" class="form-control">
                                            <option value="">Email--First Name</option> 
                                            @if(isset($users))
                                            @foreach($users as $user)
                                            <option value="{{$user->email}}" @if($nightclubEventDetails->assignedEmail==$user->email)  selected='selected' @endif>{{$user->firstName}}--{{$user->email}}</option>
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                                @endif

                                @if(\Auth::user()->role == "event admin")
                                <div class="form-group row">
                                    @if(isset($users))
                                    <input type="hidden" class="form-control" name="userEmail"
                                           value="{{isset($users)?$users->email : null}}">
                                    @endIf
                                </div>
                                @endif 

                                <div class="form-group">
                                    <div class="col-sm-12 row">
                                        <button type="submit" class="btn btn-primary">Save</button>
                                    </div>
                                </div>
                            </div>


                            <div class="col-sm-1"></div>

                            <div class="col-sm-6">

                                <div class="form-group row">
                                    <label for="image" class="control-label">Event Main Image <span class="required_span">*</span></label>
                                    <div>
                                        <input type="file" class="form-control" id="img" onchange="readURL(this, 'image');" name="image"
                                               value="{{{Input::old('image',isset($nightclubEventDetails)?$nightclubEventDetails->image : null)}}}">
                                    </div>
                                    <img id="image" style="height:100px; width:100px;" src="{{{Input::old('image',isset($nightclubEventDetails)?$nightclubEventDetails->image : null)}}}"/>
                                </div>

                                
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <b>Additional Event Photos </b><span>(Up to {{config('constants.maxEventAdditionalIamge')}} images)</span>
                        </div>
                        <div class="panel-body">
                            <div class="" id="imageSuccessDiv" style="display:none">Event Additional Images Uploaded Successfully.</div>
                            <div class="form-group row" >
                                @if(\Auth::user()->role == "club admin" || \Auth::user()->role == "event admin")
                                <div class="form-inline" style="margin-left:12px !important">
                                    <div id="fileuploader" style="curson:pointer">Browse Files </div>
                                    <div id="startUpload" style="margin-top: 15px;" style="curson:pointer">
                                        <input type="button" class="btn btn-primary" value="Upload to Server" style="margin-left: 10px; curson:pointer" />
                                    </div>
                                </div>
                                @endif
                            </div> 
                            <div class="row" style="padding: 10px;">
                                @if (isset($nightclubEventImages))

                                @foreach ($nightclubEventImages as $image)
                                <div class="additionalImageDiv">
                                    <img src="{{$image->image}}" style="width:180px;height:150px" class="img-thumbnail" >
                                    <a href="{{asset('index.php/nightclub/deleteEventImages?eventId='.$image->nightclubEventId.'&eventPhotoId='.$image->id.'&actionPage=edit')}}" onclick="return confirm('Are you sure want to delete selected image? ')"><span>Remove</span></a>
                                </div>
                                @endforeach  

                                @endif

                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
</div>

</div>
<script>
    function readURL(input, data) {
        var imageId = '#' + data;
        if (input.files && input.files[0]) {
            var reader = new FileReader();


            reader.onload = function (showImage) {
                $(imageId)
                        .attr('src', showImage.target.result)
                        .width(100)
                        .height(100);
            };

            reader.readAsDataURL(input.files[0]);
        }

    }

    $.datetimepicker.setDateFormatter({
        parseDate: function (date, format) {
            var d = moment(date, format);
            return d.isValid() ? d.toDate() : false;
        },
        
        formatDate: function (date, format) {
            return moment(date).format(format);
        }
    });

    $(document).ready(function(){
        $('#startDateTime').datetimepicker({ format:'DD-MM-YYYY h:mm a',formatTime:'h:mm a',formatDate:'DD-MM-YYYY', step:60, ampm: true, minDate: new Date()});
        $('#endDateTime').datetimepicker({ format:'DD-MM-YYYY h:mm a',formatTime:'h:mm a',formatDate:'DD-MM-YYYY', step:60, ampm: true, minDate: new Date()});
        $("#info").on("keyup",function(event){
            var length = this.value.length;
            var char_count = parseInt("{{config('constants.descriptionAllowedCharacters')}}")  - parseInt(length);
            $("#briefInfo_count").html(char_count+" Characters");
        });
    }); 

    function validateAddEvent(){
        var flag=true;

        if($("#title").val()==''){
            flag = false;
            $("#titleInput").css("display","block");
        }else{
            $("#titleInput").css("display","none");
        }

        if($("#startDateTime").val()==''){
            flag = false;
            $("#startDateInput").css("display","block");
        }else{
            $("#startDateInput").css("display","none");
        }

        if($("#endDateTime").val()==''){
            flag = false;
            $("#endDateInput").css("display","block");
        }else{
            $("#endDateInput").css("display","none");
        }

        if($("#info").val()==''){
            flag = false;
            $("#briefInfoInput").css("display","block");
        }else{
            $("#briefInfoInput").css("display","none");
        }
        
        // if($("#userEmail").val()==''){
        //     flag = false;
        //     $("#eventAdminInput").css("display","block");
        // }else{
        //     $("#eventAdminInput").css("display","none");
        // }
        // if($("#img").val()==''){
        //     flag = false;
        //     $("#eventImageInput").css("display","block");
        // }else{
        //     $("#eventImageInput").css("display","none");
        // }
        
        if(flag)
            $("#jsAlertNotification").css("display","none");
        else
            $("#jsAlertNotification").css("display","block");
        return flag;
    }
</script>
<script>

    var id = $("#nightclubEventId").val();
    var uploadObj = $("#fileuploader").uploadFile({
        autoSubmit: false,
        url: "{{asset('index.php/nightclub/uploadEventMultipleImages')}}",
        fileName: "myfile",
        formData: {"id": id},
        maxFileCount:"{{ config('constants.maxEventAdditionalIamge') - count($nightclubEventImages) }}",
        acceptFiles:"image/*",
        maxFileSize:5240000,
        afterUploadAll: function ()
        {
            location.reload(); 
            // $(".ajax-file-upload-green").parent().hide();
            // $("#imageSuccessDiv").css("display","block");
            // $("#imageSuccessDiv").fadeOut(20000);
        }
    });

    $("#startUpload").click(function ()
    {
        uploadObj.startUpload();
    });

</script>

@endsection


