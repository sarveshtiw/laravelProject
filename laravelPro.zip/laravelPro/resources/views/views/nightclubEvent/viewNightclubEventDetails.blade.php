@extends('app')
@section('title','Event Details')
@section('content')

<section class="content-header">
    <h1>
        Event Details
    </h1>
</section>
<div class="content">
    <form class="form-horizontal" method="POST" enctype="multipart/form-data"
          accesskey=""   accept-charset="UTF-8">
        <input type="hidden" name="_token" value="{{ csrf_token() }}">
        <input type="hidden" id="eventId" name="eventId" value="{{$nightclubEventDetails->nightclubEventId}}">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <b>Event Details</b>
                    <div style="float:right">
                        <b><a style="position: relative;" href="{{ url('nightclub/allEventDetails') }}">Back</a></b>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="form-group row">
                        <label class="control-label col-sm-4 leftalign">Image :</label>
                        <img class="leftalign" style="height:150px; width:200px; margin-left:15px; " src="{{$nightclubEventDetails->image}}"/>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-4 leftalign">Title : </label>
                        <label class="control-label col-sm-6 leftalign">{{$nightclubEventDetails->title}}</label>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-4 leftalign">Club Name : </label>
                        <label class="control-label col-sm-6 leftalign">{{$nightclubEventDetails->nightclubName}}</label>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-4 leftalign">Start :</label>
                        <label class="control-label col-sm-6 leftalign">{{ date('d-m-Y h:i A',strtotime($nightclubEventDetails->startDateTime)) }}</label>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-4 leftalign">End :</label>
                        <label class="control-label col-sm-6 leftalign">{{ date('d-m-Y h:i A',strtotime($nightclubEventDetails->endDateTime)) }}</label>
                    </div>


                    <div class="form-group row">
                        <label for="briefInfo" class="control-label col-sm-4 leftalign">Brief Info :</label>
                        <label class="control-label col-sm-6 leftalign">{{$nightclubEventDetails->briefInfo}}</label>
                    </div>


                    <!-- <div class="form-group row">
                        <label for="dressCode" class="control-label col-sm-4 leftalign">Dress Code :</label>
                        <label class="control-label col-sm-6 leftalign">{{$nightclubEventDetails->dressCode}}</label>
                    </div>

                    <div class="form-group row">
                        <label for="musicGenre" class="control-label col-sm-4 leftalign">Music Genre :</label>
                        <label class="control-label col-sm-6 leftalign">{{$nightclubEventDetails->musicGenre}}</label>
                    </div> -->

                </div>
                 
            </div>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <b>Additional Event Photos</b>
                </div>
                <div class="panel-body">
                    <!-- <div class="form-group row" >
                        @if(\Auth::user()->role == "club admin" || \Auth::user()->role == "event admin")
                        <div class="form-inline" style="margin-left:12px !important">
                            <div id="fileuploader" style="curson:pointer">Browse Files </div>

                            <div id="startUpload" style="margin-top: 5px;" style="curson:pointer">
                                <input type="button" class="btn btn-primary" value="Upload to Server" style="margin-left: 10px; curson:pointer"/>
                            </div>
                        </div>
                        @endif
                    </div>  -->
                    <div class="row" style="padding: 10px;">
                        @if (isset($nightclubEventImages))

                        @foreach ($nightclubEventImages as $image)
                        <div class="additionalImageDiv">
                            <img src="{{$image->image}}" style="width:180px;height:150px" class="img-thumbnail" >
                        </div>
                        @endforeach  

                        @endif

                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
</div>
<script>
    var id = $("#eventId").val();
    var uploadObj = $("#fileuploader").uploadFile({
        autoSubmit: false,
        url: "{{asset('index.php/nightclub/uploadEventMultipleImages')}}",
        fileName: "myfile",
        formData: {"id": id},
        maxFileCount:3,
        acceptFiles:"image/*",
        maxFileSize:5240000,
        afterUploadAll: function ()
        {
            location.reload();
        }
    });

    $("#startUpload").click(function ()
    {
        uploadObj.startUpload();
    });

</script>
@endsection