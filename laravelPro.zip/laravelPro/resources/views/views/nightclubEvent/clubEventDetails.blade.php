@extends('app')
@section('title','Event List')
@section('content')

<style type="text/css">
.tdButtonAlign{
    padding: 2px !important;
}
</style>
<section class="content-header">
    <h1>
        Event List
    </h1>
   <!--  <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
    </ol> -->
</section>   
<div class="content">
    <div class="row">
        @if (Session::has('flash_message'))  
            <div class="alert alert-success">
                <button data-dismiss="alert" class="close">
                    ×
                </button>
                <strong>Success!</strong> {{ Session::get('flash_message') }}
            </div>
        @endif 
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Event List 
                    @if(\Auth::user()->role == 'club admin' || \Auth::user()->role == 'event admin')
                        <b><a href="{{ url('/nightclub/viewCreateEvent') }}" data-toggle="tooltip" data-placement="top" data-original-title="Add New Event" class="pull-right"><!-- <span class="glyphicon glyphicon-plus"></span> -->Add New Event </a></b>
                    @endif
                </div>
                <div class="panel-body">

                    <form class="form-horizontal" style="margin-bottom:9px;" method="POST" enctype="multipart/form-data" action="{{URL::to('nightclub/searchEvent')}}">
                        <input type="text" style="width:180px; position: relative; margin-right:2px" class="form-control col-xs-4" placeholder="Event Name" name="title" value="{{{ Input::old('title', isset($searchCriteria) ? $searchCriteria['title'] : null)}}}">&nbsp;
                        <input type="hidden" name="nightclubId" value="{{{Auth::user()->nightclubId}}}">
                        <button class="btn btn-default" style="position: relative;" type="submit"><i class="glyphicon glyphicon-search"></i></button>
                    </form>

                    @if (count($events) > 0)

                    <table class="table table-striped table-bordered table-hover table-responsive" id="mytable">
                        <thead>
                            <tr>
                                <th>Title</th>
                                @if(\Auth::user()->role != 'club admin')
                                    <th>Club Name</th>
                                @endif
                                <th style="width: 20%;">Brief Info</th>
                                <th>Start</th>
                                <th>End</th>
                                <th style="width: 100px !important;" >Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($events as $event)
                            <tr>
                                <td>{{ ucwords($event->title) }}</td>
                                @if(\Auth::user()->role != 'club admin')
                                    <td>{{ ucwords($event->nightclubName) }}</td>
                                @endif
                                <td>{{ ucfirst($event->briefInfo) }}</td>
                                <td>{{ date('d-m-Y h:i A',strtotime($event->startDateTime)) }}</td>
                                <td>{{ date('d-m-Y h:i A',strtotime($event->endDateTime)) }}</td>
                                <td class="table-action-items tdButtonAlign"> 
                                    @if(\Auth::user()->role == "admin" || \Auth::user()->role == "club admin" || \Auth::user()->role == "event admin")
                                    <a href="{{ url('/nightclub/updateEvent/'.$event->id) }}"><span class="glyphicon glyphicon-pencil"></span></a>
                                    @endif
                                    <a href="{{url('/nightclub/viewEventDetails/'.$event->id)}}"><span class="glyphicon glyphicon-eye-open"></span> </a>
                                    @if(\Auth::user()->role != "admin")
                                    <a id="deact_{{$event->id}}" data-id="{{$event->id}}" href="#" data-toggle="modal" data-target="#myModalDeactivation"><span class="glyphicon glyphicon-minus-sign" style="color: #ff0000;"></span></a>
                                    @endif
                                    <a id="del_{{$event->id}}" data-id="{{$event->id}}" href="#" data-toggle="modal" data-target="#myModalDelete"><span class="glyphicon glyphicon-remove-sign" style="color: #ff0000;"></span></a></td>
                            </tr>
                            @endforeach
                        </tbody>

                    </table>
                    <?php echo $events->appends(Request::input())->render(); ?>
                    @else
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> No records found for club events.<br><br>
                    </div>
                    @endif
                </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="myModalDelete" class="modal fade in" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" onClick="delText()">&times;</button>
                <h4 class="modal-title">Confirm Delete</h4>
            </div>
            <div class="modal-body">
                <p> Are you sure you want to delete this Event? </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" onClick="delText()">No</button>
                <button type="button" class="btn btn-default" onClick="myfunc1()">Yes</button>
                <input type="hidden" value="" name="userId" id="dialogUserId">
            </div>
        </div>

    </div>
</div>
<div id="myModalDeactivation" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" onClick="delText()">&times;</button>
                <h4 class="modal-title">Confirm Deactivate</h4>
            </div>
            <div class="modal-body">
                <p> Are you sure you want to deactivate this Event? </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" onClick="delText()">No</button>
                <button type="button" class="btn btn-default" onClick="disableEvent()">Yes</button>
                <input type="hidden" value="" name="disableEventId" id="disableEventId">
            </div>
        </div>
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script>
    $('#myModalDelete').on('show.bs.modal', function (e) {
        //alert(e.relatedTarget.dataset.id);
        $('#dialogUserId').val(e.relatedTarget.dataset.id);
    });
    $('#myModalDeactivation').on('show.bs.modal', function (e) {
        $('#disableEventId').val(e.relatedTarget.dataset.id);
    });

    function delText() {
        $('input[type=TEXT], text').val('');
    }

    function myfunc1() {
        var id = document.getElementById('dialogUserId').value;
        window.location.href = "{{asset('index.php/nightclub/deleteEvent/')}}"+"/"+id;
//         if (data == '')
//        {
//          document.getElementById("modalLabel").innerHTML = "* please fill reason to disable";
//             return false;
//         }
//         $.ajax({
//             url: "{{URL::to('nightclub/deactivateEvent')}}",
//             type: 'POST',
//             data: {
//                 'id': id,
//                 'data': data
//             },
//             success: function (response) {
//                 $('#myModal').modal('hide');
//                 $('#deact_' + id).css({'display': 'none', 'visibility': 'hidden'});
//                 $('#act_' + id).css({'display': 'inline', 'visibility': 'visible'});
//
//                 $('input[type=TEXT], text').val('');
//             }
//         });
//
//         return false;
    }
    
    function disableEvent(){
        var id = document.getElementById('disableEventId').value;
        window.location.href = "{{url('nightclub/disableEvent/')}}"+"/"+id;
    }

    $(document).ready(function () {
        $('[data-toggle="tooltip"]').tooltip();
    });

    $(document).ready(function ()
    {
        //$("#mytable").tablesorter();
        var rowCount = $('#mytable tr').length;

    }
    );


</script>


@endsection
