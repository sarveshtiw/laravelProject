Hello!<br><br>

Your new password for the Bendr app is : {{ $password }}<br>
You can change this password from within the app in your account settings.<br><br>

Yours truly,<br>
The Bendr Team