<html>
    <head></head>
    <body>
	@if($key['role']=='club admin')

		Welcome to the Bendr team!<br/><br/>

		Follow the link provided below to log in and start creating your venue page.<br/>

		http://52.62.217.237//bendr/public/index.php<br/><br/>

		Please use below credentials to login:<br>
		Username : {{$key['userName']}}<br/>
		Password : {{$key['password']}}<br/><br/>

		Thank you for partnering with Bendr<br/>

	@elseif($key['role']=='event admin')

		Welcome to the Bendr team!<br/><br/>

		Follow the link provided below to log in and start creating your Event.<br/>

		http://52.62.217.237/bendr/public/index.php<br/><br/>


		Please use below credentials to login:<br>
		Username : {{$key['userName']}}<br/>
		Password : {{$key['password']}}<br/><br/>

		Thank you for partnering with Bendr<br/>

	@elseif($key['role']=='deal admin')

		Welcome to the Bendr team!<br/><br/>

		Follow the link provided below to log in and start creating your Deal.<br/>

		http://52.62.217.237/bendr/public/index.php<br/><br/>

		Please use below credentials to login:<br>
		Username : {{$key['userName']}}<br/>
		Password : {{$key['password']}}<br/><br/>

		Thank you for partnering with Bendr<br/>

	@endif
 	</body>
</html>




