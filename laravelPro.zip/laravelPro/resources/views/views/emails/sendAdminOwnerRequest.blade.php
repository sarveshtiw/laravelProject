<html>
    <head></head>
    <body>

		Dear Admin, <br/><br/>

		{{$key['message']}}<br/><br/>

		Thank you, <br/> <br/>
 	</body>
</html>




