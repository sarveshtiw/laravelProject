Hello!<br><br>

You have been assigned an deal from : {{$key['nightclubName']}}.<br><br>
Follow the link provided below to log in and start editing the Event.<br>

http://{{env('SERVER_URL')}}/bendr/public/index.php<br><br>

Yours truly,<br>
The Bendr Team