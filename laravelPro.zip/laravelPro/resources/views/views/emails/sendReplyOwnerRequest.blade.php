<html>
    <head></head>
    <body>
	@if($key['emailSendToRole']=='A')

		Dear Admin, <br/><br/>

		{{$key['message']}}<br/><br/>

		Thank you, <br/> <br/>

	@elseif($key['emailSendToRole']=='C')

		Dear Customer, <br/><br/>

		{{$key['message']}}<br/><br/>

		Thank you for your patience.<br/><br/>

		Sincerely, <br/>
		Bendr Team<br/>
	@endif
 	</body>
</html>




