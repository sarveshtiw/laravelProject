<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Bendr - @yield('title')</title>
        <link rel="shortcut icon" type="image/png" href="{{asset('ldpi.png')}}" />
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <!-- Bootstrap 3.3.2 -->
        <link href="{{ asset('/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
        <!-- FontAwesome 4.3.0 -->
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Ionicons 2.0.0 -->
        <link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />
        <!-- Theme style -->
        <link href="{{ asset('/dist/css/AdminLTE.min.css') }}" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="{{ asset('/plugins/datatables/dataTables.bootstrap.css') }}" type="text/css">
        <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.0.0/css/responsive.bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="{{ asset('/plugins/daterangepicker/daterangepicker-bs3.css') }}">
        <!-- AdminLTE Skins. Choose a skin from the css/skins
        folder instead of downloading all of them to reduce the load. -->
        <link href="{{ asset('/dist/css/skins/_all-skins.min.css') }}" rel="stylesheet" type="text/css" />
         <link rel="stylesheet" href="{{ asset('plugins/select2/select2.min.css') }}" rel="stylesheet" type="text/css">
        <!-- custom css -->
        <link href="{{ asset('css/developer.css') }}" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css" >
       
        

   
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
         <!-- jQuery 2.1.3 -->
        <script src="{{ asset('/plugins/jQuery/jQuery-2.1.4.min.js') }}"></script>
        <link rel="stylesheet" type="text/css" href="{{ asset('/plugins/datetimepicker/jquery.datetimepicker.min.css') }}"/>
        <script src="{{ asset('/plugins/datetimepicker/jquery.datetimepicker.full.min.js') }}"></script>
        <link href="{{ asset('/css/uploadfile.min.css') }}" rel="stylesheet" type="text/css" />
        <script src="{{ asset('/js/jquery.uploadfile.min.js') }}"></script>
        <script src="{{ asset('/js/moment.js') }}"></script>
        <script src="{{ asset('/js/moment-timezone.js') }}"></script>
        <script src="{{ asset('/js/jquery.mousewheel.js') }}"></script>

    </head>
    <body class="sidebar-mini skin-black-light">
        <div class="wrapper">
            <!-- <nav class="navbar navbar-default">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle Navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="#">Bendr</a>
                    </div>

                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav">
                            <li><a href="{{ url('/') }}">Home</a></li>

                        </ul>

                        <ul class="nav navbar-nav navbar-right">
                            @if (Auth::guest())
                            <li><a href="{{ url('/auth/login') }}">Login</a></li>
                            @elseif (Auth::user()->role == 'admin')
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Create<span class="caret"></span></a>
                                <ul class="dropdown-menu" role="CreateMenu">
                                    <li><a href="{{ url('nightclub/create') }}">New Club</a></li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Reports<span class="caret"></span></a>
                                <ul class="dropdown-menu" role="ReportsMenu">
                                    <li><a href="{{ url('nightclub/index') }}">Club Details</a></li>
                                    <li><a href="{{ url('nightclub/allUserDetails') }}">Club User Details</a></li>
                                    <li><a href="{{ url('nightclub/allEventDetails') }}">Club Event Details</a></li>
                                    <li><a href="{{ url('nightclub/allDealDetails') }}">Club Deal Details</a></li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">{{ Auth::user()->firstName }} <span class="caret"></span></a>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="{{ url('/nightclub/logout') }}">Logout</a></li>
                                    <li><a href="{{ url('/nightclub/changePassword') }}">Change Password</a></li>
                                </ul>
                            </li>
                            @elseif (Auth::user()->role == 'club admin')
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">New<span class="caret"></span></a>
                                <ul class="dropdown-menu" role="CreateMenu">
                                    <li><a href="{{ url('nightclub/viewCreateAdmin') }}">Create Event/Deal Admin</a></li>
                                    <li><a href="{{ url('nightclub/viewCreateEvent') }}">Create Event</a></li>
                                    <li><a href="{{ url('nightclub/createDeal') }}">Create Deal</a></li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Reports<span class="caret"></span></a>
                                <ul class="dropdown-menu" role="ReportsMenu">
                                    <li><a href="{{ url('nightclub/allUserDetails') }}">Club User Details</a></li>
                                    <li><a href="{{ url('nightclub/allEventDetails') }}">Club Event Details</a></li>
                                    <li><a href="{{ url('nightclub/allDealDetails') }}">Club Deal Details</a></li>
                                    <li><a href="{{ url('nightclub/nightclubCheckIn/viewCheckInHistory') }}">Entries Per Night</a></li>
                                    <li><a href="{{ url('nightclub/user/viewTotalVisits') }}">total visits</a></li>
                                    <li><a href="{{ url('nightclub/seeReports') }}">Reports</a></li>

                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">{{ Auth::user()->email }} <span class="caret"></span></a>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="{{ url('/nightclub/logout') }}">Logout</a></li>
                                    <li><a href="{{ url('/nightclub/changePassword') }}">Change Password</a></li>
                                    <li><a href="{{ url('nightclub/viewAssignedNightclub') }}">View Profile</a></li>

                                </ul>
                            </li>
                            @elseif (Auth::user()->role == 'deal admin')
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">New<span class="caret"></span></a>
                                <ul class="dropdown-menu" role="CreateMenu">
                                    <li><a href="{{ url('nightclub/createDeal') }}">Deal</a></li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Reports<span class="caret"></span></a>
                                <ul class="dropdown-menu" role="ReportsMenu">
                                    <li><a href="{{ url('nightclub/allDealDetails') }}">Club Deal Details</a></li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">{{ Auth::user()->email }} <span class="caret"></span></a>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="{{ url('/nightclub/logout') }}">Logout</a></li>
                                    <li><a href="{{ url('/nightclub/changePassword') }}">Change Password</a></li>
                                </ul>
                            </li>
                            @elseif (Auth::user()->role == 'event admin')
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">New<span class="caret"></span></a>
                                <ul class="dropdown-menu" role="CreateMenu">
                                    <li><a href="{{ url('nightclub/viewCreateEvent') }}">Event</a></li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Reports<span class="caret"></span></a>
                                <ul class="dropdown-menu" role="ReportsMenu">
                                    <li><a href="{{ url('nightclub/allEventDetails') }}">Club Event Details</a></li>
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">{{ Auth::user()->email }} <span class="caret"></span></a>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="{{ url('/nightclub/logout') }}">Logout</a></li>
                                    <li><a href="{{ url('/nightclub/changePassword') }}">Change Password</a></li>
                                </ul>
                            </li>
                            @else
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">{{ Auth::user()->firstName . ' ' . Auth::user()->surName }} <span class="caret"></span></a>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="{{ url('/nightclub/logout') }}">Logout</a></li>
                                </ul>
                            </li>
                            @endif
                        </ul>
                    </div>
                </div>
            </nav> -->
            @include('includes.header')
            @include('includes.sidebar')

            <div class="content-wrapper">
                @yield('content')
            </div>

            <!-- Scripts -->
            <footer class="main-footer">
                    <div class="pull-right hidden-xs">
                        <b>Version</b> 2.0
                    </div>
                    <strong>Copyright &copy; 2016 <a href="#">Bendr</a>.</strong> All rights reserved.
            </footer>
        </div><!-- ./wrapper -->

       
        <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
        <!-- Bootstrap 3.3.2 JS -->
        <script src="{{ asset('/bootstrap/js/bootstrap.min.js') }}" type="text/javascript"></script>
        <script src="{{ asset('/js/jquery-ui.js') }}"></script>
        <!-- Bootstrap WYSIHTML5 -->
        <script src="{{ asset('/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js') }}" type="text/javascript"></script>
        <!-- Slimscroll -->
        <script src="{{ asset('/plugins/slimScroll/jquery.slimscroll.min.js') }}" type="text/javascript"></script>
        <!-- FastClick -->
        <script src="{{ asset('/plugins/fastclick/fastclick.min.js') }}"></script>
        <script src="{{ asset('/plugins/datatables/jquery.dataTables.min.js') }}" type="text/javascript"></script>
        <script src="{{ asset('/plugins/datatables/dataTables.bootstrap.min.js') }}" type="text/javascript"></script>
        <script src="https://cdn.datatables.net/responsive/2.0.0/js/dataTables.responsive.min.js" type="text/javascript"></script>
        
        <script src="{{ asset('/plugins/daterangepicker/daterangepicker.js') }}"></script>
        <script>
            $(function () {
                $('#example2').DataTable({
                    "paging": false,
                    "lengthChange": false,
                    "searching": false,
                    "ordering": true,
                    "info": false,
                    "autoWidth": false,
                    "aaSorting":[],
                    'aoColumnDefs': [{
                        'bSortable': false,
                        'aTargets': ['nosort']
                    }]
                });
                $('#reservation').daterangepicker({
                    format: 'YYYY-MM-DD',
                    autoclose: true
                });
                $('.add-clear-x').click(function() {
                    $(this).siblings(".input-sm").val('');
                    //$("#loading").show();
                    $('#searchForm').submit();
                });
                
                //setTimeout('$(".alert").slideUp(500);', 3000);
            });
        </script>
        
        <!-- AdminLTE App -->
        <script src="{{ asset('/dist/js/app.min.js') }}" type="text/javascript"></script>
        <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
        
        <!-- AdminLTE for demo purposes -->
        <script src="{{ asset('/dist/js/demo.js') }}" type="text/javascript"></script>
        <script language="javascript">

            // Create cookie
            function createCookie(name, value, days) {
                var expires;
                if (days) {
                    var date = new Date();
                    date.setTime(date.getTime()+(days*24*60*60*1000));
                    expires = "; expires="+date.toGMTString();
                }
                else {
                    expires = "";
                }
                document.cookie = name+"="+value+expires+"; path=/"; 
            }
            function getCookie(cname) {
                var name = cname + "=";
                var ca = document.cookie.split(';');
                for(var i = 0; i < ca.length; i++) {
                    var c = ca[i];
                    while (c.charAt(0) == ' ') {
                        c = c.substring(1);
                    }
                    if (c.indexOf(name) == 0) {
                        return c.substring(name.length, c.length);
                    }
                }
                return "";
            }
            function checkCookie() {
                var clientTimeZone = getCookie("clientTimeZone");
                //console.log(clientTimeZone);
                if (clientTimeZone != "") {
                    console.log("Already get client Timezone");
                } else {
                    clientTimeZone = moment.tz.guess();
                    if (clientTimeZone != "" && clientTimeZone != null) {
                        createCookie("clientTimeZone", clientTimeZone, 365);
                    }
                }
            }
            checkCookie();
        </script>
    </body>
</html>
