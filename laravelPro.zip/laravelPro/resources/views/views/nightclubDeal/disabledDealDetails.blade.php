@extends('app')
@section('title','Deal List')
@section('content')

<style type="text/css">
.tdButtonAlign{
    padding: 2px !important;
}
</style>
<section class="content-header">
    <h1>
        Disabled Deal List
    </h1>
</section>   
<div class="content">
    <div class="row">
        @if (Session::has('flash_message'))  
            <div class="alert alert-success">
                <button data-dismiss="alert" class="close">
                    ×
                </button>
                <strong>Success!</strong> {{ Session::get('flash_message') }}
            </div>
        @endif 
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Deal List 
                    @if(\Auth::user()->role == 'club admin' || \Auth::user()->role == 'deal admin')
                        <b><a href="{{ url('/nightclub/createDeal') }}" data-toggle="tooltip" data-placement="top" data-original-title="Add New Deal" class="pull-right"><!-- <span class="glyphicon glyphicon-plus"></span> -->Add New Deal </a></b>
                    @endif
                </div>
                <div class="panel-body">

                    <form class="form-horizontal" style="margin-bottom:9px;" method="POST" enctype="multipart/form-data" action="{{URL::to('nightclub/searchDisabledDeal')}}">
                        <input type="text" class="form-control col-xs-4" style="width:180px; position: relative; margin-right:2px" placeholder="Disabled Deal Name" name="text" value="{{{ Input::old('text', isset($searchCriteria) ? $searchCriteria['text'] : null)}}}">&nbsp;
                        <input type="hidden" name="nightclubId" value="{{{Auth::user()->nightclubId}}}">
                        <button class="btn btn-default" style="position: relative;" type="submit"><i class="glyphicon glyphicon-search"></i></button>
                    </form>

                    @if (count($deals) > 0)

                    <table class="table table-striped table-bordered table-hover table-responsive" id="mytable">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <!-- <th>Club Name</th> -->
                                <th>Brief Info</th>
                                <th>Start</th>
                                <th>End</th>
                                <th style="width: 100px !important;" >Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($deals as $deal)
                            <tr>
                                <td>{{ ucwords($deal->title) }}</td>
                                <!-- <td>{{ ucwords($deal->nightclubName) }}</td> -->
                                <td>{{ ucfirst($deal->briefInfo) }}</td>
                                <td>{{ date('d-m-Y h:i A', strtotime($deal->startDateTime)) }}</td>
                                <td>{{ date('d-m-Y h:i A', strtotime($deal->endDateTime)) }}</td>
                                <td class="table-action-items tdButtonAlign"> 
                                    @if(\Auth::user()->role == "admin" || \Auth::user()->role == "club admin" || \Auth::user()->role == "deal admin")
                                        <a href="{{ url('/nightclub/updateDeal/'.$deal->id) }}"><span class="glyphicon glyphicon-pencil"></span></a>
                                    @endif
                                        <a href="{{url('/nightclub/viewDealDetails/'.$deal->id)}}"><span class="glyphicon glyphicon-eye-open"></span> </a>
                                        <a id="act_{{$deal->id}}" data-id="{{$deal->id}}" href="#" data-toggle="modal" data-target="#myModalActivation" ><span class="glyphicon glyphicon-ok-sign" style="color: #00ff00;"></span></a>
                            </tr>
                            @endforeach
                        </tbody>

                    </table>
                    <?php echo $deals->appends(Request::input())->render(); ?>
                    @else
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> No records found for disabled club deals.<br><br>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalActivation" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Confirm Activation</h4>
            </div>
            <div class="modal-body">
                <p>Do You Want To Activate This Deal?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-default" onClick="Activate()">Submit</button>
                <input type="hidden" value="" name="activateDealId" id="activateDealId">
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script>
    $('#myModalActivation').on('show.bs.modal', function (e) {
        //alert(e.relatedTarget.dataset.id);
        $('#activateDealId').val(e.relatedTarget.dataset.id);
    });

    function delText() {
        $('input[type=TEXT], text').val('');
    }

    function Activate() {
        var id = document.getElementById('activateDealId').value;
        window.location.href = "{{asset('index.php/nightclub/activateDeal/')}}"+"/"+id;
    }

    // function Activate(action) {

    //     var userId = document.getElementById('dialogActivateUserId').value;

    //     $.ajax({
    //         type: "post",
    //         url: "{{asset('nightclub/activateEvent')}}",
    //         data: {'userId': userId, 'type': action},
    //         cache: false,
    //         success: function (response) {
    //             $('#myModalActivation').modal('hide');
    //             $('#deact_' + userId).css({'display': 'inline', 'visibility': 'visible'});
    //             $('#act_' + userId).css({'display': 'none', 'visibility': 'hidden'});

    //         }
    //     });
    // }
    $(document).ready(function () {
        $('[data-toggle="tooltip"]').tooltip();
    });

    $(document).ready(function ()
    {
        //$("#myTable").tablesorter();
        var rowCount = $('#mytable tr').length;

    }
    );
</script>


@endsection
