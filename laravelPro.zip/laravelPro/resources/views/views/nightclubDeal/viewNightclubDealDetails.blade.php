@extends('app')
@section('title','Deal Details')
@section('content')

<section class="content-header">
    <h1>
        Deal Details
    </h1>
</section> 
<div class="content">
    <form class="form-horizontal" method="POST" enctype="multipart/form-data"
          accesskey=""   accept-charset="UTF-8">
        <input type="hidden" name="_token" value="{{ csrf_token() }}">
        <input type="hidden" name="id">
        <div class="col-sm-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <b>Deal Details</b>
                    <div style="float:right">
                        <b><a style="position: relative;" href="{{ url('nightclub/allDealDetails') }}">Back</a></b>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="form-group row">
                        <label class="control-label col-sm-4 leftalign">Image :</label>
                        <img class="leftalign" style="height:150px; width:200px; margin-left:15px; " src="{{$nightclubDealDetails->image}}"/>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-4 leftalign">Title : </label>
                        <label class="control-label col-sm-6 leftalign">{{ ucwords($nightclubDealDetails->title) }}</label>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-4 leftalign">Club Name : </label>
                        <label class="control-label col-sm-6 leftalign">{{ ucwords($nightclubDealDetails->nightclubName) }}</label>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-4 leftalign">Start :</label>
                        <label class="control-label col-sm-6 leftalign">{{date('d-m-Y h:i A',strtotime($nightclubDealDetails->startDateTime)) }}</label>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-4 leftalign">End:</label>
                        <label class="control-label col-sm-6 leftalign">{{date('d-m-Y h:i A',strtotime($nightclubDealDetails->endDateTime)) }}</label>
                    </div>


                    <div class="form-group row">
                        <label for="briefInfo" class="control-label col-sm-4 leftalign">Brief Info :</label>
                        <label class="control-label col-sm-6 leftalign">{{$nightclubDealDetails->briefInfo}}</label>
                    </div>


                </div>
            </div>
        </div>



        <!--<div class="form-group">
            <div class="col-xs-offset-2 col-xs-10">
                <div class="checkbox">
                    <label><input type="checkbox"> Remember me</label>
                </div>
            </div>
        </div> -->

    </form>
</div>
</div>
@endsection
