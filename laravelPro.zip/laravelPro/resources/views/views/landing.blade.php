<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>BENDR</title>
    <link href="{{ asset('web/theme/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('web/theme/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet" type="text/css">
    <link href="{{ asset('web/theme/magnific-popup/magnific-popup.css') }}" rel="stylesheet">
    <link href="{{ asset('web/css/creative.min.css') }}" rel="stylesheet">
    <link href="{{ asset('web/css/custom-orange.css') }}" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{ asset('web/css/owl.carousel.css') }}">
</head>

<body id="page-top">
    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <span class="navbar-toggle menuIcon collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> <i class="fa fa-bars" aria-hidden="true"></i>
                </span>
                <a class="navbar-brand page-scroll" href="#page-top">
                    <span class="logoImg">Bendr</span>
                </a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a class="page-scroll" href="#page-top">Home</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#about">About</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#services">Services</a>
                    </li>
                    <!-- <li>
                        <a class="page-scroll" href="#portfolio">Portfolio</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#blog">Blog</a>
                    </li> -->
                    <li>
                        <a class="page-scroll" href="#contact">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

    <header>
        <div class="header-content">
            <div class="header-content-inner">
                <img src="{{ asset('web/img/location-orange-icon.png') }}" class="img-Location" alt="Location"/>
                <h1 id="homeHeading">We were here</h1>
                <p class="hpara">Have you ever gone out with friends, only to hear the sound of crickets moments after jumping from the taxi? Or travelled to a new destination only to find out that you have absolutely no idea of where to go? so have we, countless times! We thought that there had to be a better way, so we created one! Never again will you have to ask countless strangers for hot spot tips or go out on a night not worth the cab fair. We’ve taken the guess work completely out of the equation!</p>
                 <p class="hpara viewPortfolio">View Portfolio</p>
                <a href="#portfolio" class="btn-xl page-scroll"><img src="{{ asset('web/img/downOrangeArrow-icon.png') }}" /></a>
            </div>
        </div>
    </header>

    <section class="aboutSection" id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 text-center">
                    <h2 class="section-heading">What we do?</h2> 
                    <p style="color:#fef">Bendr is a location based mobile app dedicated to bringing fun back into the mix. We provide users with Local venues, event and deal information. allow users to connect with others while out on the town and even invite those they may have forgotten to get in on the party! everything that makes a great night out possible is all here in your pocket!!</p>                  
                </div>
            </div>
        </div>
    </section>

    <section id="services" class="servicesBlockSection">
        <div class="container">
            <div class="row">
                <div class="servicesBlock">
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box">
                         <div class="Aboutsocialscount">
                                <span class="icon-fb"><img src="{{ asset('web/img/exercitation-icon.png') }}" /></span>
                            </div>
                        <h3 class="aboutHead">Filter</h3>
                        <p class="text-muted">Finding a venue thats right for you has never been easier with our filter option.
search for venues based on location, venue type, music genre, dress code or budget. anything your heart desires at the touch of a button!</p>
                        <!-- <button class="readMore">more</button> -->
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box">
                        <div class="Aboutsocialscount paddingStyle">
                                <span class="icon-fb"><img src="{{ asset('web/img/blanditis-icon.png') }}" /></span>
                            </div>
                        <h3 class="aboutHead">Chat</h3>
                        <p class="text-muted">Connecting with other night lifers is now made simple with our chat feature. simply find a user you’d like to connect with and send them a wink, if they send one back, your able to chat. Piece of cake! </p>
                        <!-- <button class="readMore">more</button> -->
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box">
                          <div class="Aboutsocialscount">
                                <span class="icon-fb"><img src="{{ asset('web/img/voluptatu-icon.png') }}" /></span>
                            </div>
                        <h3 class="aboutHead">Activity Feed</h3>
                        <p class="text-muted">The activity feed is where all the magic happens. this is where you’ll find all the happenings of your area. This includes venues, events and deals feed and so much more… This feed also allows users to follow venues, save events and deals, and see whose checked in to venues nearby!</p>
                        <!-- <button class="readMore">more</button> -->
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box">
                          <div class="Aboutsocialscount">
                                <span class="icon-fb"><img src="{{ asset('web/img/corrupti-icon.png') }}" /></span>
                            </div>
                        <h3 class="aboutHead">Profile</h3>
                        <p class="text-muted">Our profile system allows you to keep track of saved events and deals ( which means you’ll never miss an important event again), check-in at venues or even invite other friends out on the town. A must have feature for a great night out!</p>
                        <!-- <button class="readMore">more</button> -->
                     </div>
                   </div>
              </div>
            </div>
        </div>
       
    </section>

    <!-- <section class="no-padding" id="portfolio">
        <div class="container-fluid">
            <div class="row no-gutter popup-gallery">
               <div class="col-lg-8 col-lg-offset-2 text-center portfolioBLocksection">
                 <h2 class="headingBar">Look at the projects</h2>
                <div class="col-lg-4 col-sm-6 portfolioHoverBox">
                    <a href="{{ asset('web/img/portfolio/fullsize/1.jpg') }}" class="portfolio-box">
                        <img src="{{ asset('web/img/portfolio/thumbnails/1.jpg') }}" class="img-responsive" alt="">
                        <span class="srch-iconHover">
                            <i class="fa fa-search" aria-hidden="true"></i>
                        </span>
                        <span class="wishlist-iconHover">
                        <i class="fa fa-heart" aria-hidden="true"></i>
                        </span>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6 portfolioHoverBox">
                    <a href="{{ asset('web/img/portfolio/fullsize/2.jpg') }}" class="portfolio-box">
                        <img src="{{ asset('web/img/portfolio/thumbnails/2.jpg') }}" class="img-responsive" alt="">
                        <span class="srch-iconHover">
                            <i class="fa fa-search" aria-hidden="true"></i>
                        </span>
                         <span class="wishlist-iconHover">
                        <i class="fa fa-heart" aria-hidden="true"></i>
                        </span>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6 portfolioHoverBox">
                    <a href="{{ asset('web/img/portfolio/fullsize/3.jpg') }}" class="portfolio-box">
                        <img src="{{ asset('web/img/portfolio/thumbnails/3.jpg') }}" class="img-responsive" alt="">
                        <span class="srch-iconHover">
                            <i class="fa fa-search" aria-hidden="true"></i>
                        </span>
                         <span class="wishlist-iconHover">
                        <i class="fa fa-heart" aria-hidden="true"></i>
                        </span>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6 portfolioHoverBox">
                    <a href="{{ asset('web/img/portfolio/fullsize/4.jpg') }}" class="portfolio-box">
                        <img src="{{ asset('web/img/portfolio/thumbnails/4.jpg') }}" class="img-responsive" alt="">
                        <span class="srch-iconHover">
                            <i class="fa fa-search" aria-hidden="true"></i>
                        </span>
                         <span class="wishlist-iconHover">
                        <i class="fa fa-heart" aria-hidden="true"></i>
                        </span>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6 portfolioHoverBox">
                    <a href="{{ asset('web/img/portfolio/fullsize/5.jpg') }}" class="portfolio-box">
                        <img src="{{ asset('web/img/portfolio/thumbnails/5.jpg') }}" class="img-responsive" alt="">
                        <span class="srch-iconHover">
                            <i class="fa fa-search" aria-hidden="true"></i>
                        </span>
                         <span class="wishlist-iconHover">
                        <i class="fa fa-heart" aria-hidden="true"></i>
                        </span>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6 portfolioHoverBox">
                    <a href="{{ asset('web/img/portfolio/fullsize/6.jpg') }}" class="portfolio-box">
                        <img src="{{ asset('web/img/portfolio/thumbnails/6.jpg') }}" class="img-responsive" alt="">
                        <span class="srch-iconHover">
                            <i class="fa fa-search" aria-hidden="true"></i>
                        </span>
                         <span class="wishlist-iconHover">
                        <i class="fa fa-heart" aria-hidden="true"></i>
                        </span>
                    </a>
                </div>
            </div>
         </div>
        </div>
    </section> -->

   

    <!-- <section id="team" class="teamSection">
        <div class="container">
            <div class="row">
                 <div class="col-lg-8 col-lg-offset-2 text-center portfolioBLocksection">
                 <h2 class="section-heading">Meet our team</h2>
                </div>
                <div id="owl-demo" class="owl-carousel owl-theme">
                <div class="text-center teamBlockContainer item">
                    <div class="teamBlock">
                        <div class="teamMemberImg"><img src="{{ asset('web/img/team-member1.png') }}"></div>
                    </div>
                    <div class="teamMemberSocials"><div class="nameTeamMemeber">Lance Sorre</div>
                          <div class="titleTeamMemeber">CEO &amp; Founder</div>
                          <div class="storyTeamMemeber">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</div>
                            <span class="fbIcon"><i class="fa fa-facebook" aria-hidden="true"></i></span>
                            <span class="twitterIcon"><i class="fa fa-twitter" aria-hidden="true"></i></span>
                    </div>
                    
                </div>
                <div class="text-center teamBlockContainer item">
                    <div class="teamBlock">
                        <div class="teamMemberImg"><img src="{{ asset('web/img/team-member2.png') }}"></div>
                    </div>
                    <div class="teamMemberSocials"><div class="nameTeamMemeber">Erik Woldt</div>
                          <div class="titleTeamMemeber">Business Development</div>
                          <div class="storyTeamMemeber">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</div>
                            <span class="fbIcon"><i class="fa fa-facebook" aria-hidden="true"></i></span>
                            <span class="twitterIcon"><i class="fa fa-twitter" aria-hidden="true"></i></span>
                    </div>
                    
                </div>

                 <div class="text-center teamBlockContainer item">
                    <div class="teamBlock">
                        <div class="teamMemberImg"><img src="{{ asset('web/img/team-member3.png') }}"></div>
                    </div>
                    <div class="teamMemberSocials"><div class="nameTeamMemeber">Julianne Diers</div>
                          <div class="titleTeamMemeber">Editorial Manager</div>
                          <div class="storyTeamMemeber">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</div>
                            <span class="fbIcon"><i class="fa fa-facebook" aria-hidden="true"></i></span>
                            <span class="twitterIcon"><i class="fa fa-twitter" aria-hidden="true"></i></span>
                    </div>
                    
                </div>
                 <div class="text-center teamBlockContainer item">
                    <div class="teamBlock">
                        <div class="teamMemberImg"><img src="{{ asset('web/img/team-member4.png') }}"></div>
                    </div>
                    <div class="teamMemberSocials"><div class="nameTeamMemeber">Fernando Baro</div>
                          <div class="titleTeamMemeber">Production Assistant</div>
                          <div class="storyTeamMemeber">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</div>
                            <span class="fbIcon"><i class="fa fa-facebook" aria-hidden="true"></i></span>
                            <span class="twitterIcon"><i class="fa fa-twitter" aria-hidden="true"></i></span>
                    </div>
                    
                </div>

                 <div class="text-center teamBlockContainer item">
                    <div class="teamBlock">
                        <div class="teamMemberImg"><img src="{{ asset('web/img/team-member1.png') }}"></div>
                    </div>
                    <div class="teamMemberSocials"><div class="nameTeamMemeber">Lance Sorre</div>
                          <div class="titleTeamMemeber">CEO &amp; Founder</div>
                          <div class="storyTeamMemeber">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</div>
                            <span class="fbIcon"><i class="fa fa-facebook" aria-hidden="true"></i></span>
                            <span class="twitterIcon"><i class="fa fa-twitter" aria-hidden="true"></i></span>
                    </div>
                    
                </div>

                 <div class="text-center teamBlockContainer item">
                    <div class="teamBlock">
                        <div class="teamMemberImg"><img src="{{ asset('web/img/team-member2.png') }}"></div>
                    </div>
                    <div class="teamMemberSocials"><div class="nameTeamMemeber">Erik Woldt</div>
                          <div class="titleTeamMemeber">Business Development</div>
                          <div class="storyTeamMemeber">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</div>
                            <span class="fbIcon"><i class="fa fa-facebook" aria-hidden="true"></i></span>
                            <span class="twitterIcon"><i class="fa fa-twitter" aria-hidden="true"></i></span>
                    </div>
                    
                </div>

                 <div class="text-center teamBlockContainer item">
                    <div class="teamBlock">
                        <div class="teamMemberImg"><img src="{{ asset('web/img/team-member3.png') }}"></div>
                    </div>
                    <div class="teamMemberSocials"><div class="nameTeamMemeber">Julianne Diers</div>
                          <div class="titleTeamMemeber">Editorial Manager</div>
                          <div class="storyTeamMemeber">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</div>
                            <span class="fbIcon"><i class="fa fa-facebook" aria-hidden="true"></i></span>
                            <span class="twitterIcon"><i class="fa fa-twitter" aria-hidden="true"></i></span>
                    </div>
                    
                </div>

                 <div class="text-center teamBlockContainer item">
                    <div class="teamBlock">
                        <div class="teamMemberImg"><img src="{{ asset('web/img/team-member4.png') }}"></div>
                    </div>
                    <div class="teamMemberSocials"><div class="nameTeamMemeber">Fernando Baro</div>
                          <div class="titleTeamMemeber">Production Assistant</div>
                          <div class="storyTeamMemeber">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</div>
                            <span class="fbIcon"><i class="fa fa-facebook" aria-hidden="true"></i></span>
                            <span class="twitterIcon"><i class="fa fa-twitter" aria-hidden="true"></i></span>
                    </div>
                    
                </div>

                <div class="text-center teamBlockContainer item">
                    <div class="teamBlock">
                        <div class="teamMemberImg"><img src="{{ asset('web/img/team-member1.png') }}"></div>
                    </div>
                    <div class="teamMemberSocials"><div class="nameTeamMemeber">Lance Sorre</div>
                          <div class="titleTeamMemeber">CEO &amp; Founder</div>
                          <div class="storyTeamMemeber">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</div>
                            <span class="fbIcon"><i class="fa fa-facebook" aria-hidden="true"></i></span>
                            <span class="twitterIcon"><i class="fa fa-twitter" aria-hidden="true"></i></span>
                    </div>
                    
                </div>

                 <div class="text-center teamBlockContainer item">
                    <div class="teamBlock">
                        <div class="teamMemberImg"><img src="{{ asset('web/img/team-member2.png') }}"></div>
                    </div>
                    <div class="teamMemberSocials"><div class="nameTeamMemeber">Erik Woldt</div>
                          <div class="titleTeamMemeber">Business Development</div>
                          <div class="storyTeamMemeber">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</div>
                            <span class="fbIcon"><i class="fa fa-facebook" aria-hidden="true"></i></span>
                            <span class="twitterIcon"><i class="fa fa-twitter" aria-hidden="true"></i></span>
                    </div>
                    
                </div>

                                 <div class="text-center teamBlockContainer item">
                    <div class="teamBlock">
                        <div class="teamMemberImg"><img src="{{ asset('web/img/team-member3.png') }}"></div>
                    </div>
                    <div class="teamMemberSocials"><div class="nameTeamMemeber">Julianne Diers</div>
                          <div class="titleTeamMemeber">Editorial Manager</div>
                          <div class="storyTeamMemeber">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</div>
                            <span class="fbIcon"><i class="fa fa-facebook" aria-hidden="true"></i></span>
                            <span class="twitterIcon"><i class="fa fa-twitter" aria-hidden="true"></i></span>
                    </div>
                    
                </div>

                 <div class="text-center teamBlockContainer item">
                    <div class="teamBlock">
                        <div class="teamMemberImg"><img src="{{ asset('web/img/team-member4.png') }}"></div>
                    </div>
                    <div class="teamMemberSocials"><div class="nameTeamMemeber">Fernando Baro</div>
                          <div class="titleTeamMemeber">Production Assistant</div>
                          <div class="storyTeamMemeber">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</div>
                            <span class="fbIcon"><i class="fa fa-facebook" aria-hidden="true"></i></span>
                            <span class="twitterIcon"><i class="fa fa-twitter" aria-hidden="true"></i></span>
                    </div>
                    
                </div>
                

            </div>

        </div>
    </div>
    </section> -->

    <section id="blog" class="blogSection">
        <div class="container">
            <div class="row blogPositionRow">
                <div class="positionBlogSection">
                <div class="col-lg-8 col-lg-offset-2 text-center">
                    <h2 class="section-heading">Blog</h2>
                </div>
            <div class="blogContainer">
              <div class="col-lg-4 col-sm-6 portfolioHoverBox">
                    <a href="#" class="portfolio-box">
                        <img src="{{ asset('web/img/blog-img1.png') }}" class="blogImg-responsive" alt="">
                    </a>
                    <span class="blogHead">Lorem ipsum dolor sit amet, conseetur adipisicing elit.
</span>
                    <span class="blogPara">Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</span>
                    <button class="readMore">more</button>
                </div>
               <div class="col-lg-4 col-sm-6 portfolioHoverBox">
                    <a href="#" class="portfolio-box">
                        <img src="{{ asset('web/img/blog-img2.png') }}" class="blogImg-responsive" alt="">
                    </a>
                    <span class="blogHead">Lorem ipsum dolor sit amet, conseetur adipisicing elit.
</span>
<span class="blogPara">Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</span>
<button class="readMore">more</button>
                </div>
                <div class="col-lg-4 col-sm-6 portfolioHoverBox">
                    <a href="#" class="portfolio-box">
                        <img src="{{ asset('web/img/blog-img3.png') }}" class="blogImg-responsive" alt="">
                    </a>
                    <span class="blogHead">Lorem ipsum dolor sit amet, conseetur adipisicing elit.
</span>
<span class="blogPara">Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</span>
<button class="readMore">more</button>
                </div>
            </div>
            </div>
        </div>
    </div>
    </section>

    <section id="follow" class="followSection">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 text-center">
                    <h2 class="headingBar">Follow us</h2>
                </div>

                <div class="servicesBlock">
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box">
                         <div class="followSocialscount">
                                <span class="icon-fb"><i class="fa fa-facebook" aria-hidden="true"></i>
</span>
                            </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box">
                        <div class="followSocialscount paddingStyle">
                                <span class="icon-fb"><i class="fa fa-twitter" aria-hidden="true"></i>
</span>
                            </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box">
                          <div class="followSocialscount">
                                <span class="icon-dribbble"><i class="fa fa-dribbble" aria-hidden="true"></i>
</span>
                            </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box">
                          <div class="followSocialscount">
                                <span class="icon-instagram"><i class="fa fa-instagram" aria-hidden="true"></i>
</span>
                            </div>
                     </div>
                   </div>
              </div>
            </div>
        </div>
       
    </section>
            </div>
        </div>
    </section>

        <section id="contact" class="contactSection">
        <div class="container">
            <div class="row blogPositionRow">
                <div class="col-lg-8 col-lg-offset-2 text-center portfolioBLocksection">
                    <h2 class="section-heading contactHead">Contact Us</h2>
            <form class="form-inline">
                  <div class="form-group">
                    <input type="text" class="form-control" id="exampleInputName2" placeholder="Your Email">
                  </div>
                  <div class="form-group">
                        <textarea class="form-control" id="exampleTextarea" rows="3" placeholder="Your Message"></textarea>
                  </div>
              </form>


              <div class="addressSection">
                <div class="msgImg"><i class="fa fa-envelope-o" aria-hidden="true"></i></div>   
                <div class="addressText1">- <br />
                    - </div>
                    <div class="addressText2">EMAIL: bendr.app@gmail.com <br />
                   PHONE: xxx.xxx.xxxx</div>

                </div>
                
            </div>
        </div>
    </div>
    </section>

    <section class="mapSection">
         <div class="container-fluid">
            <div class="row mapRow">
                <div class="mapBlock">
                    <div style="text-decoration:none; overflow:hidden; height:200px; width:100%; max-width:100%;"><div id="gmap-display" style="height:100%; width:100%;max-width:100%;"><iframe style="height:100%;width:100%;border:0;" frameborder="0" src="https://www.google.com/maps/embed/v1/place?q=New+York+University,+New+York,+NY,+United+States&key=AIzaSyAN0om9mFmy1QN6Wf54tXAowK4eT0ZUPrU"></iframe></div><a class="embedded-map-html" href="http://www.dog-checks.com" id="make-map-data">dog checks</a><style>#gmap-display .text-marker{max-width:none!important;background:none!important;}img{max-width:none}</style></div><script src="https://www.dog-checks.com/google-maps-authorization.js?id=0fde6fed-077a-f7c2-f87d-115e9c002eb2&c=embedded-map-html&u=1471033175" defer="defer" async="async"></script>
            </div>
        </div>
    </div>
    </section>

     <div class="backToTop"> 
    <span class="backTopArrow">
    <a href="#page-top" class="btn-xl page-scroll"><img src="{{ asset('web/img/downOrangeArrow-icon.png') }}"></a>
    </span>

        <div class="footer">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a class="page-scroll" href="#page-top">Home</a>
                </li>
                <li>
                    <a class="page-scroll" href="#about">About</a>
                </li>
                <li>
                    <a class="page-scroll" href="#services">Services</a>
                </li>
                <!-- <li>
                    <a class="page-scroll" href="#portfolio">Portfolio</a>
                </li>
                <li>
                    <a class="page-scroll" href="#blog">Blog</a>
                </li> -->
                <li>
                    <a class="page-scroll" href="#contact">Contact</a>
                </li>
                <li>
                    <a class="page-scroll" href="{{ url('index.php/term/index') }}" target='_BLANK'>Terms & Conditions</a>
                </li>
                <li>
                    <a class="page-scroll" href="{{ url('index.php/term/privacy') }}" target='_BLANK'>Privacy Policy</a>
                </li>
            </ul>
        </div>
    </div>


    <!-- jQuery -->
    <script src="{{ asset('web/theme/jquery/jquery.min.js') }}"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="{{ asset('web/theme/bootstrap/js/bootstrap.min.js') }}"></script>

    <!-- Plugin JavaScript -->
    <script src="{{ asset('web/theme/scrollreveal/scrollreveal.min.js') }}"></script>
    <script src="{{ asset('web/theme/magnific-popup/jquery.magnific-popup.min.js') }}"></script>

    <!-- Theme JavaScript -->
    <script src="{{ asset('web/js/creative.min.js') }}"></script>
    <script src="{{ asset('web/js/owl.carousel.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('web/js/owl.carousel.js') }}"></script>
    <script type="text/javascript">
           $(document).ready(function() {
 
  var owl = $("#owl-demo");
 
  owl.owlCarousel({
     items:4,
      itemsCustom : [
        [0, 2],
        [479, 2],
        [991, 3],
        [1199, 3],
      ],
      navigation : true
 
  });
 
});

    </script>



</body>

</html>
