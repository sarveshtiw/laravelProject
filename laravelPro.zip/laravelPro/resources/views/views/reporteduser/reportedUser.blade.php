@extends('app')
@section('title','Reported User List')
@section('content')

<section class="content-header">
    <h1>
        Reported User List
    </h1>
</section>   
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Reported User List
                </div>
                <div class="panel-body">
                    <form class="form-inline" style="margin-bottom:9px;" method="POST" enctype="multipart/form-data" action="{{URL::to('user/searchReportedUsers')}}">
                        <input type="text" class="form-control col-xs-4" style="width:180px; position: relative; margin-right:2px" placeholder="User Name" name="userName" value="{{{ Input::old('userName', isset($searchCriteria) ? $searchCriteria['userName'] : null)}}}">&nbsp;
                        <button class="btn btn-default" style="position: relative; margin-right:2px" type="submit"><i class="glyphicon glyphicon-search"></i></button>
                    </form>
                    @if (count($users) > 0)
                    <table class="table table-striped table-bordered table-hover table-responsive" id="mytable">
                        <thead>
                            <tr>
                                <th>Reported User</th>
                                <th>Reported By</th>
                                <th>Reported Date</th>
                                <th>Reported Reason</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($users as $user)
                            <tr>
                                <td>{{ ucwords($user->reportedByUserFirstName)}} {{ ucwords($user->reportedByUserSurName) }}</td>
                                <td>{{ ucwords($user->reportedUserFirstName)}} {{ ucwords($user->reportedUserSurName) }}</td>
                                <td>{{ date('d-m-Y h:i A', strtotime($user->createDate)) }}</td>
                                <td>{{ ucwords($user->reportReason) }}</td>
                            </tr>
                            @endforeach
                        </tbody>

                    </table>
                    <?php echo $users->appends(Request::input())->render(); ?>
                    @else
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> No records found for reported users.<br><br>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
