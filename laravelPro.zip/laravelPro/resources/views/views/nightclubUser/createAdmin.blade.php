@extends('app')
@section('title','Add Admin')
@section('content')

<section class="content-header">
    <h1>
        Add Admin
    </h1>
   <!--  <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
    </ol> -->
</section> 
<div class="content">
    <div class="row">
        <!-- <div class="col-sm-3">
            <ul class="nav nav-pills nav-stacked">
                <li class="active"><a href="#">Actions</a></li>
                <li><a href="{{ url('nightclub/allUserDetails') }}">View Users</a></li>
            </ul>
        </div> -->
        <div class="col-sm-12">
            <div class="panel panel-default">
                <div class="panel-heading">Add Admin</div>
                <div class="panel-body">
                    @if (count($errors) > 0)
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> There were some problems with your input.<br><br>
                        <ul>
                            @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                    @endif
                    @if (Session::has('flash_message'))  
                    <div class="alert alert-success">
                        <button data-dismiss="alert" class="close">
                            ×
                        </button>
                        <strong>Success!</strong> {{ Session::get('flash_message') }}
                    </div>
                    @endif 

                    <form class="form-horizontal" role="form" method="POST" action="{{ url('nightclub/createAdmin')}}">
                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        <input type="hidden" name="nightclubId" value="{{ Auth::user()->nightclubId }}">
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="email">E-Mail Address <span class="required_span">*</span></label>
                            <div class="col-md-6">
                                <input type="email" class="form-control" name="email">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="userName">Name <span class="required_span">*</span></label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="userName">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="role" class="col-md-4 control-label">Role <span class="required_span">*</span></label>
                            <div class="col-md-6">
                                <select name="role" class="form-control">
                                    <option value=" "> </option>
                                    <option value="event admin">Event Admin</option>
                                    <option value="deal admin">Deal Admin</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">Save</button>
                                <a class="btn btn-primary" style="position: relative;" href="{{ url('nightclub/viewAdminUserDetails') }}">Cancel</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>



@endsection
