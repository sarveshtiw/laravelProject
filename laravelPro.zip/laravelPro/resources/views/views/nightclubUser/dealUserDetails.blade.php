@extends('app')
@section('title','Deal Admin Details')
@section('content')

<section class="content-header">
    <h1>
            Deal Admin Details
    </h1>
</section>   
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Deal Admin Details
                </div>
                <div class="panel-body">
                    <form class="form-horizontal" style="margin-bottom:9px;" method="POST" enctype="multipart/form-data" action="{{URL::to('nightclub/searchDealAdminDetails')}}">
                        <input type="text" style="width: 180px; position: relative; margin-right:5px" class="form-control col-xs-4" placeholder="Name" name="name" value="{{{ Input::old('name', isset($searchCriteria) ? $searchCriteria['name'] : null)}}}">&nbsp;
                        <input type="hidden" name="nightclubId" value="{{{Auth::user()->nightclubId}}}">
                        <button class="btn btn-default" style="position: relative;" type="submit"><i class="glyphicon glyphicon-search"></i></button>
                    </form>

                    @if (count($users) > 0)
                    <table class="table table-striped table-bordered table-hover table-responsive" id="mytable">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email Address</th>
                                <th>Deals</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($users as $user)
                                <tr>
                                    <td>{{ ucwords($user->firstName) }}</td>
                                    <td>{{ $user->email }}</td>
                                    <td>
                                        @foreach($user->userDeals as $userDeals)
                                            {{ ucwords($userDeals->title) }} <br>
                                        @endforeach
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>

                    </table>
                    <?php echo $users->appends(Request::input())->render(); ?>
                    @else
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> No records found for deal admins.<br><br>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModal" class="modal fade in" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" onClick="delText()">&times;</button>
                <h4 class="modal-title">Please Enter Reason To Disable</h4>
            </div>
            <div class="modal-body">
                <label id="modalLabel" style="color: red;"></label>
                <input type="text" class="form-control" id="disableReason" name="disableReason" placeholder="Reason to Disable">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" onClick="delText()">Close</button>
                <button type="button" class="btn btn-default" onClick="myfunc1()">Submit</button>
                <input type="hidden" value="" name="userId" id="dialogUserId">
            </div>
        </div>

    </div>
</div>
<div id="myModalActivation" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Confirm Activation</h4>
            </div>
            <div class="modal-body">
                <p>Do You Want To Activate This User</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-default" onClick="Activate('activate')">Submit</button>
                <input type="hidden" value="" name="userId" id="dialogActivateUserId">
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script>
    $('#myModal').on('show.bs.modal', function (e) {
        //alert(e.relatedTarget.dataset.id);
        $('#dialogUserId').val(e.relatedTarget.dataset.id);
    });
    $('#myModalActivation').on('show.bs.modal', function (e) {
        //alert(e.relatedTarget.dataset.id);
        $('#dialogActivateUserId').val(e.relatedTarget.dataset.id);
    });

    function delText() {
        $('input[type=TEXT], text').val('');
    }

    function myfunc1() {
        var data = document.getElementById('disableReason').value;
        var id = document.getElementById('dialogUserId').value;
        if (data == '')
        {
            document.getElementById("modalLabel").innerHTML = "* please fill reason to disable";
            return false;
        }
        $.ajax({
            url: "{{asset('nightclub/deactivateUser')}}",
            type: 'POST',
            data: {
                'id': id,
                'data': data
            },
            success: function (response) {
                $('#myModal').modal('hide');
                $('#deact_' + id).css({'display': 'none', 'visibility': 'hidden'});
                $('#act_' + id).css({'display': 'inline', 'visibility': 'visible'});

                $('input[type=TEXT], text').val('');
            }
        });

        return false;
    }

    function Activate(action) {

        var userId = document.getElementById('dialogActivateUserId').value;

        $.ajax({
            type: "post",
            url: "{{asset('nightclub/activateUser')}}",
            data: {'userId': userId, 'type': action},
            cache: false,
            success: function (response) {
                $('#myModalActivation').modal('hide');
                $('#deact_' + userId).css({'display': 'inline', 'visibility': 'visible'});
                $('#act_' + userId).css({'display': 'none', 'visibility': 'hidden'});

            }
        });
    }
    $(document).ready(function ()
    {
        //$("#mytable").tablesorter();
    }
    );

</script>


@endsection
