@extends('app')
@section('title','User List')
@section('content')

<section class="content-header">
    <h1>
        User List
    </h1>
</section>   
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    User List
                </div>
                <div class="panel-body">
                    <form class="form-horizontal" style="margin-bottom:9px;" method="POST" enctype="multipart/form-data" action="{{URL::to('nightclub/searchUser')}}">
                        <input type="text" style="width: 180px; position: relative; margin-right:5px" class="form-control col-xs-4" placeholder="Name" name="name" value="{{{ Input::old('name', isset($searchCriteria) ? $searchCriteria['name'] : null)}}}">&nbsp;
                        <input type="hidden" name="nightclubId" value="{{{Auth::user()->nightclubId}}}">
                        <button class="btn btn-default" style="position: relative;" type="submit"><i class="glyphicon glyphicon-search"></i></button>
                    </form>

                    @if (count($users) > 0)
                    <table class="table table-striped table-bordered table-hover table-responsive" id="mytable">
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Email Address</th>
                                <th>Location</th>
                                <th>Gender</th>
                                <th>Age</th>
                                <th style="width: 100px !important;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($users as $user)
                            
                                <tr>
                                    <td><img style="height:45px; width:45px" src="{{ (!empty($user->image) && file_exists(public_path().config('constants.userImage').$user->image)) ? asset('/images/user/'.$user->image) : asset(config('constants.userDefaultImage'))}}" class="img-circle" alt="User Image" /></td>
                                    <td>{{ ucwords($user->firstName) }}</td>
                                    <td>{{ $user->email }}</td>
                                    <td>{{ ucwords($user->location) }}</td>
                                    <td>{{ ucwords($user->gender) }}</td>
                                    <td>{{ ucwords($user->age) }}</td>
                                    <td class="table-action-items"> 
                                        <a id="act_{{$user->id}}" data-id="{{$user->id}}" href="#" data-toggle="modal" data-target="#myModalActivation" style="{{ ($user->isDisabled) ? 'visibility:visible; display:inline;' : 'visibility:hidden; display:none;'}}"><span class="glyphicon glyphicon-ok-sign" style="color: #00ff00;"></span></a>
                                        <a id="deact_{{$user->id}}" data-id="{{$user->id}}" href="#" data-toggle="modal" style="{{ ($user->isDisabled) ? 'visibility:hidden; display:none;' : 'visibility:visible; display:inline;'}}" data-target="#myModal"><span class="glyphicon glyphicon-remove-sign" style="color: #ff0000;"></span></a></td> 
                                </tr>
                            @endforeach
                        </tbody>

                    </table>
                    <?php echo $users->appends(Request::input())->render(); ?>
                    @else
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> No records found for nightclubs.<br><br>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModal" class="modal fade in" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" onClick="delText()">&times;</button>
                <h4 class="modal-title">Confirm Delete</h4>
            </div>
            <div class="modal-body">
                <p> Are you sure you want to delete this user account? This action will delete all user information including profile, photos, status, followed clubs, friends and chats.</p>
                <input type="hidden" class="form-control" id="disableReason" name="disableReason" placeholder="Reason to Disable">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" onClick="delText()">No</button>
                <button type="button" class="btn btn-default" onClick="myfunc1()">Yes</button>
                <input type="hidden" value="" name="userId" id="dialogUserId">
            </div>
        </div>

    </div>
</div>
<div id="myModalActivation" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Confirm Activation</h4>
            </div>
            <div class="modal-body">
                <p>Do You Want To Activate This User</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-default" onClick="Activate('activate')">Submit</button>
                <input type="hidden" value="" name="userId" id="dialogActivateUserId">
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script>
    $('#myModal').on('show.bs.modal', function (e) {
        //alert(e.relatedTarget.dataset.id);
        $('#dialogUserId').val(e.relatedTarget.dataset.id);
    });
    $('#myModalActivation').on('show.bs.modal', function (e) {
        //alert(e.relatedTarget.dataset.id);
        $('#dialogActivateUserId').val(e.relatedTarget.dataset.id);
    });

    function delText() {
        $('input[type=TEXT], text').val('');
    }

    function myfunc1() {
        //var data = document.getElementById('disableReason').value;
        var id = document.getElementById('dialogUserId').value;
        window.location.href = "{{asset('index.php/nightclub/deleteAppUser/')}}"+"/"+id;
        // if (data == '')
        // {
        //     document.getElementById("modalLabel").innerHTML = "* please fill reason to disable";
        //     return false;
        // }
        // $.ajax({
        //     url: "{{asset('index.php/nightclub/deactivateUser')}}",
        //     type: 'POST',
        //     data: {
        //         'id': id,
        //         'data': data
        //     },
        //     success: function (response) {
        //         $('#myModal').modal('hide');
        //         $('#deact_' + id).css({'display': 'none', 'visibility': 'hidden'});
        //         $('#act_' + id).css({'display': 'inline', 'visibility': 'visible'});

        //         $('input[type=TEXT], text').val('');
        //     }
        // });

        //return false;
    }

    // function Activate(action) {

    //     var userId = document.getElementById('dialogActivateUserId').value;

    //     $.ajax({
    //         type: "post",
    //         url: "{{asset('index.php/nightclub/activateUser')}}",
    //         data: {'userId': userId, 'type': action},
    //         cache: false,
    //         success: function (response) {
    //             $('#myModalActivation').modal('hide');
    //             $('#deact_' + userId).css({'display': 'inline', 'visibility': 'visible'});
    //             $('#act_' + userId).css({'display': 'none', 'visibility': 'hidden'});

    //         }
    //     });
    // }
</script>
@endsection
