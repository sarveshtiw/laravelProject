@extends('app')
@section('title','Owner Request Details')
@section('content')

<section class="content-header">
    <h1>
        @if(\Auth::user()->role == 'admin')
            Owner Request Details
        @else (\Auth::user()->role == 'club admin')
            Request Details
        @endif

    </h1>
</section>   
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    @if(\Auth::user()->role == 'admin')
                        Owner Request Details
                    @else (\Auth::user()->role == 'club admin')
                        Request Details
                    @endif
                     -  {{ $ownerRequestDetails[0]->title }}
                </div>
                <div class="panel-body">
                    @if (Session::has('flash_message'))  
                    <div class="alert alert-success">
                        <button data-dismiss="alert" class="close">
                            ×
                        </button>
                        <strong>Success!</strong> {{ Session::get('flash_message') }}
                    </div>
                  @endif
                    <!-- Messeging View/ Comment Sction -->
                    @foreach($ownerRequestDetails as $ownerRequestDetail)
                    <div class="media" style="border-bottom: 1px solid #ddd;padding-bottom: 10px;">
                      <div class="media-left">
                        <a href="#">
                          @if($ownerRequestDetail->messageBy=='C') 
                            <img class="media-object" width="64" height="64" src="{{{isset($ownerRequestDetail->logo) ? asset('images/nightclub/logo/'.$ownerRequestDetail->logo): asset(config('constants.nightclubDefaultImage'))}}}" alt="...">
                          @elseif($ownerRequestDetail->messageBy=='A') 
                            <img class="media-object" width="64" height="64" src="{{{isset(\Auth::user()->image) ? asset('images/user/'.\Auth::user()->image): asset(config('constants.userDefaultImage'))}}}" alt="...">
                          @endif
                        </a>
                      </div>
                      <div class="media-body">
                        <h4 class="media-heading">
                          @if($ownerRequestDetail->messageBy=='C') 
                            {{$ownerRequestDetail->nightclubName}}
                          @elseif($ownerRequestDetail->messageBy=='A') 
                            {{\Auth::user()->firstName}} {{\Auth::user()->surName}}
                          @endif
                        </h4>
                        {{$ownerRequestDetail->messageDetails}}
                      </div>
                    </div>
                    @endforeach
                    <div class="row">
                      <form method="POST" enctype="multipart/form-data" action="{{URL::to('ownerRequest/conversation')}}"
                            accesskey=""   accept-charset="UTF-8">
                          <input type="hidden" name="_token" value="{{ csrf_token() }}">
                          <input type="hidden" name="requestId" value="{{ $requestId }}">
                          <label class="control-label col-sm-12 leftalign">
                          <div class="col-sm-5">
                              <div class="form-group row">
                                  <label class="leftalign">Leave a Reply</left>
                                  <div>
                                      ​<textarea id="message" name="message" rows="5" cols="52" class="form-control" placeholder="Message">{{{Input::old('message',isset($requestDetails) ? $requestDetails->message : null)}}}</textarea>
                                  </div>
                              </div>

                              <div class="form-group">
                                  <div class="col-sm-12 row">
                                      <button type="submit" class="btn btn-primary">Send</button>
                                      <a class="btn btn-primary" style="position: relative;" href="{{ url('ownerRequest/view') }}">Cancel</a>
                                  </div>
                              </div>
                          </div>
                        </label>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
