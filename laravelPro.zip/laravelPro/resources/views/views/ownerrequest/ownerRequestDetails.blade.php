@extends('app')
@section('title','Owner Request List')
@section('content')

<section class="content-header">
    <h1>
        @if(\Auth::user()->role == 'admin')
            Owner Request List
        @else (\Auth::user()->role == 'club admin')
            Request List
        @endif

    </h1>
</section>   
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    @if(\Auth::user()->role == 'admin')
                        Owner Request List
                    @else (\Auth::user()->role == 'club admin')
                        Request List
                    @endif
                    @if(\Auth::user()->role == 'club admin')
                        <a href="{{ url('/club/request') }}" data-toggle="tooltip" data-placement="top" data-original-title="Add New Deal" class="pull-right">Add New Request</a>
                    @endif
                </div>
                <div class="panel-body">

                    @if (count($ownerRequestList) > 0)
                    <table class="table table-striped table-bordered table-hover table-responsive" id="mytable">
                        <thead>
                            <tr>
                                <th>Club Name</th>
                                <th>Phone No.</th>
                                <th>Message Subject</th>
                                <th>Requested Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($ownerRequestList as $ownerRequest)
                            <tr>
                                <td><a href="{{url('/ownerRequest/ownerRequestDetails/'.$ownerRequest->id)}}">{{ ucwords($ownerRequest->nightclubName) }}</a></td>
                                <!-- <td>{{ ucwords($ownerRequest->nightclubName) }}</td> -->
                                <td>{{ $ownerRequest->phone_no }}</td>
                                <td>{{ ucwords($ownerRequest->title) }}</td>
                                <td>{{ date('d-m-Y h:i A', strtotime($ownerRequest->createDate)) }}</td>
                            </tr>
                            @endforeach
                        </tbody>

                    </table>
                    <?php echo $ownerRequestList->appends(Request::input())->render(); ?>
                    @else
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> No records found for owner request.<br><br>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
