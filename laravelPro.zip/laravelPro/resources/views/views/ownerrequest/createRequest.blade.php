@extends('app')
@section('title','Create Request')
@section('content')

<section class="content-header">
    <h1>
        Create Request
    </h1>
</section>  
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <form method="POST" enctype="multipart/form-data" action="{{URL::to('club/request')}}"
                  accesskey=""   accept-charset="UTF-8">
                <input type="hidden" name="_token" value="{{ csrf_token() }}">

                @if (Session::has('flash_message'))  
                <div class="alert alert-success">
                    <button data-dismiss="alert" class="close">
                        ×
                    </button>
                    <strong>Success!</strong> {{ Session::get('flash_message') }}
                </div>
                @endif 
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <b>Create Request</b>
                        </div>
                        <div class="panel-body">
                            <?php if ($errors->count() > 0) { ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php foreach ($errors->all() as $messages) { ?>
                                            <li> <?php echo $messages ?> </li>
                                        <?php } ?>
                                    </ul>
                                </div>
                            <?php } ?>
                            <div class="col-sm-5">
                                <div class="form-group row">
                                    <label for="name" class="control-label">Title <span class="required_span">*</span></label>
                                    <div>
                                        <input type="text" class="form-control" id="title" name="title" placeholder="Title"
                                               value="{{{ Input::old('title', isset($requestDetails) ? $requestDetails->title : null)}}}">
                                    </div>

                                </div>

                                <div class="form-group row">
                                    <label for="name" class="control-label">Phone No.</label>
                                    <div>
                                        <input type="text" class="form-control" id="phone_no" name="phone_no" placeholder="Phone No"
                                               value="{{{ Input::old('phone_no', isset($requestDetails) ? $requestDetails->phone_no : null)}}}" onkeypress="return isNumberKey(event);" maxlength="15">
                                    </div>

                                </div>

                                <div class="form-group row">
                                    <label for="message" class="control-label">Message <span class="required_span">*</span></label>
                                    <div>
                                        ​<textarea id="message" name="message" rows="5" cols="52" class="form-control" placeholder="Message">{{{Input::old('message',isset($requestDetails) ? $requestDetails->message : null)}}}</textarea>
                                    </div>
                                </div>
                                

                                <div class="form-group">
                                    <div class="col-sm-12 row">
                                        <button type="submit" class="btn btn-primary">Send</button>
                                        <a class="btn btn-primary" style="position: relative;" href="{{ url('ownerRequest/view') }}">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
@endsection
<script type="text/javascript">
    function isNumberKey(evt){
        var charCode = (evt.which) ? evt.which : evt.keyCode
        return !(charCode > 31 && (charCode < 48 || charCode > 57));
    }
</script>




