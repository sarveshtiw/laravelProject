@extends('app')
@section('title', 'Dashboard')
@section('content')
        @if (Session::has('flash_message'))  
        <div class="alert alert-success">
            <button data-dismiss="alert" class="close">
                ×
            </button>
            <strong>Success!</strong> {{ Session::get('flash_message') }}
        </div>
    @endif 

 <!-- Main content -->
 <section class="content-header">
    <h1>
        Dashboard
    </h1>
    <!-- <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
    </ol> -->
</section>   
<div class="content">
     <div class="row">
        @if(\Auth::user()->role == config('constants.admin'))
            <div class="col-lg-12">
                <div class="box box-warning">
                    <div class="box-header with-border">
                        <h4>Welcome to Bendr Panel!  </h4>
                        <div class="box-tools pull-right">
                            <button class="btn btn-box-tool" data-widget="collapse">
                                <i class="fa fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="box-body">
                        <div class="my_dashboard_text">
                            <p style="text-align:justify">Portal makes management even easier. Simply log in to your online account at any 
                                time for up-to-date information</p>
                            <p style="text-align:justify">&nbsp;&nbsp;&nbsp;<strong>&nbsp; App Admin will use to:</strong></p>
                            <ol>
                                <li style="text-align:justify">&nbsp;Manage <strong>Users</strong>.</li>
                                <li style="text-align:justify">&nbsp;View <strong>Clubs</strong>.</li>
                                <li style="text-align:justify">&nbsp;View <strong>Events</strong>.</li>
                                <li style="text-align:justify">&nbsp;View <strong>Deals</strong>.</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="box box-widget widget-user-2">
                  <div class="widget-user-header bg-aqua-active" style="padding:1px">
                  <h3 class="widget-user-username" style="margin-left:6px">Overview</h3>
                </div>
                <div class="box-footer no-padding">
                  <ul class="nav nav-stacked">
                    <li> <a href="{{ url('nightclub/index') }}" style="padding:4px 5px">Total Clubs <span class="pull-right badge bg-blue">{{ $nightClubCount }}</span></a></li>
                    <li> <a href="{{ url('nightclub/allEventDetails') }}" style="padding:4px 5px">Active Events <span class="pull-right badge bg-red">{{ $nightClubEventCount }}</span></a></li>
                    <li> <a href="{{ url('nightclub/allDealDetails') }}" style="padding:5px 5px">Active Deals <span class="pull-right badge bg-green">{{ $nightClubDealCount }}</span></a></li>
                    <!-- style="padding: 4px 15px;" -->
                  </ul>
                </div>
                </div>
            </div>
            <div class="col-lg-3 col-xs-3">
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3>{{ $userCount }}</h3>
                        <h4>Total Users</h4>
                    </div>
                    <div class="icon">
                        <i class="ion ion-pie-graph"></i>
                    </div>
                    <a href="{{ url('nightclub/allUserDetails') }}" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <div class="col-lg-3 col-xs-3">
                <div class="small-box bg-green">
                    <div class="inner">
                        <h3>{{ $clubOwnerRequestCount }}</h3>
                        <h4>Club Owner Requests</h4>
                    </div>
                    <div class="icon">
                        <i class="ion ion-pie-graph"></i>
                    </div>
                    <a href="{{ url('ownerRequest/view') }}" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <div class="col-lg-3 col-xs-3">
                <div class="small-box bg-olive">
                    <div class="inner">
                        <h3>{{ $suggestedVenuesCount }}</h3>
                        <h4>Suggested Venues</h4>
                    </div>
                    <div class="icon">
                        <i class="ion ion-stats-bars"></i>
                    </div>
                    <a href="{{ url('suggestvenue/list') }}" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
        @elseif(\Auth::user()->role == config('constants.clubAdmin'))
            <div class="col-lg-12">
                <div class="box box-warning">
                    <div class="box-header with-border">
                        <h4>Welcome to Bendr Panel!  </h4>
                        <div class="box-tools pull-right">
                            <button class="btn btn-box-tool" data-widget="collapse">
                                <i class="fa fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="box-body">
                        <div class="my_dashboard_text">
                            <p style="text-align:justify">Portal makes management even easier. Simply log in to your online account at any 
                                time for up-to-date information</p>
                            <p style="text-align:justify">&nbsp;&nbsp;&nbsp;<strong>&nbsp; App Admin will use to:</strong></p>
                            <ol>
                                <li style="text-align:justify">&nbsp;Manage <strong>Users</strong>.</li>
                                <li style="text-align:justify">&nbsp;View <strong>Clubs</strong>.</li>
                                <li style="text-align:justify">&nbsp;View <strong>Events</strong>.</li>
                                <li style="text-align:justify">&nbsp;View <strong>Deals</strong>.</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-xs-4">
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3>{{ $adminCount }}</h3>
                        <h4>Total Admins</h4>
                    </div>
                    <div class="icon">
                        <i class="ion ion-pie-graph"></i>
                    </div>
                    <a href="{{ url('nightclub/viewAdminUserDetails') }}" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <div class="col-lg-4 col-xs-4">
                <div class="small-box bg-green">
                    <div class="inner">
                        <h3>{{ $nightClubEventCount }}</h3>
                        <h4>Active Events</h4>
                    </div>
                    <div class="icon">
                        <i class="ion ion-pie-graph"></i>
                    </div>
                    <a href="{{ url('nightclub/allEventDetails') }}" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <div class="col-lg-4 col-xs-4">
                <div class="small-box bg-olive">
                    <div class="inner">
                        <h3>{{ $nightClubDealCount }}</h3>
                        <h4>Active Deals</h4>
                    </div>
                    <div class="icon">
                        <i class="ion ion-stats-bars"></i>
                    </div>
                    <a href="{{ url('nightclub/allDealDetails') }}" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
        @elseif(\Auth::user()->role == config('constants.eventAdmin'))
            <div class="col-lg-12">
                <div class="box box-warning">
                    <div class="box-header with-border">
                        <h4>Welcome to Bendr Panel!  </h4>
                        <div class="box-tools pull-right">
                            <button class="btn btn-box-tool" data-widget="collapse">
                                <i class="fa fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="box-body" style="min-height:400px">
                        <div class="my_dashboard_text">
                            <p style="text-align:justify">Portal makes management even easier. Simply log in to your online account at any 
                                time for up-to-date information</p>
                            <p style="text-align:justify">&nbsp;&nbsp;&nbsp;<strong>&nbsp; Event Admin will use to:</strong></p>
                            <ol>
                                <li style="text-align:justify">&nbsp;View <strong>Events</strong>.</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        @elseif(\Auth::user()->role == config('constants.dealAdmin'))
            <div class="col-lg-12">
                <div class="box box-warning">
                    <div class="box-header with-border">
                        <h4>Welcome to Bendr Panel!  </h4>
                        <div class="box-tools pull-right">
                            <button class="btn btn-box-tool" data-widget="collapse">
                                <i class="fa fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="box-body" style="min-height:400px">
                        <div class="my_dashboard_text">
                            <p style="text-align:justify">Portal makes management even easier. Simply log in to your online account at any 
                                time for up-to-date information</p>
                            <p style="text-align:justify">&nbsp;&nbsp;&nbsp;<strong>&nbsp; Deal Admin will use to:</strong></p>
                            <ol>
                                <li style="text-align:justify">&nbsp;View <strong>Deals</strong>.</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        @endif
    </div>
</div><!-- /.content -->

@endsection
