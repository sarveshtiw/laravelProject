<header class="main-header">
   <!-- Logo -->
        
        <a href="{{url('/')}}" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <!-- <span class="logo-mini"><b>Bendr</b></span> -->
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><img style="height:30px" src="{{asset('/images/bendr_blue.png')}}"></span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <!-- <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a> -->
          @if (\Auth::user()->role == config('constants.admin') || \Auth::user()->role == config('constants.clubAdmin'))
          <div class="navbar-custom-menu" style="">
            <ul class="nav navbar-nav">
                <li class="dropdown user user-menu">
                    <a href="{{ url('ownerRequest/view')}}"  style="padding: 15px 25px 10px 10px;">
                      <i class="fa fa-bell-o fa-1x custome_notification" style="" aria-hidden="true"></i>
                      <span style="top: 7px; left: 25px; position: absolute;">
                        @if(\Auth::user()->notificationMessagesCount) 
                          {{ \Auth::user()->notificationMessagesCount }} 
                        @endif</span>
                    </a>
                </li>
            </ul>
        </div>
        @endif
    </nav>
</header>