<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="{{ (!empty(\Auth::user()->image) && file_exists(public_path().config('constants.userImage').\Auth::user()->image)) ? asset('/images/user/'.\Auth::user()->image) : asset(config('constants.userDefaultImage'))}}" class="img-circle" alt="User Image" style="max-height:45px" />
            </div>
            <div class="pull-left info">
                <p> <?php 
                          if(isset(\Auth::user()->name)){
                            if( strlen(Auth::user()->name) > 15){
                              echo substr(trim(Auth::user()->name),0,15)."...";
                            } else {
                              echo trim(Auth::user()->name);
                            }
                          }else{
                            echo null;
                          }
                      ?></p>
                <a href="#" style="cursor:default"><!-- <i class="fa fa-circle text-success"></i> --> {{ ucwords(Auth::user()->role) }}</a>
            </div>
        </div>
      
        <ul class="sidebar-menu">
            <li class="header">MENU</li>
            <li class="treeview">
                <a href="{{url('/home')}}">
                    <i class="fa fa-home"></i> <span>Home</span> 
                </a>
                
            </li>
            @if (\Auth::user()->role == config('constants.admin'))
            <li class="treeview">
                <a href="#">
                <i class="fa fa-folder"></i> <span>Club Mgmt.</span> <i class="fa fa-angle-right pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class=""><a href="{{ url('nightclub/create') }}" id="menuAddClub"><i class="fa fa-circle-o"></i> Add Club</a></li>
                    <li class=""><a href="{{ url('nightclub/index')}}"><i class="fa fa-circle-o"></i>View All Clubs</a></li>
                    <li class=""><a href="{{ url('nightclub/allEventDetails') }}"><i class="fa fa-circle-o"></i>View All Events</a></li>
                    <li class=""><a href="{{ url('nightclub/allDealDetails') }}"><i class="fa fa-circle-o"></i>View All Deals</a></li><li class=""><a href="{{ url('nightclub/viewClubAdmins') }}"><i class="fa fa-circle-o"></i>View All Club Admins</a></li>
                </ul>
            </li>

            <li class="treeview">
                <a href="#">
                <i class="fa fa-users"></i> <span>User Mgmt.</span> <i class="fa fa-angle-right pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class=""><a href="{{ url('nightclub/allUserDetails') }}"><i class="fa fa-circle-o"></i>View Bendr Users</a></li>
                </ul>
            </li>

            <li class="treeview">
                <a href="#">
                <i class="fa fa-list"></i> <span>Reports.</span> <i class="fa fa-angle-right pull-right"></i>
                <ul class="treeview-menu">
                    <li class=""><a href="{{ url('suggestvenue/list') }}"><i class="fa fa-circle-o"></i>View Suggested Venues</a></li>
                    <li class=""><a href="{{ url('ownerRequest/view') }}"><i class="fa fa-circle-o"></i>View Club Owner Requests</a></li>
                    <li class=""><a href="{{ url('user/viewReportedUsers') }}"><i class="fa fa-circle-o"></i>View Reported Users</a></li>
                    <li class=""><a href="{{ url('group/viewReportedGroups') }}"><i class="fa fa-circle-o"></i>View Reported Groups</a></li>
                </ul>
                </a>
            </li>
            @elseif (\Auth::user()->role == config('constants.clubAdmin'))
            <li class="treeview">
                <a href="#">
                <i class="fa fa-folder"></i> <span>Club Mgmt.</span> <i class="fa fa-angle-right pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class=""><a href="{{ url('nightclub/index')}}"><i class="fa fa-circle-o"></i>View Club Info</a></li>
                </ul>
            </li>

            <li class="treeview">
                <a href="#">
                <i class="fa fa-folder"></i> <span>Event Mgmt.</span> <i class="fa fa-angle-right pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class=""><a href="{{ url('nightclub/viewCreateEvent') }}"><i class="fa fa-circle-o"></i> Add Event</a></li>
                    <li class=""><a href="{{ url('nightclubEvent/validateFBLogin') }}"><i class="fa fa-circle-o"></i> Import Events From Facebook</a></li>
                    <li class=""><a href="{{ url('nightclub/allEventDetails') }}"><i class="fa fa-circle-o"></i>View Club Events</a></li>
                    <li class=""><a href="{{ url('nightclub/disabledEventDetails') }}"><i class="fa fa-circle-o"></i>View Disabled Club Events</a></li>
                    <li class=""><a href="{{ url('nightclub/viewEventAdminDetails') }}"><i class="fa fa-circle-o"></i>View Club Event Admins</a></li>
                </ul>
            </li>

            <li class="treeview">
                <a href="#">
                <i class="fa fa-folder"></i> <span>Deal Mgmt.</span> <i class="fa fa-angle-right pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class=""><a href="{{ url('nightclub/createDeal') }}"><i class="fa fa-circle-o"></i> Add Deal</a></li>
                    <li class=""><a href="{{ url('nightclub/allDealDetails') }}"><i class="fa fa-circle-o"></i>View Club Deals</a></li>
                    <li class=""><a href="{{ url('nightclub/disabledDealDetails') }}"><i class="fa fa-circle-o"></i>View Disabled Club Deals</a></li>
                    <li class=""><a href="{{ url('nightclub/viewDealAdminDetails') }}"><i class="fa fa-circle-o"></i>View Deal Admins</a></li>
                </ul>
            </li>

            <li class="treeview">
                <a href="#">
                <i class="fa fa-list"></i> <span>Reports.</span> <i class="fa fa-angle-right pull-right"></i>
                <ul class="treeview-menu">
                    <li class=""><a href="{{ url('nightclub/nightclubCheckIn/getCheckInHistory') }}"><i class="fa fa-circle-o"></i>Club Check-in Report</a></li>
                    <li class=""><a href="{{ url('nightclub/nightclubCheckIn/getTotalVisits') }}"><i class="fa fa-circle-o"></i>Frequent Visitor Report</a></li>
                    <li class=""><a href="{{ url('nightclub/nightclubCheckIn/getTotalVisitorsBySuburbs') }}"><i class="fa fa-circle-o"></i>City Report</a></li>
                    <li class=""><a href="{{ url('nightclub/nightclubCheckIn/getAverageVisitTime') }}"><i class="fa fa-circle-o"></i>Average Time of Entry</a></li>
                    <li class=""><a href="{{ url('nightclub/nightclubCheckIn/getUserVisitTime') }}"><i class="fa fa-circle-o"></i>Club Visit per User</a></li>
                </ul>
                </a>
            </li>   
            <li class="treeview">
                <a href="#">
                <i class="fa fa-list"></i> <span>Event/Deal Admin Mgmt.</span> <i class="fa fa-angle-right pull-right"></i>
                <ul class="treeview-menu">
                    <li class=""><a href="{{ url('nightclub/viewCreateAdmin') }}"><i class="fa fa-circle-o"></i>Add Admin</a></li>
                    <li class=""><a href="{{ url('nightclub/viewAdminUserDetails') }}"><i class="fa fa-circle-o"></i>View All Admins</a></li>
                </ul>
                </a>
            </li>
            <li class="treeview">
                <a href="#">
                <i class="fa fa-list"></i> <span>Request to Admin.</span> <i class="fa fa-angle-right pull-right"></i>
                <ul class="treeview-menu">
                    <li class=""><a href="{{ url('club/request') }}"><i class="fa fa-circle-o"></i>Add New Request</a></li>
                    <li class=""><a href="{{ url('ownerRequest/view') }}"><i class="fa fa-circle-o"></i>View Requests</a></li>
                </ul>
                </a>
            </li>

            @elseif (\Auth::user()->role == config('constants.eventAdmin'))

            <li class="treeview">
                <a href="#">
                <i class="fa fa-folder"></i> <span>Event Mgmt.</span> <i class="fa fa-angle-right pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class=""><a href="{{ url('nightclub/viewCreateEvent') }}"><i class="fa fa-circle-o"></i> Add Club Event</a></li>
                    <li class=""><a href="{{ url('nightclub/disabledEventDetails') }}"><i class="fa fa-circle-o"></i>View Disabled Club Events</a></li>
                    <li class=""><a href="{{ url('nightclub/allEventDetails') }}"><i class="fa fa-circle-o"></i>View Events Info</a></li>
                </ul>
            </li>

            @elseif (\Auth::user()->role == config('constants.dealAdmin'))

            <li class="treeview">
                <a href="#">
                <i class="fa fa-folder"></i> <span>Deal Mgmt.</span> <i class="fa fa-angle-right pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li class=""><a href="{{ url('nightclub/createDeal') }}"><i class="fa fa-circle-o"></i> Add Deal</a></li>
                    <li class=""><a href="{{ url('nightclub/disabledDealDetails') }}"><i class="fa fa-circle-o"></i>View Disabled Club Deals</a></li>
                    <li class=""><a href="{{ url('nightclub/allDealDetails') }}"><i class="fa fa-circle-o"></i>View Deals Info</a></li>
                </ul>
            </li>

            @endif
 
            <li class="treeview">
                <a href="#">
                <i class="fa fa-gears"></i> <span>Account Settings</span>
                <i class="fa fa-angle-right pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li><a href="{{url('nightclub/changePassword')}}"><i class="fa fa-circle-o"></i> Change Password</a></li>
                    @if (\Auth::user()->role == config('constants.admin'))
                    <li><a href="{{url('setting/viewTerms')}}"><i class="fa fa-circle-o"></i> Terms & Conditions</a></li>
                    @endif
                    <li><a href="{{ url('/auth/logout') }}"><i class="fa fa-circle-o"></i>Sign out</a>
                </ul>
            </li>
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>