Hello!<br><br>

Your new password for your Bendr admin account is : {{$key['password']}}<br>
You can change this password at any time in your account settings.<br><br>

Yours truly,<br>
The Team
