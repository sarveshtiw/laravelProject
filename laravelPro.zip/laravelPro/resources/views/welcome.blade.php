@extends('app')

@section('content')
@if (Session::has('flash_message'))  
<div class="alert alert-success">
    <button data-dismiss="alert" class="close">
        ×
    </button>
    <strong>Success!</strong> {{ Session::get('flash_message') }}
</div>
@endif 

<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <div class="panel panel-default">
                <div class="panel-heading">CLUBS</div>

                <div class="panel-body">
                    @if(count($nightclubDetails) > 0)

                    @foreach($nightclubDetails as $nightclub)
                    
                    <div class="col-sm-3 col-xs-6">
                       <div class="caption" style="margin-bottom: 15px;">
                            <img class="caption__media" src="{{{isset($nightclub->coverImage) ? asset('images/nightclub/cover/'.$nightclub->coverImage): asset(config('constants.nightclubDefaultCoverImage'))}}}" />
                            <div class="caption__overlay">
                                <h4 class="caption__overlay__title">{{{isset($nightclub) ? $nightclub->nightclubName : null}}}</h4>
                                <p class="caption__overlay__content">{{$nightclub->briefInfo}}</p>
                            </div>

                        </div>
                    </div>
                    
                    @endforeach

                    
                    <div class="col-sm-12">
                        <?php echo $nightclubDetails->appends(Request::input())->render(); ?>
                    </div>
                    @else
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> No records found for nightclubs.<br><br>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
