@extends('app')
@section('title','Club Detail')
@section('content')

<section class="content-header">
    <h1>
        Club Details
    </h1>
    <!-- <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
    </ol> -->
</section>  
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <form class="form-horizontal" method="POST" enctype="multipart/form-data"
                  accesskey=""   accept-charset="UTF-8">
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <input type="hidden" name="id">
                <div class="col-sm-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <b>Club Details</b>
                            <div style="float:right">
                                <!-- <a  style="position: relative;" href="{{ url('/nightclub/update/'.$nightclubDetails->id) }}"> Edit Club Details | Back </a> -->
                                <a style="position: relative;" href="{{ url('/nightclub/update/'.$nightclubDetails->id) }}"><b>Edit Club Details</a> 
                                @if(\Auth::user()->role == 'admin')
                                | <a style="position: relative;" href="{{ url('nightclub/index') }}">Back</a></b>
                                @endif
                            </div>
                        </div>
                        <div class="panel-body">

                            <div class="form-group row">
                                <label class="control-label col-sm-4 leftalign">Cover Image :</label>
                                <img class="leftalign" style="height:150px; width:200px; margin-left:15px; " src="{{$nightclubDetails->coverImage}}"/>
                            </div>

                            <div class="form-group row">
                                <label class="control-label col-sm-4 leftalign">Logo :</label>
                                <img class="leftalign" style="height:150px; width:200px; margin-left:15px; " src="{{$nightclubDetails->logoImage}}"/>
                            </div>

                            <div class="form-group row">
                                <label class="control-label col-sm-4 leftalign">Name : </label>
                                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->nightclubName}}</label>
                            </div>

                            <div class="form-group row">
                                <label class="control-label col-sm-4 leftalign">Location :</label>
                                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->location}}</label>
                            </div>

                            <div class="form-group row">
                                <label for="weekdayOpeningTime" class="control-label col-sm-4 leftalign">Monday open time :</label>
                                <label class="control-label col-sm-6 leftalign">{{ date('h:i A',strtotime($nightclubDetails->monOpeningTime)) }}</label>
                            </div>

                            <div class="form-group row">
                                <label class="control-label col-sm-4 leftalign">Monday close time :</label>
                                <label class="control-label col-sm-6 leftalign">{{ date('h:i A',strtotime($nightclubDetails->monClosingTime)) }}</label>
                            </div>

                            <div class="form-group row">
                                <label class="control-label col-sm-4 leftalign">Tuesday open time :</label>
                                <label class="control-label col-sm-6 leftalign">{{ date('h:i A',strtotime($nightclubDetails->tueOpeningTime)) }}</label>
                            </div>

                            <div class="form-group row">
                                <label class="control-label col-sm-4 leftalign">Tuesday close time :</label>
                                <label class="control-label col-sm-6 leftalign">{{ date('h:i A',strtotime($nightclubDetails->tueClosingTime)) }}</label>
                            </div>

                            <div class="form-group row">
                                <label for="weekdayOpeningTime" class="control-label col-sm-4 leftalign">Wednesday open time :</label>
                                <label class="control-label col-sm-6 leftalign">{{ date('h:i A',strtotime($nightclubDetails->wedOpeningTime)) }}</label>
                            </div>

                            <div class="form-group row">
                                <label class="control-label col-sm-4 leftalign">Wednesday close time :</label>
                                <label class="control-label col-sm-6 leftalign">{{ date('h:i A',strtotime($nightclubDetails->wedClosingTime)) }}</label>
                            </div>

                            <div class="form-group row">
                                <label class="control-label col-sm-4 leftalign">Thursday open time :</label>
                                <label class="control-label col-sm-6 leftalign">{{ date('h:i A',strtotime($nightclubDetails->thuOpeningTime)) }}</label>
                            </div>

                            <div class="form-group row">
                                <label class="control-label col-sm-4 leftalign">Thursday close time :</label>
                                <label class="control-label col-sm-6 leftalign">{{ date('h:i A',strtotime($nightclubDetails->thuClosingTime)) }}</label>
                            </div>

                            <div class="form-group row">
                                <label for="weekdayOpeningTime" class="control-label col-sm-4 leftalign">Friday open time :</label>
                                <label class="control-label col-sm-6 leftalign">{{ date('h:i A',strtotime($nightclubDetails->friOpeningTime)) }}</label>
                            </div>

                            <div class="form-group row">
                                <label class="control-label col-sm-4 leftalign">Friday close time :</label>
                                <label class="control-label col-sm-6 leftalign">{{ date('h:i A',strtotime($nightclubDetails->friClosingTime)) }}</label>
                            </div>

                            <div class="form-group row">
                                <label class="control-label col-sm-4 leftalign">Saturday open time :</label>
                                <label class="control-label col-sm-6 leftalign">{{ date('h:i A',strtotime($nightclubDetails->satOpeningTime)) }}</label>
                            </div>

                            <div class="form-group row">
                                <label class="control-label col-sm-4 leftalign">Saturday close time :</label>
                                <label class="control-label col-sm-6 leftalign">{{ date('h:i A',strtotime($nightclubDetails->satClosingTime)) }}</label>
                            </div>

                            <div class="form-group row">
                                <label for="weekdayOpeningTime" class="control-label col-sm-4 leftalign">Sunday open time :</label>
                                <label class="control-label col-sm-6 leftalign">{{ date('h:i A',strtotime($nightclubDetails->sunOpeningTime)) }}</label>
                            </div>

                            <div class="form-group row">
                                <label class="control-label col-sm-4 leftalign">Sunday close time :</label>
                                <label class="control-label col-sm-6 leftalign">{{ date('h:i A',strtotime($nightclubDetails->sunClosingTime)) }}</label>
                            </div>

                            <div class="form-group row">
                                <label for="briefInfo" class="control-label col-sm-4 leftalign">Brief Info :</label>
                                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->briefInfo}}</label>
                            </div>

                            <div class="form-group row">
                                <label for="budget" class="control-label col-sm-4 leftalign">Budget :</label>
                                <label class="control-label col-sm-6 leftalign">
                                    @if($nightclubDetails->budget==1)
                                        {{ config('constants.BudgetCheapest') }}
                                    @elseif($nightclubDetails->budget==2)
                                        {{ config('constants.BudgetAverage') }}
                                    @elseif($nightclubDetails->budget==3)
                                        {{ config('constants.BudgetHighClass') }}
                                    @endif
                                </label>
                            </div>

                            <div class="form-group row">
                                <label for="venueType" class="control-label col-sm-4 leftalign">Venue Type :</label>
                                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->venueType}}</label>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-sm-4 leftalign">Sub Venue Type :</label>
                                <label class="control-label col-sm-6 leftalign">@if(!empty(trim($nightclubDetails->subVenueType))) {{$nightclubDetails->subVenueType}} @else  N/A @endif</label>
                            </div>
                            <div class="form-group row">
                                <label for="dressCode" class="control-label col-sm-4 leftalign">Popularity :</label>
                                <label class="control-label col-sm-6 leftalign">
                                    <fieldset class="rating">
                                        @if($nightclubDetails->popularity==3)
                                            <input type="radio" id="star3" name="rating" value="3" checked/><label class = "full" for="star3" title="3 Stars"></label>
                                            <input type="radio" id="star2" name="rating" value="2" /><label class = "full" for="star2" title="2 Stars"></label>
                                            <input type="radio" id="star1" name="rating" value="1" /><label class = "full" for="star1" title="1 Star"></label>
                                        @elseif($nightclubDetails->popularity==2)
                                            <input type="radio" id="star2" name="rating" value="2" checked/><label class = "full" for="star2" title="2 Stars"></label>
                                            <input type="radio" id="star1" name="rating" value="1" /><label class = "full" for="star1" title="1 Star"></label>
                                        @elseif($nightclubDetails->popularity==1)
                                            <input type="radio" id="star1" name="rating" value="1" checked/><label class = "full" for="star1" title="1 Star"></label>
                                        @endif
                                    </fieldset>

                                </label>
                            </div>

                            <div class="form-group row">
                                <label for="dressCode" class="control-label col-sm-4 leftalign">Dress Code :</label>
                                <label class="control-label col-sm-6 leftalign">
                                    @if($nightclubDetails->dressCode==1)
                                        {{ config('constants.DressCodeCasual') }}
                                    @elseif($nightclubDetails->dressCode==2)
                                        {{ config('constants.DressCodeSemiFormal') }}
                                    @elseif($nightclubDetails->dressCode==3)
                                        {{ config('constants.DressCodeFormal') }}
                                    @endif
                                </label>
                            </div>

                            <div class="form-group row">
                                <label for="musicGenre" class="control-label col-sm-4 leftalign">Music Genre :</label>
                                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->musicGenre}}</label>
                            </div>

                            <div class="form-group row">
                                <label for="musicGenre" class="control-label col-sm-4 leftalign">Sub Music Genre :</label>
                                <label class="control-label col-sm-6 leftalign">@if(!empty(trim($nightclubDetails->subMusicGenre))) {{$nightclubDetails->subMusicGenre}} @else  N/A @endif</label>
                            </div>

                            <div class="form-group row">
                                <label for="facebookLink" class="control-label col-sm-4 leftalign">Facebook Link :</label>
                                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->facebookLink}}</label>
                            </div>

                            <div class="form-group row">
                                <label for="twitterLink" class="control-label col-sm-4 leftalign">Twitter Link :</label>
                                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->twitterLink}}</label>  
                            </div>

                            <div class="form-group row">
                                <label for="instagramLink" class="control-label col-sm-4 leftalign">Instagram Link :</label>
                                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->instagramLink}}</label>
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                    <div class="panel-heading">
                        <b>Additional Club Photos</b>
                    </div>
                    <div class="panel-body">
                        <div class="row" style="padding: 10px;">
                            @if (isset($nightclubImages))

                            @foreach ($nightclubImages as $image)
                            <div class="additionalImageDiv">
                                <img src="{{$image->image}}" style="width:180px;height:150px" class="img-thumbnail" >
                            </div>
                            @endforeach  

                            @endif

                        </div>
                    </div>
                </div>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
@endsection