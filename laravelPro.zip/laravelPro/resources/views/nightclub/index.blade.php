@extends('app')
@section('title','Club List')
@section('content')

<section class="content-header">
    <h1>
        Club List
    </h1>
    <!-- <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
    </ol> -->
</section>   
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Club List
                    <div style="float:right">
                        @if(\Auth::user()->role == 'admin')
                            <b><a style="position: relative;" href="{{ url('nightclub/create') }}">Add Club</a></b>
                        @endif
                    </div>
                </div>
                <div class="panel-body">
                    <form class="form-inline" style="margin-bottom:9px;" method="POST" enctype="multipart/form-data" action="{{URL::to('nightclub/search')}}">
                        <!-- <input type="text" class="form-control col-xs-4" style="width: 140px; position: relative;" placeholder="Location" name="location" value="{{{ Input::old('location', isset($searchCriteria) ? $searchCriteria['location'] : null)}}}"> -->
                        <input type="text" class="form-control col-xs-4" style="width:180px; position: relative; margin-right:2px" placeholder="Club Name" name="nightclubName" value="{{{ Input::old('nightclubName', isset($searchCriteria) ? $searchCriteria['nightclubName'] : null)}}}">&nbsp;
                        <button class="btn btn-default" style="position: relative; margin-right:2px" type="submit"><i class="glyphicon glyphicon-search"></i></button>
                    </form>

                    @if (count($nightclubs) > 0)
                    <table class="table table-striped table-bordered table-hover table-responsive" id="mytable">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Location</th>
                                <th>Brief Info</th>
                                <th>Logo</th>
                                <th style="width: 100px !important;" >Club Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($nightclubs as $nightclub)
                            <tr>
                                <td>{{ ucwords($nightclub->nightclubName) }}</td>
                                <td>{{ ucfirst($nightclub->location) }}</td>
                                <td>{{ ucfirst($nightclub->briefInfo) }}</td>
                                <td><img style="height:72px; width:72px;" src="{{{isset($nightclub->logo) ? asset('images/nightclub/logo/'.$nightclub->logo): asset(config('constants.nightclubDefaultImage'))}}}"/></td>
                                <td class="table-action-items"> 
                                    <a href="{{ url('/nightclub/update/'.$nightclub->id) }}"><span class="glyphicon glyphicon-pencil"></span></a>
                                    <a href="{{url('/nightclub/viewDetails/'.$nightclub->id)}}"><span class="glyphicon glyphicon-eye-open"></span> </a>
                                    <a id="act_{{$nightclub->id}}" data-id="{{$nightclub->id}}" href="#" data-toggle="modal" data-target="#myModalActivation" style="{{ ($nightclub->isDisabled) ? 'visibility:visible; display:inline;' : 'visibility:hidden; display:none;'}}"><span class="glyphicon glyphicon-ok-sign" style="color: #00ff00;"></span></a>
                                    <a id="deact_{{$nightclub->id}}" data-id="{{$nightclub->id}}" href="#" data-toggle="modal" style="{{ ($nightclub->isDisabled) ? 'visibility:hidden; display:none;' : 'visibility:visible; display:inline;'}}" data-target="#myModal"><span class="glyphicon glyphicon-remove-sign" style="color: #ff0000;"></span></a></td> 
                            </tr>
                            @endforeach
                        </tbody>

                    </table>
                    <?php echo $nightclubs->appends(Request::input())->render(); ?>
                    @else
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> No records found for nightclubs.<br><br>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<div id="myModal" class="modal fade in" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" onClick="delText()" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Comfirm Deactivation</h4>
            </div>
            <div class="modal-body">
                <p>Do you want to deactivate this Club?</p>
                <label id="modalLabel" style="color: red;"></label>
                <input type="hidden" class="form-control" id="disableReason" name="disableReason" value="Disabled by App Admin" placeholder="Reason to Disable">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" onClick="delText()" data-dismiss="modal">No</button>
                <button type="button" class="btn btn-default" onClick="myfunc1('deactivate')">Yes</button>
                <input type="hidden" value="" name="clubId" id="dialogClubId">
            </div>
        </div>

    </div>
</div>
<div id="myModalActivation" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Confirm Activation</h4>
            </div>
            <div class="modal-body">
                <p>Do you want to activate this Club?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                <button type="button" class="btn btn-default" onClick="Activate('activate')">Yes</button>
                <input type="hidden" value="" name="userId" id="dialogActivateUserId">
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script>
    $('#myModal').on('show.bs.modal', function (e) {
        //alert(e.relatedTarget.dataset.id);
        $('#dialogClubId').val(e.relatedTarget.dataset.id);
    });

    $('#myModalActivation').on('show.bs.modal', function (e) {
        //alert(e.relatedTarget.dataset.id);
        $('#dialogActivateUserId').val(e.relatedTarget.dataset.id);
    });

    function delText() {
        $('input[type=TEXT], text').val('');
    }

    function myfunc1(action) {
        var data = document.getElementById('disableReason').value;
        var id = document.getElementById('dialogClubId').value;

        if (data == '')
        {
            document.getElementById("modalLabel").innerHTML = "* please fill reason to disable";
            return false;
        }
        $.ajax({
            url: "{{asset('index.php/nightclub/deactivate')}}",
            type: 'POST',
            data: {
                'id': id,
                'data': data
            },
            success: function (response) {
                $('#myModal').modal('hide');
                $('#deact_' + id).css({'display': 'none', 'visibility': 'hidden'});
                $('#act_' + id).css({'display': 'inline', 'visibility': 'visible'});

                $('input[type=TEXT], text').val('');
            }
        });

        return false;
    }

    function Activate(action) {

        var clubId = document.getElementById('dialogActivateUserId').value;

        $.ajax({
            type: "post",
            url: "{{asset('index.php/nightclub/activate')}}",
            data: {'clubId': clubId, 'type': action},
            cache: false,
            success: function (result) {
                $('#myModalActivation').modal('hide');
                $('#deact_' + clubId).css({'display': 'inline', 'visibility': 'visible'});
                $('#act_' + clubId).css({'display': 'none', 'visibility': 'hidden'});
            }
        });
    }
    $(document).ready(function ()
    {
        //$("#mytable").tablesorter();
        var rowCount = $('#mytable tr').length;

    }
    );

</script>

@endsection
