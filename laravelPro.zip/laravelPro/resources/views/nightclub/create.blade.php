@extends('app')
@section('title','Add Club')
@section('content')
<style type="text/css">

.remove-right-padding{
 padding-left: 10px;
padding-right: 0px;
padding-top: 5px;
}
.padding-align-top{
    padding-top: 5px;
}
#myModalActivation .form-group{
    font-size: 13px;
    padding-bottom: 15px;
    border-bottom: 1px solid #f4f4f4;
}
#myModalActivation .form-group:last-child{
    padding-bottom: 0px;
    border-bottom: none;
}
</style>
<section class="content-header">
    <h1>
        Add Club
    </h1>
</section> 
<div class="content">
    <!-- /.content -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Add Club
                    </div>
                    <div class="panel-body">
                        <form method="POST" enctype="multipart/form-data" action="{{URL::to('nightclub/create')}}"
                              accesskey=""   accept-charset="UTF-8" onsubmit="return validateAddClub()">
                            <input type="hidden" name="_token" value="{{ csrf_token() }}">
                            <input type="hidden" name="id" value="{{{ Input::old('id', isset($nightclubDetails) ? $nightclubDetails->id : null)}}}">
                            <input type="hidden" id="hd_monOpeningTime" name="hd_monOpeningTime" value="{{{ Input::old('hd_monOpeningTime', isset($nightclubDetails) ? $nightclubDetails->monOpeningTime : null)}}}">
                            <input type="hidden" id="hd_monClosingTime" name="hd_monClosingTime" value="{{{ Input::old('hd_monClosingTime', isset($nightclubDetails) ? $nightclubDetails->monClosingTime : null)}}}">
                            <input type="hidden" id="hd_tueOpeningTime" name="hd_tueOpeningTime" value="{{{ Input::old('hd_tueOpeningTime', isset($nightclubDetails) ? $nightclubDetails->tueOpeningTime : null)}}}">
                            <input type="hidden" id="hd_tueClosingTime" name="hd_tueClosingTime" value="{{{ Input::old('hd_tueClosingTime', isset($nightclubDetails) ? $nightclubDetails->tueClosingTime : null)}}}">
                            <input type="hidden" id="hd_wedOpeningTime" name="hd_wedOpeningTime" value="{{{ Input::old('hd_wedOpeningTime', isset($nightclubDetails) ? $nightclubDetails->wedOpeningTime : null)}}}">
                            <input type="hidden" id="hd_wedClosingTime" name="hd_wedClosingTime" value="{{{ Input::old('hd_wedClosingTime', isset($nightclubDetails) ? $nightclubDetails->wedClosingTime : null)}}}">
                            <input type="hidden" id="hd_thuOpeningTime" name="hd_thuOpeningTime" value="{{{ Input::old('hd_thuOpeningTime', isset($nightclubDetails) ? $nightclubDetails->thuOpeningTime : null)}}}">
                            <input type="hidden" id="hd_thuClosingTime" name="hd_thuClosingTime" value="{{{ Input::old('hd_thuClosingTime', isset($nightclubDetails) ? $nightclubDetails->thuClosingTime : null)}}}">
                            <input type="hidden" id="hd_friOpeningTime" name="hd_friOpeningTime" value="{{{ Input::old('hd_friOpeningTime', isset($nightclubDetails) ? $nightclubDetails->friOpeningTime : null)}}}">
                            <input type="hidden" id="hd_friClosingTime" name="hd_friClosingTime" value="{{{ Input::old('hd_friClosingTime', isset($nightclubDetails) ? $nightclubDetails->friClosingTime : null)}}}">
                            <input type="hidden" id="hd_satOpeningTime" name="hd_satOpeningTime" value="{{{ Input::old('hd_satOpeningTime', isset($nightclubDetails) ? $nightclubDetails->satOpeningTime : null)}}}">
                            <input type="hidden" id="hd_satClosingTime" name="hd_satClosingTime" value="{{{ Input::old('hd_satClosingTime', isset($nightclubDetails) ? $nightclubDetails->sunOpeningTime : null)}}}">
                            <input type="hidden" id="hd_sunOpeningTime" name="hd_sunOpeningTime" value="{{{ Input::old('hd_sunOpeningTime', isset($nightclubDetails) ? $nightclubDetails->sunOpeningTime : null)}}}">
                            <input type="hidden" id="hd_sunClosingTime" name="hd_sunClosingTime" value="{{{ Input::old('hd_sunClosingTime', isset($nightclubDetails) ? $nightclubDetails->sunClosingTime : null)}}}">

                            <div class="alert alert-danger" style="display:none" id="jsAlertNotification">
                                <ul>
                                    <span id="clubNameInput"><li> The name field is required. </li></span>
                                    <span id="localtionInput"><li> The location field is required. </li></span>
                                    <span id="coverImageInput"><li> The cover image field is required. </li></span>
                                    <span id="logoImageInput"><li> The logo field is required. </li></span>
                                    <!-- <span id="mondayOpeningTimeInput"><li> The club opening time field is required. </li></span>
                                    <span id="mondayClosingTimeInput"><li> The club closing time field is required. </li></span> -->
                                    <span id="briefInfoInput"><li> The brief info field is required. </li></span>
                                    <span id="venueTypeInput"><li> The venue type field is required. </li></span>
                                    <span id="musicGenreInput"><li> The music genre field is required. </li></span>
                                    <span id="adminEmailInput"><li> The email field is required. </li></span>
                                </ul>
                            </div>
                            <?php if ($errors->count() > 0) { ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php foreach ($errors->all() as $messages) { ?>
                                            <li> <?php echo $messages ?> </li>
                                        <?php } ?>
                                    </ul>
                                </div>
                            <?php } ?>
                            @if (Session::has('error_message')) 
                            <div class="alert alert-danger">
                                    <ul>
                                        <li> {{Session::get('error_message')}} </li>
                                    </ul>
                                </div>
                            @endif
                            @if (Session::has('flash_message'))  
                            <div class="alert alert-success">
                                <button data-dismiss="alert" class="close">
                                    ×
                                </button>
                                <strong>Success!</strong> {{ Session::get('flash_message') }}
                            </div>
                            @endif 
                            <div class="col-sm-5">
                                <div class="form-group row">
                                    <label for="name" class="control-label">Name <span class="required_span">*</span></label>
                                    <div>
                                        <input type="text" class="form-control" id="name" name="name" placeholder="Name"
                                               value="{{{ Input::old('name', isset($nightclubDetails) ? $nightclubDetails->nightclubName : null)}}}">
                                    </div>

                                </div>
                                <div class="form-group row">
                                    <label for="location" class="control-label">Location <span class="required_span">*</span></label>
                                    <div>
                                        <input type="text" class="form-control" id="location" name="location" placeholder="location"
                                               value="{{{ Input::old('location',isset($nightclubDetails) ? $nightclubDetails->location : null)}}}">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="coverImage" class="control-label">Cover Image <span class="required_span">*</span></label>
                                    <div>
                                        <input type="file" class="form-control" id="cover" onchange="readURL(this, 'coverImage');" name="coverImage"
                                               value="{{{Input::old('coverImage',isset($nightclubDetails)?$nightclubDetails->coverImage : null)}}}">
                                    </div>
                                    <img id="coverImage" style="height:100px; width:100px;" src="{{{Input::old('coverImage',isset($nightclubDetails)?$nightclubDetails->coverImage : null)}}}"/>
                                </div>

                                <div class="form-group row">
                                    <label for="logo" class="control-label">Logo <span class="required_span">*</span></label>
                                    <div>
                                        <input type="file" class="form-control" id="logo" onchange="readURL(this, 'logoImage');" name="logo" >
                                    </div>
                                    <img id="logoImage" style="height:100px; width:100px;" src="{{{Input::old('logo',isset($nightclubDetails)?$nightclubDetails->logoImage : null)}}}"/>
                                </div>
                                <a href="#" data-toggle="modal" data-target="#myModalActivation">Add/Change Club Timings</a>
                                <div class="form-group row">
                                    <label for="briefInfo" class="control-label">Brief Info <span class="required_span">*</span></label>
                                    <div>
                                        ​<textarea id="info" maxlength="{{config('constants.descriptionAllowedCharacters')}}" name="briefInfo" rows="5" cols="52" class="form-control" placeholder="Brief Info">{{{Input::old('briefInfo',isset($nightclubDetails) ? $nightclubDetails->briefInfo : null)}}}</textarea>
                                        <span id="briefInfo_count" style="float:right">{{config('constants.descriptionAllowedCharacters')}}  Characters</span>
                                    </div>
                                </div>

                            </div>

                            <div class="col-sm-1"></div>

                            <div class="col-sm-6 myright">
                                <div class="form-group row">
                                    <label for="venueType" class="control-label">Venue Type <span class="required_span">*</span></label>
                                    <div>
                                        <?php $venueTypeList = App\Models\VenueType::lists('venueTypeName', 'venueTypeName'); ?>
                                        <?php echo Form::select('venueType', [null=>'Select Venue Type'] + $venueTypeList, isset($nightclubDetails->venueType)&&!empty($nightclubDetails->venueType)?$nightclubDetails->venueType:null, ['class' => 'form-control', 'onchange' =>'javascript:getSubVenueList()', 'id' =>'venueType']); ?>
                                        
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="subVenueType" class="control-label">Sub Venue Type</label>
                                    <div>
                                        <select name="subVenueType" class="form-control" id="subVenueType">
                                            <option value="{{{Input::old('subVenueType',isset($nightclubDetails)&&!empty($nightclubDetails->subVenueType)?$nightclubDetails->subVenueType : null)}}}">
                                                {{{Input::old('subVenueType',isset($nightclubDetails)&&!empty($nightclubDetails->subVenueType)?$nightclubDetails->subVenueType : 'N/A')}}}</option>
                                        </select>
                                        <div class="spinner3" id="subVenueTypeLoader" style="display:none"></div>
                                    </div>
                                </div>

                                

                                <div class="form-group row">
                                    <label for="dressCode" class="control-label">Dress Code <span class="required_span">*</span></label>
                                    <div>
                                        <select name="dressCode" class="form-control">
                                            <option value="1" <?php if(isset($nightclubDetails) && $nightclubDetails->dressCode=='1') echo "selected='selected'";?>>Casual</option>
                                            <option value="2" <?php if(isset($nightclubDetails) && $nightclubDetails->dressCode=='2') echo "selected='selected'";?>>Semi Formal</option>
                                            <option value="3" <?php if(isset($nightclubDetails) && $nightclubDetails->dressCode=='3') echo "selected='selected'";?>>Formal</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="musicGenre" class="control-label">Music Genre <span class="required_span">*</span></label>
                                    <div>
                                        <?php $musicGenreList = App\Models\musicGenre::lists('musicGenreName', 'musicGenreName'); ?>
                                        <?php echo Form::select('musicGenre', [null=>'Select Music Genre'] + $musicGenreList,isset($nightclubDetails->musicGenre)&&!empty($nightclubDetails->musicGenre)?$nightclubDetails->musicGenre:null, ['class' => 'form-control', 'onchange' =>'javascript:getSubMusicGenreList()', 'id' =>'musicGenre']); ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="subMusicGenre" class="control-label">Sub Music Genre</label>
                                    <div>
                                        <select name="subMusicGenre" class="form-control" id="subMusicGenre">
                                            <option value="{{{Input::old('subMusicGenre',isset($nightclubDetails)?$nightclubDetails->subMusicGenre : null)}}}">
                                                {{{Input::old('subMusicGenre',isset($nightclubDetails)?$nightclubDetails->subMusicGenre : 'N/A')}}}</option>
                                        </select>
                                        <div class="spinner3" id="subMusicGenreLoader" style="display:none"></div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="budget" class="control-label">Budget <span class="required_span">*</span></label>
                                    <div>
                                        <select name="budget" class="form-control" placeholder="Budget">
                                            <option value="1" <?php if(isset($nightclubDetails) && $nightclubDetails->budget=='1') echo "selected='selected'";?>>Affordable</option>
                                            <option value="2" <?php if(isset($nightclubDetails) && $nightclubDetails->budget=='2') echo "selected='selected'";?>>Average</option>
                                            <option value="3" <?php if(isset($nightclubDetails) && $nightclubDetails->budget=='3') echo "selected='selected'";?>>Classy</option>
                                        </select>
                                    </div>
                                </div>
                                @if(\Auth::user()->role == "admin")
                                <div class="form-group row">
                                    <label for="popularity" class="control-label">Popularity <span class="required_span">*</span></label>
                                    <div>
                                        <select name="popularity" class="form-control" placeholder="Popularity">
                                            <option value="1" <?php if(isset($nightclubDetails) && $nightclubDetails->popularity=='1') echo "selected='selected'";?>>One Star</option>
                                            <option value="2" <?php if(isset($nightclubDetails) && $nightclubDetails->popularity=='2') echo "selected='selected'";?>>Two Star</option>
                                            <option value="3" <?php if(isset($nightclubDetails) && $nightclubDetails->popularity=='3') echo "selected='selected'";?>>Three Star</option>
                                        </select>
                                    </div>
                                </div>
                                @endif
                                <div class="form-group row">
                                    <label for="facebookLink" class="control-label">Facebook Link</label>
                                    <div>
                                        <input type="text" class="form-control" name="facebookLink" placeholder="Facebook Link"
                                               value="{{{Input::old('facebookLink',isset($nightclubDetails)?$nightclubDetails->facebookLink : null)}}}">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="twitterLink" class="control-label">Twitter Link</label>
                                    <div>
                                        <input type="text" class="form-control" name="twitterLink" placeholder="Twitter Link"
                                               value="{{{Input::old('twitterLink',isset($nightclubDetails)?$nightclubDetails->twitterLink : null)}}}">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="instagramLink" class="control-label">Instagram Link</label>
                                    <div>
                                        <input type="text" class="form-control" name="instagramLink" placeholder="Instagram Link"
                                               value="{{{Input::old('instagramLink',isset($nightclubDetails)?$nightclubDetails->instagramLink : null)}}}">
                                    </div>
                                </div>
                                @if(\Auth::user()->role == "admin")
                                <div class="form-group row">
                                    <label for="email" class="control-label">Admin Login Email <span class="required_span">*</span></label>
                                    <div>
                                        <input type="email" id="userEmail" class="form-control" name="email" placeholder="Admin Email"
                                               value="{{{Input::old('email',isset($userDetails)?$userDetails->email : null)}}}">
                                               <span id="spanEmailAlert" style="float:right"></span>
                                    </div>
                                </div>
                                @endif

                            </div>
                            <div class="form-group">
                                <div class="col-sm-12 row">
                                    <button type="submit" class="btn btn-primary" id="saveButton">Save</button>
                                    <a class="btn btn-primary" style="position: relative;" href="{{ url('nightclub/index') }}">Cancel</a>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
                <!-- <div class="col-sm-12"> -->
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <b>Additional Club Photos</b> <span>(Up to {{config('constants.maxEventAdditionalIamge')}} images)</span>
                    </div>
                    <div class="panel-body">
                        <div class="" id="imageSuccessDiv" style="display:none">Club Additional Images Uploaded Successfully.</div>
                        <div class="form-group row" >
                            <?php  $nightclubId = ''; 
                                   if(input::get('nightclubId'))
                                    $nightclubId = base64_decode(input::get('nightclubId'))?>
                            
                            <input type="hidden" name="nightclubId" id="nightclubId" value="{{ (isset($nightclubId) && !empty($nightclubId))?$nightclubId : null }}">
                            @if(\Auth::user()->role == "club admin" || \Auth::user()->role == "admin")
                            <div class="form-inline" style="margin-left:12px !important">
                                <div id="fileuploader">Browse Files </div>
                                <div id="startUpload" style="margin-top: 15px;" style="curson:pointer">
                                    <!-- {{ (!isset($nightclubId) || empty($nightclubId))? "disabled": ""}} -->
                                    <input type="button" id="btnUploadServer" class="btn btn-primary" value="Upload to Server" style="margin-left: 10px; cursor:default"/>
                                </div>
                            </div>
                            @endif
                            
                        </div> 
                        <div class="row" style="padding: 10px;">
                                @if (isset($nightclubImages))

                                @foreach ($nightclubImages as $image)
                                <div class="additionalImageDiv">
                                    <img src="{{$image->image}}" style="width:180px;height:150px" class="img-thumbnail" >
                                    <a href="{{asset('index.php/nightclub/deleteClubImages?nightclubId='.$image->nightclubId.'&nightclubPhotoId='.$image->id.'&actionPage=edit')}}" onclick="return confirm('Are you sure want to delete selected image? ')"><span>Remove</span></a>
                                </div>
                                @endforeach  

                                @endif

                        </div>
                    </div>
                </div>
            <!-- </div> -->
            </div>
        </div>
    </div>
</div>

<div id="myModalActivation" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Add/Change club Timings</h4>
            </div>
            <div class="modal-body"> 
                <div class="alert alert-danger" style="display:none" id="modalErrors">
                    <ul>
                        <span id="monCloseOpenError"><li> Monday opening and closing time are compulsory. </li></span>
                    </ul>
                </div>
            <div class="form-group row">
                <div class="col-md-4 remove-right-padding">
                    <label for="monopenTime" class="control-label">Monday | Open Time <span class="required_span">*</span></label>
                </div>
                <div class="col-md-3 remove-left-padding">
                    <input type="text" class="form-control timeinput" name="monOpeningTime" id="monOpeningTime" placeholder="Time"
                           value="{{{Input::old('monOpeningTime',isset($nightclubDetails)?$nightclubDetails->monOpeningTime : null)}}}">
                </div>
                <div class="col-md-2 remove-right-padding">
                    <label for="monClosingTime" class="control-label">Close Time <span class="required_span">*</span></label>
                </div>
                <div class="col-md-3 remove-left-padding">
                    <input type="text" class="form-control timeinput" name="monClosingTime" id="monClosingTime" placeholder="Time"
                           value="{{{Input::old('monClosingTime',isset($nightclubDetails)?$nightclubDetails->monClosingTime : null)}}}">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-4 remove-right-padding">
                    <label for="tueOpeningTime" class="control-label">Tuesday | Open Time <span class="required_span">*</span></label>
                </div>
                <div class="col-md-3 remove-left-padding">
                    <input type="text" class="form-control timeinput" name="tueOpeningTime" id="tueOpeningTime" placeholder="Time"
                           value="{{{Input::old('tueOpeningTime',isset($nightclubDetails)?$nightclubDetails->tueOpeningTime : null)}}}">
                </div>
                <div class="col-md-2 remove-right-padding">
                <label for="tueClosingTime" class="control-label">Close Time <span class="required_span">*</span></label>
                </div>
                <div class="col-md-3 remove-left-padding">
                    <input type="text" class="form-control timeinput" name="tueClosingTime" id="tueClosingTime" placeholder="Time"
                           value="{{{Input::old('tueClosingTime',isset($nightclubDetails)?$nightclubDetails->tueClosingTime : null)}}}">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-4 remove-right-padding">
                <label for="wedOpeningTime" class="control-label">Wednesday | Open Time <span class="required_span">*</span></label>
                </div>
                <div class="col-md-3 remove-left-padding">
                    <input type="text" class="form-control timeinput" name="wedOpeningTime" id="wedOpeningTime" placeholder="Time"
                           value="{{{Input::old('wedOpeningTime',isset($nightclubDetails)?$nightclubDetails->wedOpeningTime : null)}}}">
                </div>

                <div class="col-md-2 remove-right-padding">
                <label for="wedClosingTime" class="control-label">Close Time <span class="required_span">*</span></label>
                </div>
                <div class="col-md-3 remove-left-padding">
                    <input type="text" class="form-control timeinput" name="wedClosingTime" id="wedClosingTime" placeholder="Time"
                           value="{{{Input::old('wedClosingTime',isset($nightclubDetails)?$nightclubDetails->wedClosingTime : null)}}}">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-4 remove-right-padding">
                <label for="thuOpeningTime" class="control-label">Thursday | Open Time <span class="required_span">*</span></label>
                </div>
               <div class="col-md-3 remove-left-padding">
                    <input type="text" class="form-control timeinput" name="thuOpeningTime" id="thuOpeningTime" placeholder="Time"
                           value="{{{Input::old('thuOpeningTime',isset($nightclubDetails)?$nightclubDetails->thuOpeningTime : null)}}}">
                </div>

                <div class="col-md-2 remove-right-padding">
                <label for="thuClosingTime" class="control-label">Close Time <span class="required_span">*</span></label>
                </div>
                <div class="col-md-3 remove-left-padding">
                    <input type="text" class="form-control timeinput" name="thuClosingTime" id="thuClosingTime" placeholder="Time"
                           value="{{{Input::old('thuClosingTime',isset($nightclubDetails)?$nightclubDetails->thuClosingTime : null)}}}">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-4 remove-right-padding">
                <label for="friOpeningTime" class="control-label">Friday | Open Time <span class="required_span">*</span></label>
                </div>
                <div class="col-md-3 remove-left-padding">
                    <input type="text" class="form-control timeinput" name="friOpeningTime" id="friOpeningTime" placeholder="Time"
                           value="{{{Input::old('friOpeningTime',isset($nightclubDetails)?$nightclubDetails->friOpeningTime : null)}}}">
                </div>
                 <div class="col-md-2 remove-right-padding">
                <label for="friClosingTime" class="control-label">Close Time <span class="required_span">*</span></label>
                </div>
                 <div class="col-md-3 remove-left-padding">
                    <input type="text" class="form-control timeinput" name="friClosingTime" id="friClosingTime" placeholder="Time"
                           value="{{{Input::old('friClosingTime',isset($nightclubDetails)?$nightclubDetails->friClosingTime : null)}}}">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-4 remove-right-padding">
                <label for="satOpeningTime" class="control-label">Saturday | Open Time <span class="required_span">*</span></label>
                </div>
                <div class="col-md-3 remove-left-padding">
                    <input type="text" class="form-control timeinput" name="satOpeningTime" id="satOpeningTime" placeholder="Time"
                           value="{{{Input::old('satOpeningTime',isset($nightclubDetails)?$nightclubDetails->satOpeningTime : null)}}}">
                </div>
                <div class="col-md-2 remove-right-padding">
                <label for="satClosingTime" class="control-label">Close Time <span class="required_span">*</span></label>
               </div>
               <div class="col-md-3 remove-left-padding">
                    <input type="text" class="form-control timeinput" name="satClosingTime" id="satClosingTime" placeholder="Time"
                           value="{{{Input::old('satClosingTime',isset($nightclubDetails)?$nightclubDetails->satClosingTime : null)}}}">
                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-4 remove-right-padding">
                <label for="sunOpeningTime" class="control-label">Sunday | Open Time <span class="required_span">*</span></label>
                </div>
                <div class="col-md-3 remove-left-padding">
                    <input type="text" class="form-control timeinput" name="sunOpeningTime" id="sunOpeningTime" placeholder="Time"
                           value="{{{Input::old('sunOpeningTime',isset($nightclubDetails)?$nightclubDetails->sunOpeningTime : null)}}}">
                </div>
                 <div class="col-md-2 remove-right-padding">
                    <label for="sunClosingTime" class="control-label">Close Time <span class="required_span">*</span></label>
                    </div>
                    <div class="col-md-3 remove-left-padding">
                        <input type="text" class="form-control timeinput" name="sunClosingTime" id="sunClosingTime" placeholder="Time"
                               value="{{{Input::old('sunClosingTime',isset($nightclubDetails)?$nightclubDetails->sunClosingTime : null)}}}">
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" onClick="clearModalData()">Cancel</button>
                <button type="button" class="btn btn-default" id="btnAddTime" onClick="saveClubTime()">Add</button>
                <input type="hidden" value="" name="userId" id="dialogActivateUserId">
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script>
    $('#myModalActivation').on('show.bs.modal', function (e) {
        //alert(e.relatedTarget.dataset.id);
        $('#dialogActivateUserId').val(e.relatedTarget.dataset.id);
    });
    function clearModalData()
    {
      $(".timeinput").val("");  
      $('#myModalActivation').modal('hide');
    }
        function saveClubTime(){
        var x = $("#monOpeningTime").val();
        var y = $("#monClosingTime").val();
        if(x.length <= 0|| y.length <= 0){
         $('#modalErrors').css("display","block");   
        }else{
        $('#modalErrors').css("display","none"); 
        $("#hd_monOpeningTime").val($("#monOpeningTime").val());
        $("#hd_monClosingTime").val($("#monClosingTime").val());
        $("#hd_tueOpeningTime").val($("#tueOpeningTime").val());
        $("#hd_tueClosingTime").val($("#tueClosingTime").val());
        $("#hd_wedOpeningTime").val($("#wedOpeningTime").val());
        $("#hd_wedClosingTime").val($("#wedClosingTime").val());
        $("#hd_thuOpeningTime").val($("#thuOpeningTime").val());
        $("#hd_thuClosingTime").val($("#thuClosingTime").val());
        $("#hd_friOpeningTime").val($("#friOpeningTime").val());
        $("#hd_friClosingTime").val($("#friClosingTime").val());
        $("#hd_satOpeningTime").val($("#satOpeningTime").val());
        $("#hd_satClosingTime").val($("#satClosingTime").val());
        $("#hd_sunOpeningTime").val($("#sunOpeningTime").val());
        $("#hd_sunClosingTime").val($("#sunClosingTime").val());
        
        $("#myModalActivation .close").click(); 
        }

        
    }

    function readURL(input, data) {
        var imageId = '#' + data;
        if (input.files && input.files[0]) {
            var reader = new FileReader();


            reader.onload = function (showImage) {
                $(imageId)
                        .attr('src', showImage.target.result)
                        .width(100)
                        .height(100);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
    
    function getSubVenueList(){
        $.ajax({
            url: "{{asset('index.php/venueType/getSubVenueList')}}",
            type: 'POST',
            data: {'venueType' : $("#venueType").val()},
            dataType: 'json',
            beforeSend: function() {
                // setting a timeout
                $('#subVenueTypeLoader').css('display','inline-block');
            },
            success: function(response) {
                $('#subVenueTypeLoader').css('display','none');
                if(response.length>=1){
                    $('#subVenueType').find('option').remove();
                    $("#subVenueType").append(new Option('Select Sub Venue Type',''));
                    for (var i = 0; i < response.length; i++) {
                        $("#subVenueType").append(new Option(response[i].venueSubTypeName, response[i].venueSubTypeName));
                    }
                } else {
                    $('#subVenueType').find('option').remove();
                    $("#subVenueType").append(new Option("N/A",""));
                }
            },
            error: function(data) {
                console.log('Try Again.');
            }
        });
    }

    function getSubMusicGenreList(){
        $.ajax({
            url: "{{asset('index.php/musicGenre/getSubMusicGenreList')}}",
            type: 'POST',
            data: {'musicGenre' : $("#musicGenre").val()},
            dataType: 'json',
            beforeSend: function() {
                // setting a timeout
                // /$('.refereshrecapcha').html('Refreshing....');
                $('#subMusicGenreLoader').css('display','none');
            },
            success: function(response) {
                $('#subMusicGenreLoader').css('display','none');
                if(response.length>=1){
                    $('#subMusicGenre').find('option').remove();
                    $("#subMusicGenre").append(new Option('Select Sub Music Genre',''));
                    for (var i = 0; i < response.length; i++) {
                        $("#subMusicGenre").append(new Option(response[i].subMusicGenreName, response[i].subMusicGenreName));
                    }
                } else {
                    $('#subMusicGenre').find('option').remove();
                    $("#subMusicGenre").append(new Option( "N/A",""));
                }
            },
            error: function(data) {
                console.log('Try Again.');
            }
        });
    }
    $.datetimepicker.setDateFormatter({
        parseDate: function (date, format) {
            var d = moment(date, format);
            return d.isValid() ? d.toDate() : false;
        },
        
        formatDate: function (date, format) {
            return moment(date).format(format);
        }
    });
    
    $('#monOpeningTime').change(function() {
          $('#tueOpeningTime').val($('#monOpeningTime').val());
          $('#wedOpeningTime').val($('#monOpeningTime').val());
          $('#thuOpeningTime').val($('#monOpeningTime').val());
          $('#friOpeningTime').val($('#monOpeningTime').val());
          $('#satOpeningTime').val($('#monOpeningTime').val());
          $('#sunOpeningTime').val($('#monOpeningTime').val());
         });
         
    $('#monClosingTime').change(function() {
          $('#tueClosingTime').val($('#monClosingTime').val());
          $('#wedClosingTime').val($('#monClosingTime').val());
          $('#thuClosingTime').val($('#monClosingTime').val());
          $('#friClosingTime').val($('#monClosingTime').val());
          $('#satClosingTime').val($('#monClosingTime').val());
          $('#sunClosingTime').val($('#monClosingTime').val());
         });

        
    $(document).ready(function(){
        $('#btnAddTime').prop('disabled', true);
        $('.timeinput').change(function() {
            if($(this).val() != '') {
               $('#btnAddTime').prop('disabled', false);
            }else{
                $('#btnAddTime').prop('disabled', true);
            }
         });

        $('#monOpeningTime').datetimepicker({datepicker:false, format:'h:mm a', formatTime:'h:mm a', step:60, ampm: true});
        $('#monClosingTime').datetimepicker({datepicker:false, format:'h:mm a', formatTime:'h:mm a', step:60, ampm: true});
        $('#tueOpeningTime').datetimepicker({datepicker:false, format:'h:mm a', formatTime:'h:mm a', step:60, ampm: true});
        $('#tueClosingTime').datetimepicker({datepicker:false, format:'h:mm a', formatTime:'h:mm a', step:60, ampm: true});

        $('#wedOpeningTime').datetimepicker({datepicker:false, format:'h:mm a', formatTime:'h:mm a', step:60, ampm: true});
        $('#wedClosingTime').datetimepicker({datepicker:false, format:'h:mm a', formatTime:'h:mm a', step:60, ampm: true});
        $('#thuOpeningTime').datetimepicker({datepicker:false, format:'h:mm a', formatTime:'h:mm a', step:60, ampm: true});
        $('#thuClosingTime').datetimepicker({datepicker:false, format:'h:mm a', formatTime:'h:mm a', step:60, ampm: true});

        $('#friOpeningTime').datetimepicker({datepicker:false, format:'h:mm a', formatTime:'h:mm a', step:60, ampm: true});
        $('#friClosingTime').datetimepicker({datepicker:false, format:'h:mm a', formatTime:'h:mm a', step:60, ampm: true});
        $('#satOpeningTime').datetimepicker({datepicker:false, format:'h:mm a', formatTime:'h:mm a', step:60, ampm: true});
        $('#satClosingTime').datetimepicker({datepicker:false, format:'h:mm a', formatTime:'h:mm a', step:60, ampm: true});

        $('#sunOpeningTime').datetimepicker({datepicker:false, format:'h:mm a', formatTime:'h:mm a', step:60, ampm: true});
        $('#sunClosingTime').datetimepicker({datepicker:false, format:'h:mm a', formatTime:'h:mm a', step:60, ampm: true});

        $("#info").on("keyup",function(event){
            var length = this.value.length;
            var char_count = parseInt("{{config('constants.descriptionAllowedCharacters')}}")  - parseInt(length);
            $("#briefInfo_count").html(char_count+" Characters");
        });
        $( "#userEmail" ).blur(function() {
            var userEmail = $("#userEmail").val();
            if(userEmail.trim() && userEmail.length>2){
                $.ajax({
                    url: "{{asset('index.php/nighclub/validateUserEmail')}}",
                    type: 'POST',
                    data: {'userEmail' : $("#userEmail").val()},
                    dataType: 'json',
                    beforeSend: function() {
                        // setting a timeout
                        $('#spanEmailAlert').html('Validating....');
                        $("#saveButton").attr('disabled',true);
                    },
                    success: function(data, response) {
                        if(data.type=='error'){
                            $("#spanEmailAlert").html(data.message);
                            $("#spanEmailAlert").css('color','#dd4b39');
                        }
                        else if(data.type=='success'){
                            $("#spanEmailAlert").html(data.message);
                            $("#saveButton").removeAttr('disabled');
                            $("#spanEmailAlert").css('color','#00a65a');
                        }
                    },
                    error: function(data,response) {
                       $("#spanEmailAlert").html('Try again');
                       $("#spanEmailAlert").css('color','#dd4b39');
                    }
                });
            }
            else if(userEmail.length==0)
            {
                $("#spanEmailAlert").html('');
            }
        });
    

    var id = $("#nightclubId").val();
    var uploadObj = $("#fileuploader").uploadFile({
        autoSubmit: false,
        url: "{{asset('index.php/nightclub/uploadClubMultipleImages')}}",
        fileName: "myfile",
        formData: {"id": id},
        maxFileCount:"{{config('constants.maxEventAdditionalIamge')}}",
        acceptFiles:"image/*",
        maxFileSize:5240000,
        afterUploadAll: function ()
        {
            location.reload(); 
        }
    });

    $("#startUpload").click(function ()
    {
        uploadObj.startUpload();
    });
}); 

setTimeout(function() {   //calls click event after a certain time
   @if(!isset($nightclubId) || empty($nightclubId))
        $(".ajax-upload-dragdrop").css("opacity","0.65");
        $(".ajax-upload-dragdrop").css("pointer-events","none");
        $('#btnUploadServer').attr("disabled", 'disabled');
    @elseif(isset($nightclubId) && !empty($nightclubId))
        $(".ajax-upload-dragdrop").css("opacity","1");
        $(".ajax-upload-dragdrop").css("pointer-events","auto");
        $('#btnUploadServer').removeAttr("disabled");
    @endif  
}, 2000);

function validateAddClub(){
    var flag=true;

    if($("#name").val()==''){
        flag = false;
        $("#clubNameInput").css("display","block");
    }else{
        $("#clubNameInput").css("display","none");
    }

    if($("#location").val()==''){
        flag = false;
        $("#localtionInput").css("display","block");
    }else{
        $("#localtionInput").css("display","none");
    }

    if($("#coverImage").attr('src')==''){
        flag = false;
        $("#coverImageInput").css("display","block");
    }else{
        $("#coverImageInput").css("display","none");
    }

    if($("#logoImage").attr('src')==''){
        flag = false;
        $("#logoImageInput").css("display","block");
    }else{
        $("#logoImageInput").css("display","none");
    }

    // if($("#weekdayOpenTime").val()==''){
    //     flag = false;
    //     $("#wkOpeningTimeInput").css("display","block");
    // }else{
    //     $("#wkOpeningTimeInput").css("display","none");
    // }
    
    // if($("#weekdayCloseTime").val()==''){
    //     flag = false;
    //     $("#wkClosingTimeInput").css("display","block");
    // }else{
    //     $("#wkClosingTimeInput").css("display","none");
    // }

    // if($("#weekendOpenTime").val()==''){
    //     flag = false;
    //     $("#wkndOpeningTimeInput").css("display","block");
    // }else{
    //     $("#wkndOpeningTimeInput").css("display","none");
    // }

    // if($("#weekendCloseTime").val()==''){
    //     flag = false;
    //     $("#wkndClosingTimeInput").css("display","block");
    // }else{
    //     $("#wkndClosingTimeInput").css("display","none");
    // }

    if($("#info").val()==''){
        flag = false;
        $("#briefInfoInput").css("display","block");
    }else{
        $("#briefInfoInput").css("display","none");
    }

    if($("#venueType").val()==''){
        flag = false;
        $("#venueTypeInput").css("display","block");
    }else{
        $("#venueTypeInput").css("display","none");
    }

    if($("#musicGenre").val()==''){
        flag = false;
        $("#musicGenreInput").css("display","block");
    }else{
        $("#musicGenreInput").css("display","none");
    }

    if($("#userEmail").val()==''){
        flag = false;
        $("#adminEmailInput").css("display","block");
    }else{
        $("#adminEmailInput").css("display","none");
    }
    if(flag)
        $("#jsAlertNotification").css("display","none");
    else
        $("#jsAlertNotification").css("display","block");
    return flag;
}

</script>
@endsection
