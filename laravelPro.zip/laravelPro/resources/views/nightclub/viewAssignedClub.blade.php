@extends('app')

@section('content')

<section class="content-header">
    <h1>
        Event Details
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
    </ol>
</section>   
<div class="content">
    <div class="page-header">
        <h1>View Club Details</h1>
    </div>
    <form class="form-horizontal" method="POST" enctype="multipart/form-data"
          accesskey=""   accept-charset="UTF-8">
        <input type="hidden" name="_token" value="{{ csrf_token() }}">
        <input type="hidden" name="nightclubId" value="{{$nightclubDetails->id}}">
        <div class="col-sm-2">
            <ul class="nav nav-pills nav-stacked">
                <li class="active"><a href="#">Home</a></li>
                <li><a href="{{ url('nightclub/update/'.$nightclubDetails->id) }}">Update Nightclub</a></li>
            </ul>
        </div>
        <div class="col-sm-5">
            <div class="form-group row">
                <label class="control-label col-sm-6 rightalign">Cover Image :</label>
                <img class="leftalign" style="height:150px; width:200px; margin-left:15px; " src="{{$nightclubDetails->coverImage}}"/>
            </div>

            <div class="form-group row">
                <label class="control-label col-sm-6 rightalign">Name : </label>
                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->nightclubName}}</label>
            </div>

            <div class="form-group row">
                <label class="control-label col-sm-6 rightalign">location :</label>
                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->location}}</label>
            </div>

            <div class="form-group row">
                <label for="weekdayOpeningTime" class="control-label col-sm-6 rightalign">weekday open time :</label>
                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->weekdayOpeningTime}}</label>
            </div>

            <div class="form-group row">
                <label class="control-label col-sm-6 rightalign">weekday close time :</label>
                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->weekdayClosingTime}}</label>
            </div>

            <div class="form-group row">
                <label class="control-label col-sm-6 rightalign">weekend open time :</label>
                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->weekendOpeningTime}}</label>
            </div>

            <div class="form-group row">
                <label class="control-label col-sm-6 rightalign">weekend close time :</label>
                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->weekendClosingTime}}</label>
            </div>

            <div class="form-group row">
                <label for="briefInfo" class="control-label col-sm-6 rightalign">Brief Info :</label>
                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->briefInfo}}</label>
            </div>

            <div class="form-group row">
                <label for="budget" class="control-label col-sm-6 rightalign">Budget :</label>
                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->budget}}</label>
            </div>

        </div>



        <div class="col-sm-5">

            <div class="form-group row">
                <label class="control-label col-sm-6 rightalign">logo :</label>
                <img class="leftalign" style="height:150px; width:200px; margin-left:15px; " src="{{$nightclubDetails->logoImage}}"/>
            </div>

            

            <div class="form-group row">
                <label for="venueType" class="control-label col-sm-6 rightalign">Venue Type :</label>
                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->venueType}}</label>
            </div>
            <div class="form-group row">
                <label class="control-label col-sm-6 rightalign">Sub Venue Type :</label>
                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->subVenueType}}</label>
            </div>

            <div class="form-group row">
                <label for="dressCode" class="control-label col-sm-6 rightalign">Dress Code :</label>
                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->dressCode}}</label>
            </div>

            <div class="form-group row">
                <label for="musicGenre" class="control-label col-sm-6 rightalign">Music Genre :</label>
                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->musicGenre}}</label>
            </div>

            <div class="form-group row">
                <label for="facebookLink" class="control-label col-sm-6 rightalign">Facebook Link :</label>
                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->facebookLink}}</label>
            </div>

            <div class="form-group row">
                <label for="twitterLink" class="control-label col-sm-6 rightalign">twitter link :</label>
                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->twitterLink}}</label>  
            </div>

            <div class="form-group row">
                <label for="instagramLink" class="control-label col-sm-6 rightalign">instagram link :</label>
                <label class="control-label col-sm-6 leftalign">{{$nightclubDetails->instagramLink}}</label>
            </div>
        </div>


        <!--<div class="form-group">
            <div class="col-xs-offset-2 col-xs-10">
                <div class="checkbox">
                    <label><input type="checkbox"> Remember me</label>
                </div>
            </div>
        </div> -->

    </form>
</div>

@endsection