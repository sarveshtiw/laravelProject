## Bendr Application

Bendr is an application for club going people. It helps users to find clubs near them and connect and communicate with other users in the club.

It also helps clubs to promote their business.

## Developed by

Appster Information Pvt. Ltd. [Appster website](http://appster.in).
